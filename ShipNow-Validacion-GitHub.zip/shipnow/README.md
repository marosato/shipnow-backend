# ShipNow — Backend III

API académica de logística, versión 1.0.0. Integra usuarios, productos, pedidos, entregas, tracking, documentos, mocks, errores uniformes, Winston, Swagger, pruebas funcionales y Docker.

La corrección de la entrega incorpora el CRUD de envíos, Multer, Docker Compose y pruebas del ciclo completo mediante `npm test`. La devolución y la matriz de cambios están en [src/docs/ENTREGA-FINAL.md](src/docs/ENTREGA-FINAL.md). **Estado de validación:** Windows: 114 pruebas unitarias y 26 de integración aprobadas según la salida compartida. Docker pendiente de ejecución remota. Ver [VALIDACION-GITHUB.md](VALIDACION-GITHUB.md).

## Ejecutar localmente

Requisitos: Node.js 24, npm y MongoDB 7 u 8 funcionando en `127.0.0.1:27017`.

```powershell
npm ci
Copy-Item .env.example .env
npm start
```

Si ya existe `.env`, conservarlo y revisar sus valores. El servidor abre después de conectar MongoDB e inicializar los índices. `npm run dev` habilita reinicio al cambiar archivos.

- Swagger: http://127.0.0.1:8080/api/docs/
- OpenAPI JSON: http://127.0.0.1:8080/api/docs/openapi.json
- Health: http://127.0.0.1:8080/api/health (200 si MongoDB responde; 503 si no está disponible).

## Pruebas

```powershell
npm test
```

Ejecuta primero las pruebas sin MongoDB y luego las pruebas funcionales con MongoDB real. No hace falta iniciar `npm start`: Supertest usa la aplicación directamente. Si MongoDB no está disponible, el comando falla con código distinto de cero; no omite pruebas ni informa un éxito parcial.

La base predeterminada es `shipnow_test`. Las pruebas **no usan `MONGODB_URI` ni leen `.env`**. Para otra instancia:

```powershell
$env:TEST_MONGODB_URI = 'mongodb://127.0.0.1:27017/shipnow_test'
npm test
Remove-Item Env:TEST_MONGODB_URI
```

Se exige un nombre terminado en `_test`. Cada caso crea sus datos, elimina solo sus propios registros y usa carpetas temporales para archivos. No se ejecuta `dropDatabase` ni se vacían colecciones completas. Usar una base exclusiva de pruebas.

- `npm run test:unit`: 114 pruebas de configuración, validaciones, errores, mocks, logs, contratos OpenAPI y Multer, sin MongoDB.
- `npm run test:integration`: 26 pruebas con MongoDB: usuarios/productos, mocks persistidos, CRUD de envíos, transiciones, tracking, archivos, compensación y errores.
- [src/docs/VERIFICACION-FINAL.md](src/docs/VERIFICACION-FINAL.md): evidencia y limitaciones de la verificación realizada.

## Docker

Requiere Docker Engine o Docker Desktop iniciado, en modo Linux, con Compose v2.

```powershell
docker compose up --build -d
docker compose ps
Invoke-RestMethod 'http://127.0.0.1:8080/api/health'
```

La imagen usa construcción multi-stage, dependencias de producción y usuario `node`. Compose espera el healthcheck de MongoDB antes de iniciar la API. El puerto 8080 se publica solo en loopback. Detener antes el servidor local si ocupa ese puerto.

Los datos de MongoDB, uploads y logs se conservan en volúmenes. `docker compose down` detiene el conjunto sin borrar esos volúmenes. MongoDB no publica un puerto al host. Mocks y loggerTest quedan apagados en producción.

Ejecutar toda la suite en contenedores, sin instalar Node ni MongoDB en Windows:

```powershell
docker compose --profile test run --build --rm tests
```

El perfil `test` inicia una instancia **mongo-test** independiente con almacenamiento temporal. El contenedor `tests` ejecuta exactamente `npm test`. La API principal no necesita estar iniciada. Para detener esa base al terminar: `docker compose --profile test stop mongo-test`.

Construcción/ejecución manual (MongoDB debe ser accesible desde el contenedor):

```powershell
docker build --target production -t shipnow:1.0.0 .
docker run --rm -p 127.0.0.1:8080:8080 -e MONGODB_URI=mongodb://host.docker.internal:27017/shipnow_development shipnow:1.0.0
```

`host.docker.internal` corresponde a Docker Desktop. Para conservar uploads/logs en una ejecución manual, montar volúmenes; Compose ya lo resuelve.

## Variables

| Variable | Uso |
| --- | --- |
| `PORT` | Puerto HTTP, entero de 1 a 65535. |
| `HOST` | `127.0.0.1` por defecto; `0.0.0.0` dentro del contenedor. |
| `NODE_ENV` | `development`, `test` o `production`. |
| `MONGODB_URI` | URI de la base usada por el servidor. Obligatoria. |
| `ENABLE_MOCKS` | `true`/`false`; siempre apagado en producción. |
| `ENABLE_LOGGER_TEST` | `true`/`false`; siempre apagado en producción. |
| `TEST_MONGODB_URI` | Variable de terminal exclusiva de los tests; por defecto `mongodb://127.0.0.1:27017/shipnow_test`. |

La configuración del servidor está centralizada en `src/config/env.config.js`, la de tests en `src/config/test.config.js`. No subir `.env` ni credenciales.

## Endpoints principales

| Recurso | Operaciones |
| --- | --- |
| `/api/users` y `/api/users/:id` | Crear, listar y consultar usuarios. |
| `/api/products` y `/api/products/:id` | Crear, listar y consultar productos. |
| `/api/orders` y `/api/orders/:id` | POST, GET, GET por ID, PATCH y DELETE lógico. |
| `/api/deliveries` y `/api/deliveries/:id` | POST, GET, GET por ID, PATCH de repartidor y DELETE lógico del envío. |
| `/api/orders/:id/status`, `/api/deliveries/:id/status` | PATCH del estado compartido. |
| `/api/orders/:id/tracking`, `/api/deliveries/:id/tracking` | GET del estado y su historial. |
| `/api/users/:id/documents`, `/api/deliveries/:id/documents` | POST multipart y GET de metadatos paginados. |
| Las rutas de documentos + `/:documentId` | GET del archivo como adjunto. |
| `/api/health` | GET de disponibilidad de API y MongoDB. |
| `/api/mocks/dataset`, `/api/mocks/users`, `/api/mocks/seed` | Herramientas de desarrollo; seed persiste un lote. |
| `/loggerTest` | Prueba de los seis niveles; solo habilitada en desarrollo/test. |

Swagger detalla los 31 métodos HTTP cuando las herramientas de desarrollo están habilitadas; en producción quedan 27. Los endpoints de la propia documentación no se cuentan.

Un **envío** se representa con un pedido (`Order`: cliente, dirección, ítems, total, estado e historial) y su entrega (`Delivery`: relación única con pedido y repartidor). El estado y la prioridad se leen siempre del pedido. No hay una colección paralela `Shipment` con datos duplicados.

Se avanza `pending → assigned → in_transit → delivered`. Se admite cancelación desde los estados no terminales. Repetir el estado es idempotente. Para avanzar se exige una entrega con repartidor válido. El historial se guarda junto al cambio de estado en una escritura atómica.

PATCH de datos solo está permitido en `pending`. DELETE es una **baja lógica del envío completo**, disponible para `pending` o `cancelled`; oculta pedido y entrega y conserva registros, historial y archivos. Los pedidos entregados no se borran por HTTP. Para cancelar manteniendo el recurso visible, usar PATCH de estado. Los importes se calculan en centavos y no se aceptan `total` ni `status` en el alta.

## Repartidores

Los usuarios públicos se crean con rol `user`. Para dar de alta un repartidor sin exponer una ruta de elevación de permisos:

```powershell
npm run driver:create -- "Repartidor de prueba" "driver@example.com"
```

En Compose: `docker compose exec api npm run driver:create -- "Repartidor de prueba" "driver@example.com"`. El comando usa la base configurada, valida el email y devuelve el ID. En desarrollo también se pueden obtener repartidores mediante `/api/mocks/seed`.

## Archivos y logs

Multer acepta **un archivo `document`**, sin campos adicionales, PDF/JPEG/PNG y hasta **5 MiB**. Se verifican extensión, MIME y firma inicial. Es una validación de formato, no un análisis antivirus ni una validación completa del contenido. Los bytes se guardan en `uploads/` con UUID; MongoDB guarda dueño, nombre original, tipo, tamaño y clave interna. Las rutas físicas no se exponen. Si falla el guardado de metadatos se retira el archivo escrito.

Los archivos se descargan como adjuntos, comprobando que pertenezcan al recurso de la URL. La carpeta no está montada como contenido estático. La baja lógica conserva los comprobantes para auditoría; la purga definitiva y su política de retención quedan fuera de estas rutas.

Winston escribe `error-AAAA-MM-DD.log` (fatal/error) y `combined-AAAA-MM-DD.log` (hasta http), con rotación de 5 MB y hasta 5 archivos por serie. La consola se usa en desarrollo. Se registran IDs, eventos y códigos; no cuerpos, credenciales ni documentos. `logs/`, `uploads/`, `node_modules/`, `.env` y `coverage/` están excluidos de Git y del contexto de Docker.

## Arquitectura y alcance

`Router → Controller → Service → Repository → Model`. Las rutas no consultan MongoDB. Los errores terminan en un middleware común con `{ status: "error", error: "CODE", message: "..." }`. Los éxitos usan `{ status: "success", data: ... }`. Listados paginados: `page` y `limit`, máximo 100 elementos.

La documentación vigente está en **`src/docs/`**. Los apuntes de etapas anteriores se conservaron en `src/docs/historial/`; son históricos, no instrucciones de la versión actual.

Este proyecto implementa la entrega académica para un entorno controlado. No incorpora autenticación/autorización de clientes y repartidores; no debe exponerse públicamente con datos personales hasta incorporar esos controles. Compose lo publica solo en el equipo local.
