# Validación remota

El workflow `.github/workflows/validate.yml` corre en una máquina Ubuntu de GitHub con cada push o pull request. No necesita Docker local ni secretos.

1. Construye la etapa `test` del Dockerfile y ejecuta `npm test`: suites unitarias y de integración con MongoDB real descartable.
2. Construye y arranca la imagen de producción con MongoDB y espera sus healthchecks.
3. Comprueba HTTP: salud de API y base, listados Orders/Deliveries, Swagger UI/OpenAPI y rutas de prueba deshabilitadas.
4. Conserva logs en un artifact por siete días y elimina únicamente los recursos del runner temporal.

En GitHub, abrir **Actions → Validar ShipNow con Docker → ejecución**. Un resultado verde confirma estos pasos para el commit indicado. Los detalles están en cada paso y en el artifact `shipnow-validation-…`. No se publica una imagen ni se despliega la aplicación.

Para repetir una ejecución, usar **Re-run all jobs**. Cuando el workflow esté en la rama principal, también se puede iniciar con **Run workflow**.

La ejecución remota aún debe completar sus pasos: preparar el YAML no equivale a aprobar Docker. La evidencia previa de Windows corresponde a 114 pruebas unitarias y 26 de integración aprobadas.

## Subir desde la web, sin Docker local

La conexión usada para preparar este paquete no tiene permiso de escritura (GitHub 403). No se creó una rama ni se ejecutó Actions desde aquí.

1. Extraer el ZIP. Dentro de `shipnow` están los archivos que van en la raíz del repositorio; no subir la carpeta `shipnow` como un nivel adicional.
2. En https://github.com/marosato/shipnow-backend crear la rama `ci/validacion-entrega-final` desde `main` usando el selector de ramas.
3. En esa rama, usar **Add file → Upload files**. Subir primero la carpeta `src` y confirmar el commit; luego la carpeta `tests` y confirmar otro commit. Subir después los archivos de la raíz, incluidos Dockerfile, docker-compose.yml, package.json, package-lock.json, .dockerignore y .env.example. No subir el ZIP, node_modules ni un archivo .env personal.
4. Por último subir la carpeta `.github` completa y confirmar el commit. Debe quedar `.github/workflows/validate.yml` en GitHub. Este último commit dispara Actions con todo el código ya disponible.
5. Abrir Actions y revisar la ejecución de esa rama. No es necesario modificar main para probar.

Las subidas separadas evitan el límite de archivos de la interfaz web. Los documentos históricos que ya estaban en `docs/` pueden permanecer: no afectan las pruebas; la documentación actual es README.md y src/docs/ENTREGA-FINAL.md.
