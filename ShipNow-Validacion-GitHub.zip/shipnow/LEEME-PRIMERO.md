# Actualización de la entrega final

Este paquete integra la ampliación de Orders/Deliveries y las correcciones de la devolución del profesor. No se publicó automáticamente en GitHub.

1. Detener el servidor de ShipNow.
2. Guardar una copia de la carpeta actual fuera del repositorio.
3. Extraer el ZIP y copiar el contenido de `shipnow/` sobre el proyecto. Conservar la carpeta `.git` y el `.env` existentes; el ZIP no los incluye.
4. La documentación anterior ya está en `src/docs/historial/`. Si al copiar quedó la carpeta vieja `docs/` en la raíz, moverla fuera del repositorio como respaldo. No debe quedar una segunda copia en la raíz.
5. Ejecutar `npm ci` y luego `npm test`, con MongoDB local iniciado. No hace falta iniciar la API para los tests.
6. Verificar Docker con los comandos del README. Si el puerto 8080 está ocupado por el servidor local, detenerlo antes de iniciar Compose.
7. Revisar `git status` y `git diff --stat`; recién después de aprobar las pruebas, preparar el commit de la corrección.

`npm test` ahora incluye MongoDB. Usa una base independiente `shipnow_test`, sin tomar la URI del servidor. El estado de verificación y los comandos están en `src/docs/VERIFICACION-FINAL.md`.

La suite completa ya fue aprobada en Windows. Para validar Docker sin usar el equipo local, seguir VALIDACION-GITHUB.md y confirmar el resultado verde en Actions.
