import { expect } from 'chai';
import request from 'supertest';
import express from 'express';
import { createApp } from '../src/app.js';
import { upload } from '../src/middlewares/upload.js';
import { errorHandler } from '../src/middlewares/error-handler.js';
import { validateFile } from '../src/services/document.service.js';
import { MAX_FILE_SIZE } from '../src/config/upload.config.js';
import { testConfig } from '../src/config/test.config.js';

// Archivo PDF mínimo con cabecera; firma != validación semántica del documento.
const pdf = Buffer.from('%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\n%%EOF\n');
const app = express();
app.post('/upload', upload, (req, res, next) => {
  try { validateFile(req.file); res.json({ size: req.file.size }); } catch (error) { next(error); }
});
app.use(errorHandler);

describe('Entrega final: límites HTTP, archivos y aislamiento', () => {
  it('health devuelve 503 JSON cuando MongoDB no está conectado', async () => {
    const response = await request(createApp()).get('/api/health').expect(503);
    expect(response.body).to.include({ status: 'error', error: 'DATABASE_UNAVAILABLE' });
  });
  it('testing usa su propia URI e ignora la base de producción', () => {
    expect(testConfig({ MONGODB_URI: 'mongodb://localhost/production' }).mongodbUri).to.equal('mongodb://127.0.0.1:27017/shipnow_test');
    expect(() => testConfig({ TEST_MONGODB_URI: 'mongodb://localhost/production' })).to.throw('_test');
    expect(() => testConfig({ TEST_MONGODB_URI: 'mongodb://localhost/' })).to.throw('_test');
  });
  for (const [name, data, contentType] of [
    ['document.pdf', pdf, 'application/pdf'],
    ['photo.png', Buffer.from([137,80,78,71,13,10,26,10,0]), 'image/png'],
    ['photo.jpg', Buffer.from([255,216,255,224,0]), 'image/jpeg'],
  ]) {
    it(`Multer acepta extensión, MIME y firma compatibles: ${name}`, async () => {
      const response = await request(app).post('/upload').attach('document', data, { filename: name, contentType }).expect(200);
      expect(response.body.size).to.equal(data.length);
    });
  }
  for (const [name, data, contentType] of [
    ['script.exe', pdf, 'application/pdf'],
    ['fake.pdf', Buffer.from('not a PDF'), 'application/pdf'],
    ['mismatch.png', pdf, 'image/png'],
    ['mismatch.pdf', pdf, 'text/plain'],
  ]) {
    it(`rechaza archivo incompatible: ${name}`, async () => {
      expect((await request(app).post('/upload').attach('document', data, { filename: name, contentType }).expect(400)).body.error).to.equal('INVALID_FILE_TYPE');
    });
  }
  it('rechaza archivo ausente o vacío', async () => {
    for (const req of [request(app).post('/upload'), request(app).post('/upload').attach('document', Buffer.alloc(0), { filename: 'empty.pdf', contentType: 'application/pdf' })]) {
      expect((await req.expect(400)).body.error).to.equal('FILE_REQUIRED');
    }
  });
  it('rechaza más de 5 MiB con 413', async () => {
    const data = Buffer.alloc(MAX_FILE_SIZE + 1); pdf.copy(data);
    expect((await request(app).post('/upload').attach('document', data, { filename: 'large.pdf', contentType: 'application/pdf' }).expect(413)).body.error).to.equal('FILE_TOO_LARGE');
  });
  it('rechaza otro campo de archivo, múltiples archivos y campos de texto', async () => {
    const options = { filename: 'file.pdf', contentType: 'application/pdf' };
    const cases = [request(app).post('/upload').attach('other', pdf, options),
      request(app).post('/upload').attach('document', pdf, options).attach('document', pdf, options),
      request(app).post('/upload').field('extra','value').attach('document', pdf, options)];
    for (const req of cases) expect((await req.expect(400)).body.error).to.equal('INVALID_UPLOAD');
  });
  it('rechaza multipart malformado con el contrato global', async () => {
    expect((await request(app).post('/upload').set('Content-Type', 'multipart/form-data').send('broken').expect(400)).body.error).to.equal('INVALID_UPLOAD');
  });
  it('valida IDs antes de consultar MongoDB en las nuevas rutas', async () => {
    const api = createApp();
    for (const resource of ['orders', 'deliveries']) {
      await request(api).get(`/api/${resource}/bad/tracking`).expect(400);
      await request(api).delete(`/api/${resource}/bad`).expect(400);
      await request(api).patch(`/api/${resource}/bad`).send({}).expect(400);
    }
    for (const resource of ['users', 'deliveries']) {
      await request(api).post(`/api/${resource}/bad/documents`).expect(400);
      await request(api).get(`/api/${resource}/bad/documents`).expect(400);
    }
  });
});
