import { expect } from 'chai';
import request from 'supertest';
import { randomUUID } from 'node:crypto';
import { mkdtemp, readdir, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../src/app.js';
import User from '../src/models/user.model.js';
import Order from '../src/models/order.model.js';
import Delivery from '../src/models/delivery.model.js';
import Document from '../src/models/document.model.js';
import { MAX_FILE_SIZE } from '../src/config/upload.config.js';
import { expectDocumentedResponse } from './helpers/openapi.js';

const pdf = Buffer.from('%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\n%%EOF\n');
const attachment = { filename: 'comprobante.pdf', contentType: 'application/pdf' };
const absent = '000000000000000000000000';
let app, directory, user, driver, otherDriver, orders, users, deliveries;
const input = () => ({ userId: user._id, address: 'Calle Prueba 123', items: [{ name: 'Caja', quantity: 2, unitPrice: 12.5 }] });
async function makeOrder() {
  const r = await request(app).post('/api/orders').send(input()).expect(201);
  orders.push(r.body.data._id);
  return r.body.data;
}
async function makeDelivery(order) {
  const r = await request(app).post('/api/deliveries').send({ orderId: order._id, driverId: String(driver._id) }).expect(201);
  deliveries.push(r.body.data._id);
  return r.body.data;
}
async function documented(req, status, path, method) {
  const result = await req.expect(status);
  await expectDocumentedResponse(path, method, result);
  return result.body.data;
}

describe('Entrega final: CRUD, tracking y archivos con MongoDB real', () => {
  beforeEach(async () => {
    orders = []; users = []; deliveries = [];
    directory = await mkdtemp(join(tmpdir(), 'shipnow-uploads-'));
    app = createApp({ uploadDirectory: directory });
    user = (await request(app).post('/api/users').send({ name: 'Cliente', email: `${randomUUID()}@example.com` }).expect(201)).body.data;
    users.push(user._id);
    driver = await User.create({ name: 'Repartidor', email: `${randomUUID()}@example.com`, role: 'driver' }); users.push(driver._id);
    otherDriver = await User.create({ name: 'Otro repartidor', email: `${randomUUID()}@example.com`, role: 'driver' }); users.push(otherDriver._id);
  });
  afterEach(async () => {
    await Document.deleteMany({ ownerId: { $in: [...users, ...deliveries] } });
    await Delivery.deleteMany({ orderId: { $in: orders } });
    await Order.deleteMany({ _id: { $in: orders } });
    await User.deleteMany({ _id: { $in: users } });
    if (directory) await rm(directory, { recursive: true, force: true });
  });
  it('ciclo completo: alta, edición, asignación, traslado, entrega, comprobante y tracking', async () => {
    await documented(request(app).get('/api/health'), 200, '/api/health', 'get');
    const order = await makeOrder();
    const updated = await documented(request(app).patch(`/api/orders/${order._id}`).send({ address: 'Dirección corregida', priority: 'high', items: [{ name: 'Caja', quantity: 3, unitPrice: 10 }] }), 200, '/api/orders/{id}', 'patch');
    expect(updated).to.include({ total: 30, priority: 'high', address: 'Dirección corregida' });
    const delivery = await makeDelivery(order);
    const reassigned = await documented(request(app).patch(`/api/deliveries/${delivery._id}`).send({ driverId: String(otherDriver._id) }), 200, '/api/deliveries/{id}', 'patch');
    expect(reassigned.driverId).to.equal(String(otherDriver._id));
    for (const status of ['assigned','in_transit','delivered']) {
      await documented(request(app).patch(`/api/deliveries/${delivery._id}/status`).send({ status }), 200, '/api/deliveries/{id}/status', 'patch');
    }
    await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'delivered' }).expect(200);
    const tracking = await documented(request(app).get(`/api/deliveries/${delivery._id}/tracking`), 200, '/api/deliveries/{id}/tracking', 'get');
    expect(tracking.events.map(e => e.status)).to.deep.equal(['pending','assigned','in_transit','delivered']);
    const dates = tracking.events.map(e => Date.parse(e.at));
    expect(dates).to.deep.equal([...dates].sort((a,b) => a-b));
    const stored = await Order.findById(order._id).lean();
    expect(stored.tracking).to.have.length(4);
    const doc = await documented(request(app).post(`/api/deliveries/${delivery._id}/documents`).attach('document', pdf, attachment), 201, '/api/deliveries/{id}/documents', 'post');
    expect(doc.ownerId).to.equal(delivery._id);
    const listed = await documented(request(app).get(`/api/deliveries/${delivery._id}/documents?limit=1`), 200, '/api/deliveries/{id}/documents', 'get');
    expect(listed.map(x => x._id)).to.deep.equal([doc._id]);
    const downloaded = await request(app).get(`/api/deliveries/${delivery._id}/documents/${doc._id}`).expect(200);
    expect(downloaded.headers['content-disposition']).to.include('attachment');
    expect(downloaded.body.equals(pdf)).to.equal(true);
  });
  it('la prioridad editada se refleja en la entrega existente', async () => {
    const order = await makeOrder(); const delivery = await makeDelivery(order);
    await request(app).patch(`/api/orders/${order._id}`).send({ priority: 'high' }).expect(200);
    expect((await request(app).get(`/api/deliveries/${delivery._id}`).expect(200)).body.data.priority).to.equal('high');
  });
  for (const resource of ['orders','deliveries']) {
    it(`DELETE ${resource} da de baja el envío y preserva su historial`, async () => {
      const order = await makeOrder(); const delivery = await makeDelivery(order);
      const id = resource === 'orders' ? order._id : delivery._id;
      await documented(request(app).delete(`/api/${resource}/${id}`), 200, `/api/${resource}/{id}`, 'delete');
      await request(app).get(`/api/orders/${order._id}`).expect(404);
      await request(app).get(`/api/deliveries/${delivery._id}`).expect(404);
      await request(app).get(`/api/orders/${order._id}/tracking`).expect(404);
      for (const r of ['orders','deliveries']) {
        const list = await request(app).get(`/api/${r}?limit=100`).expect(200);
        expect(list.body.data.some(x => x._id === order._id || x._id === delivery._id)).to.equal(false);
      }
      const persisted = await Order.findById(order._id);
      expect(persisted.deletedAt).to.be.instanceOf(Date);
      expect(persisted.status).to.equal('cancelled');
      expect(persisted.tracking.map(e => e.status)).to.deep.equal(['pending','cancelled']);
      await request(app).delete(`/api/${resource}/${id}`).expect(404);
    });
  }
  it('bloquea edición y baja después de la asignación sin cambiar datos', async () => {
    const order = await makeOrder(); const delivery = await makeDelivery(order);
    await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'assigned' }).expect(200);
    const cases = [request(app).patch(`/api/orders/${order._id}`).send({ address:'Cambio inválido' }),
      request(app).patch(`/api/deliveries/${delivery._id}`).send({ driverId:String(otherDriver._id) }),
      request(app).delete(`/api/orders/${order._id}`), request(app).delete(`/api/deliveries/${delivery._id}`)];
    for (const req of cases) expect((await req.expect(409)).body.error).to.equal('ORDER_NOT_EDITABLE');
    expect((await Order.findById(order._id)).address).to.equal(input().address);
    expect((await request(app).get(`/api/deliveries/${delivery._id}`)).body.data.driverId).to.equal(String(driver._id));
  });
  it('rechaza edición vacía, campos protegidos y driver con rol incorrecto', async () => {
    const order = await makeOrder(); const delivery = await makeDelivery(order);
    for (const body of [{},{ total:0 },{ userId:absent },{ status:'delivered' }]) await request(app).patch(`/api/orders/${order._id}`).send(body).expect(400);
    await request(app).patch(`/api/deliveries/${delivery._id}`).send({ driverId:user._id }).expect(400);
    await request(app).patch(`/api/deliveries/${delivery._id}`).send({ driverId:absent }).expect(404);
  });
  it('guarda documento de usuario con nombre único y metadatos, sin ruta pública', async () => {
    const doc = await documented(request(app).post(`/api/users/${user._id}/documents`).attach('document', pdf, attachment), 201, '/api/users/{id}/documents','post');
    expect(doc).not.to.have.property('storageKey');
    const persisted = await Document.findById(doc._id).lean();
    expect(persisted.storageKey).to.match(/^[a-f0-9-]{36}\.pdf$/);
    expect((await readFile(join(directory,persisted.storageKey))).equals(pdf)).to.equal(true);
    await documented(request(app).get(`/api/users/${user._id}/documents`),200,'/api/users/{id}/documents','get');
    await request(app).get(`/api/users/${driver._id}/documents/${doc._id}`).expect(404);
  });
  it('no persiste archivos o metadatos inválidos, vacíos, excesivos ni de dueño ausente', async () => {
    const route = `/api/users/${user._id}/documents`;
    await request(app).post(route).expect(400);
    await request(app).post(route).attach('document', Buffer.from('fake'), attachment).expect(400);
    const large = Buffer.alloc(MAX_FILE_SIZE+1); pdf.copy(large);
    await request(app).post(route).attach('document',large,attachment).expect(413);
    await request(app).post(`/api/users/${absent}/documents`).attach('document',pdf,attachment).expect(404);
    expect(await readdir(directory)).to.deep.equal([]);
    expect(await Document.countDocuments({ ownerId:user._id })).to.equal(0);
  });
  it('compensa el archivo si falla la persistencia de metadatos', async () => {
    const original = Document.create;
    Document.create = async () => { throw new Error('Simulated database write failure'); };
    try { await request(app).post(`/api/users/${user._id}/documents`).attach('document',pdf,attachment).expect(500); }
    finally { Document.create = original; }
    expect(await readdir(directory)).to.deep.equal([]);
    expect(await Document.countDocuments({ ownerId:user._id })).to.equal(0);
  });
  it('transiciones concurrentes conservan un historial coherente con el estado', async () => {
    const order = await makeOrder(); await makeDelivery(order);
    const results = await Promise.all(['assigned','cancelled'].map(status => request(app).patch(`/api/orders/${order._id}/status`).send({ status })));
    // Puede ser serializable pending->assigned->cancelled (dos 200), o ganar cancelación (200/409).
    expect(results.every(r => [200,409].includes(r.status))).to.equal(true);
    const persisted = await Order.findById(order._id);
    expect(persisted.tracking.map(e => e.status)).to.deep.equal(persisted.tracking.length === 3 ? ['pending','assigned','cancelled'] : ['pending',persisted.status]);
    expect(persisted.tracking.at(-1).status).to.equal(persisted.status);
  });
});
