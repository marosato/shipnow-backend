import { expect } from 'chai';
import request from 'supertest';
import app from '../src/app.js';
import { validateOrderInput } from '../src/services/order.service.js';
const id = '507f1f77bcf86cd799439011';
const valid = { userId: id, address: ' Calle 1 ', items: [{ name: ' Caja ', quantity: 3, unitPrice: 0.1 }] };

describe('M5.1: validación de pedidos y entregas sin MongoDB', () => {
  it('calcula centavos, normaliza texto y establece valores del servidor', () => {
    const order = validateOrderInput(valid);
    expect(order).to.include({ total: 0.3, status: 'pending', priority: 'normal', address: 'Calle 1' });
    expect(order.items[0].name).to.equal('Caja');
  });
  const cases = [
    ['post', '/api/orders', { ...valid, items: [] }, 'INVALID_ITEMS'],
    ['post', '/api/orders', { ...valid, items: Array(101).fill(valid.items[0]) }, 'INVALID_ITEMS'],
    ['post', '/api/orders', { ...valid, items: [{ name: 'Caja', quantity: 1, unitPrice: 0.001 }] }, 'INVALID_ORDER_AMOUNT'],
    ['post', '/api/orders', { ...valid, items: [{ name: 'Caja', quantity: 1.5, unitPrice: 1 }] }, 'INVALID_ORDER_AMOUNT'],
    ['post', '/api/orders', { ...valid, items: [{ name: 'Caja', quantity: 1000000, unitPrice: 1000000000 }] }, 'INVALID_ORDER_AMOUNT'],
    ['post', '/api/orders', { ...valid, total: 0 }, 'INVALID_BODY'],
    ['post', '/api/orders', { ...valid, priority: 'urgent' }, 'INVALID_PRIORITY'],
    ['post', '/api/orders', { ...valid, userId: 'bad' }, 'INVALID_ID'],
    ['post', '/api/deliveries', { orderId: id, driverId: 'bad' }, 'INVALID_ID'],
    ['post', '/api/deliveries', { orderId: id, driverId: id, status: 'delivered' }, 'INVALID_BODY'],
    ['patch', `/api/orders/${id}/status`, { status: 'unknown' }, 'INVALID_STATUS'],
    ['patch', `/api/deliveries/${id}/status`, { status: 'unknown' }, 'INVALID_STATUS'],
    ['get', '/api/orders?limit=101', undefined, 'INVALID_PAGINATION'],
    ['get', '/api/deliveries?extra=1', undefined, 'INVALID_QUERY'],
  ];
  for (const [method, path, body, code] of cases) {
    it(`${method.toUpperCase()} ${path}: ${code}`, async () => {
      let call = request(app)[method](path);
      if (body) call = call.send(body);
      const response = await call.expect(400);
      expect(response.body.error).to.equal(code);
    });
  }
});
