import { expect } from 'chai';
import request from 'supertest';
import { randomUUID } from 'node:crypto';
import app from '../src/app.js';
import User from '../src/models/user.model.js';
import Order from '../src/models/order.model.js';
import Delivery from '../src/models/delivery.model.js';
import * as orderRepository from '../src/repositories/order.repository.js';
import { expectDocumentedResponse } from './helpers/openapi.js';

const absent = '000000000000000000000000';
let user, driver, orders;
const input = () => ({ userId: String(user._id), address: 'Calle de prueba 123',
  items: [{ name: 'Caja', quantity: 3, unitPrice: 0.1 }] });
async function createOrder() {
  const response = await request(app).post('/api/orders').send(input()).expect(201);
  orders.push(response.body.data._id);
  await expectDocumentedResponse('/api/orders', 'post', response);
  return response.body.data;
}
async function createDelivery(order) {
  const response = await request(app).post('/api/deliveries').send({ orderId: order._id, driverId: String(driver._id) }).expect(201);
  await expectDocumentedResponse('/api/deliveries', 'post', response);
  return response.body.data;
}

describe('M5.1: ciclo real de pedidos y entregas', () => {
  beforeEach(async () => {
    orders = [];
    // Fixtures internas: no se crea una ruta pública para elevar roles.
    user = await User.create({ name: 'Cliente test', email: `${randomUUID()}@example.com`, role: 'user' });
    driver = await User.create({ name: 'Driver test', email: `${randomUUID()}@example.com`, role: 'driver' });
  });
  afterEach(async () => {
    if (orders.length) {
      await Delivery.deleteMany({ orderId: { $in: orders } });
      await Order.deleteMany({ _id: { $in: orders } });
    }
    await User.deleteMany({ _id: { $in: [user?._id, driver?._id].filter(Boolean) } });
  });
  it('crea, lista, consulta y avanza por ambos endpoints sin divergir estados', async () => {
    const order = await createOrder();
    expect(order).to.include({ total: 0.3, status: 'pending', priority: 'normal' });
    const delivery = await createDelivery(order);
    expect(delivery.status).to.equal('pending');
    for (const [resource, item] of [['orders', order], ['deliveries', delivery]]) {
      const found = await request(app).get(`/api/${resource}/${item._id}`).expect(200);
      await expectDocumentedResponse(`/api/${resource}/{id}`, 'get', found);
      const list = await request(app).get(`/api/${resource}?limit=1`).expect(200);
      expect(list.body.data.length).to.be.at.most(1);
      await expectDocumentedResponse(`/api/${resource}`, 'get', list);
    }
    for (const [resource, id, status] of [['orders', order._id, 'assigned'], ['deliveries', delivery._id, 'in_transit'], ['deliveries', delivery._id, 'delivered']]) {
      const changed = await request(app).patch(`/api/${resource}/${id}/status`).send({ status }).expect(200);
      await expectDocumentedResponse(`/api/${resource}/{id}/status`, 'patch', changed);
      for (const [name, item] of [['orders', order], ['deliveries', delivery]]) {
        expect((await request(app).get(`/api/${name}/${item._id}`)).body.data.status).to.equal(status);
      }
    }
    const repeated = await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'delivered' }).expect(200);
    expect(repeated.body.data.status).to.equal('delivered');
    const invalid = await request(app).patch(`/api/deliveries/${delivery._id}/status`).send({ status: 'pending' }).expect(409);
    await expectDocumentedResponse('/api/deliveries/{id}/status', 'patch', invalid);
  });
  it('rechaza usuarios, repartidores y recursos inexistentes o con roles incorrectos', async () => {
    const missingUser = await request(app).post('/api/orders').send({ ...input(), userId: absent }).expect(404);
    await expectDocumentedResponse('/api/orders', 'post', missingUser);
    expect((await request(app).post('/api/orders').send({ ...input(), userId: String(driver._id) }).expect(400)).body.error).to.equal('INVALID_CUSTOMER');
    const order = await createOrder();
    for (const [driverId, status, code] of [[absent, 404, 'DRIVER_NOT_FOUND'], [String(user._id), 400, 'INVALID_DRIVER']]) {
      const response = await request(app).post('/api/deliveries').send({ orderId: order._id, driverId }).expect(status);
      expect(response.body.error).to.equal(code);
      await expectDocumentedResponse('/api/deliveries', 'post', response);
    }
    for (const resource of ['orders', 'deliveries']) {
      const response = await request(app).get(`/api/${resource}/${absent}`).expect(404);
      await expectDocumentedResponse(`/api/${resource}/{id}`, 'get', response);
    }
    await request(app).post('/api/deliveries').send({ orderId: absent, driverId: String(driver._id) }).expect(404);
  });
  it('exige entrega para avanzar y permite cancelar sin entrega', async () => {
    const order = await createOrder();
    expect((await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'assigned' }).expect(409)).body.error).to.equal('DELIVERY_REQUIRED');
    await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'cancelled' }).expect(200);
    const closed = await request(app).post('/api/deliveries').send({ orderId: order._id, driverId: String(driver._id) }).expect(409);
    expect(closed.body.error).to.equal('DELIVERY_ORDER_CLOSED');
    await expectDocumentedResponse('/api/deliveries', 'post', closed);
  });
  it('el índice único resuelve dos altas concurrentes de entrega', async () => {
    const order = await createOrder();
    const responses = await Promise.all([1, 2].map(() => request(app).post('/api/deliveries').send({ orderId: order._id, driverId: String(driver._id) })));
    expect(responses.map(r => r.status).sort()).to.deep.equal([201, 409]);
    for (const response of responses) await expectDocumentedResponse('/api/deliveries', 'post', response);
    expect(await Delivery.countDocuments({ orderId: order._id })).to.equal(1);
  });
  it('compare-and-set impide sobrescribir un estado modificado concurrentemente', async () => {
    const order = await createOrder();
    await createDelivery(order);
    const results = await Promise.all([
      orderRepository.changeStatus(order._id, 'pending', 'assigned'),
      orderRepository.changeStatus(order._id, 'pending', 'cancelled'),
    ]);
    expect(results.filter(Boolean)).to.have.length(1);
  });
  it('ignora estados antiguos en Delivery y no almacena una segunda copia nueva', async () => {
    const order = await createOrder(); const delivery = await createDelivery(order);
    const stored = await Delivery.collection.findOne({ orderId: new Order({ _id: order._id })._id });
    expect(stored).not.to.have.property('status');
    await Delivery.collection.updateOne({ _id: stored._id }, { $set: { status: 'delivered' } });
    expect((await request(app).get(`/api/deliveries/${delivery._id}`)).body.data.status).to.equal('pending');
  });
  it('rechaza saltos de estado sin cambiar la persistencia', async () => {
    const order = await createOrder(); const delivery = await createDelivery(order);
    const response = await request(app).patch(`/api/deliveries/${delivery._id}/status`).send({ status: 'delivered' }).expect(409);
    expect(response.body.error).to.equal('INVALID_STATUS_TRANSITION');
    expect((await Order.findById(order._id)).status).to.equal('pending');
  });
});
