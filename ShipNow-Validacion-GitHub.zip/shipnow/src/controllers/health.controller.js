import { health } from '../services/health.service.js';
export async function get(req, res, next) {
  try { res.json({ status: 'success', data: await health() }); } catch (error) { next(error); }
}
