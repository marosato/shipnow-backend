import * as service from '../services/document.service.js';
import { AppError } from '../errors/app-error.js';
import { ERRORS } from '../errors/error-catalog.js';
export function documentController(type, directory) {
  return {
    async checkOwner(req, res, next) {
      try { await service.owner(type, req.params.id); next(); } catch (error) { next(error); }
    },
    async create(req, res, next) {
      try { res.status(201).json({ status: 'success', data: await service.create(type, req.params.id, req.file, directory) }); }
      catch (error) { next(error); }
    },
    async list(req, res, next) {
      try { res.json({ status: 'success', data: await service.list(type, req.params.id, req.query) }); }
      catch (error) { next(error); }
    },
    async download(req, res, next) {
      try {
        const file = await service.download(type, req.params.id, req.params.documentId, directory);
        res.set('X-Content-Type-Options', 'nosniff');
        res.download(file.path, file.name, error => {
          if (error) next(error.code === 'ENOENT' ? new AppError(ERRORS.DOCUMENT_NOT_FOUND) : error);
        });
      } catch (error) { next(error); }
    },
  };
}
