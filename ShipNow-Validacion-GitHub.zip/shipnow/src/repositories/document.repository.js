import Document from '../models/document.model.js';
export function initialize() { return Document.init(); }
export function create(data) { return Document.create(data); }
export function list(ownerType, ownerId, { skip, limit }) {
  return Document.find({ ownerType, ownerId }).select('-storageKey').sort({ _id: 1 }).skip(skip).limit(limit).lean().exec();
}
export function find(id, ownerType, ownerId) {
  return Document.findOne({ _id: id, ownerType, ownerId }).lean().exec();
}
