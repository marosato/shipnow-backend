import Order from '../models/order.model.js';

export async function initialize() { await Order.init(); }

export function insertMany(documents) {
  return Order.insertMany(documents, { ordered: true });
}

export function deleteMockBatch(batchId) {
  // Solo datos identificados con el UUID de este lote; nunca borra una colección.
  return Order.deleteMany({ mockBatchId: batchId }).exec();
}

const fields = '_id userId address items total status priority createdAt updatedAt';
const active = { deletedAt: null };
export function findAll({ limit, skip }) {
  return Order.find(active).select(fields).sort({ _id: 1 }).skip(skip).limit(limit).lean().exec();
}
export function findById(id) { return Order.findOne({ _id: id, ...active }).select(fields).lean().exec(); }
export async function create(data) {
  const document = await Order.create({ ...data, tracking: [{ status: data.status, at: new Date() }] });
  return findById(document._id);
}
export function changeStatus(id, expectedStatus, status) {
  // Compare-and-set: un cambio concurrente nunca se sobreescribe a ciegas.
  return Order.findOneAndUpdate({ _id: id, status: expectedStatus, ...active }, { $set: { status }, $push: { tracking: { status, at: new Date() } } },
    { new: true, runValidators: true }).select(fields).lean().exec();
}

export function updatePending(id, data) {
  return Order.findOneAndUpdate({ _id: id, status: 'pending', ...active }, { $set: data },
    { new: true, runValidators: true }).select(fields).lean().exec();
}
export function remove(id) {
  const at = new Date();
  return Order.findOneAndUpdate({ _id: id, status: { $in: ['pending', 'cancelled'] }, ...active },
    { $set: { deletedAt: at, status: 'cancelled' }, $push: { tracking: { status: 'cancelled', at } } },
    { new: true, runValidators: true }).select(fields).lean().exec();
}
export function tracking(id) {
  return Order.findOne({ _id: id, ...active }).select('_id status tracking createdAt').lean().exec();
}
