import { Types } from 'mongoose';
import Order from '../models/order.model.js';
import Delivery from '../models/delivery.model.js';

export async function initialize() { await Delivery.init(); }

export function insertMany(documents) {
  return Delivery.insertMany(documents.map(({ status, ...document }) => document), { ordered: true });
}

export function deleteMockBatch(batchId) {
  // Solo datos identificados con el UUID de este lote; nunca borra una colección.
  return Delivery.deleteMany({ mockBatchId: batchId }).exec();
}

// El estado se lee del pedido; los antiguos campos delivery.status se ignoran.
// No se requieren migraciones ni dos escrituras para cambiar un estado.
const publicStages = [
  { $lookup: { from: Order.collection.name, localField: 'orderId', foreignField: '_id', as: 'order' } },
  { $unwind: '$order' },
  { $match: { 'order.deletedAt': null } },
  { $project: { _id: 1, orderId: 1, driverId: { $ifNull: ['$order.driverId', '$driverId'] }, priority: '$order.priority',
    status: '$order.status', createdAt: 1, updatedAt: '$order.updatedAt' } },
];
export function findAll({ limit, skip }) {
  return Delivery.aggregate([{ $sort: { _id: 1 } }, ...publicStages, { $skip: skip }, { $limit: limit }]).exec();
}
export async function findById(id) {
  const results = await Delivery.aggregate([{ $match: { _id: new Types.ObjectId(id) } }, ...publicStages]).exec();
  return results[0] ?? null;
}
export async function findByOrderId(orderId) {
  const results = await Delivery.aggregate([{ $match: { orderId: new Types.ObjectId(orderId) } }, ...publicStages]).exec();
  return results[0] ?? null;
}
export async function create(data) {
  const document = await Delivery.create(data);
  const result = await findById(document._id);
  if (!result || ['delivered', 'cancelled'].includes(result.status)) {
    await Delivery.deleteOne({ _id: document._id });
    return null;
  }
  return result;
}
