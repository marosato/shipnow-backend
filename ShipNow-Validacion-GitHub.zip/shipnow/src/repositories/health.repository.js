import mongoose from 'mongoose';
export async function ping() {
  if (mongoose.connection.readyState !== 1) return false;
  try { await mongoose.connection.db.admin().ping({ maxTimeMS: 2000 }); return true; }
  catch { return false; }
}
