import { validateEnv } from './env.config.js';
export function testConfig(source = process.env) {
  const mongodbUri = source.TEST_MONGODB_URI ?? 'mongodb://127.0.0.1:27017/shipnow_test';
  const config = validateEnv({ NODE_ENV: 'test', PORT: '8080', MONGODB_URI: mongodbUri });
  const database = new URL(mongodbUri).pathname.slice(1);
  if (!/^[a-zA-Z0-9_]+_test$/.test(database)) throw new Error('TEST_MONGODB_URI requiere una base con sufijo _test.');
  return config;
}
