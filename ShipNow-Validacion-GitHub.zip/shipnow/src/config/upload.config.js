import { fileURLToPath } from 'node:url';
export const UPLOAD_DIRECTORY = fileURLToPath(new URL('../../uploads/', import.meta.url));
export const MAX_FILE_SIZE = 5 * 1024 * 1024;
export const FILE_TYPES = Object.freeze({
  'application/pdf': Object.freeze(['.pdf']),
  'image/jpeg': Object.freeze(['.jpg', '.jpeg']),
  'image/png': Object.freeze(['.png']),
});
