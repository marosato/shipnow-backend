import { loadConfig } from '../config/env.config.js';
import { connectDatabase, disconnectDatabase } from '../config/db.config.js';
import * as users from '../repositories/user.repository.js';
import { requiredText } from '../services/validation.js';
// Operación administrativa local; no habilita altas de roles por HTTP sin autenticación.
try {
  const [nameInput, emailInput, ...extra] = process.argv.slice(2);
  if (extra.length) throw new Error('Argumentos inválidos.');
  const name = requiredText(nameInput, 'name', 120);
  const email = requiredText(emailInput, 'email', 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Email inválido.');
  const config = loadConfig();
  await connectDatabase(config.mongodbUri);
  await users.initialize();
  const driver = await users.create({ name, email, role: 'driver' });
  console.log(JSON.stringify({ id: String(driver._id), role: driver.role }));
} catch {
  console.error('No se creó el repartidor. Revisar conexión, email único y uso: npm run driver:create -- "Nombre" "email@example.com"');
  process.exitCode = 1;
} finally { await disconnectDatabase(); }
