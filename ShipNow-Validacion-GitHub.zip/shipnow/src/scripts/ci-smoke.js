import assert from 'node:assert/strict';

const base = 'http://127.0.0.1:8080';
async function request(path, status = 200) {
  const response = await fetch(`${base}${path}`, { signal: AbortSignal.timeout(10000) });
  assert.equal(response.status, status, `${path}: HTTP inesperado`);
  return response;
}

const health = await (await request('/api/health')).json();
assert.deepEqual(health, { status: 'success', data: { api: 'up', database: 'up' } });
const spec = await (await request('/api/docs/openapi.json')).json();
for (const resource of ['orders', 'deliveries']) {
  assert.ok(spec.paths[`/api/${resource}`]?.get, `${resource}: falta GET`);
  assert.ok(spec.paths[`/api/${resource}`]?.post, `${resource}: falta POST`);
  await request(`/api/${resource}`);
}
assert.match(await (await request('/api/docs/')).text(), /swagger-ui/i);
for (const path of ['/loggerTest', '/api/mocks/dataset?qty=1']) {
  const body = await (await request(path, 404)).json();
  assert.equal(body.error, 'ROUTE_NOT_FOUND');
}
assert.ok(!Object.keys(spec.paths).some(path => path.includes('/mocks') || path.includes('loggerTest')));
console.log('OK: API y MongoDB saludables; Orders y Deliveries disponibles; Swagger operativo; rutas de prueba deshabilitadas.');
