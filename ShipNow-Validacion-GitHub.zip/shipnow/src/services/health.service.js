import { ping } from '../repositories/health.repository.js';
import { ERRORS } from '../errors/error-catalog.js';
import { AppError } from '../errors/app-error.js';
export async function health() {
  if (!await ping()) throw new AppError(ERRORS.DATABASE_UNAVAILABLE);
  return { api: 'up', database: 'up' };
}
