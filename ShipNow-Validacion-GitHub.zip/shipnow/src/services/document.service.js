import { mkdir, writeFile, unlink } from 'node:fs/promises';
import { basename, extname, join } from 'node:path';
import { randomUUID } from 'node:crypto';
import * as documents from '../repositories/document.repository.js';
import * as userService from './user.service.js';
import * as deliveryService from './delivery.service.js';
import { pagination, validateId } from './validation.js';
import { AppError } from '../errors/app-error.js';
import { ERRORS } from '../errors/error-catalog.js';
import { MAX_FILE_SIZE, FILE_TYPES } from '../config/upload.config.js';
import { logger } from '../config/logger.config.js';
export async function owner(type, id) {
  validateId(id);
  return type === 'user' ? userService.getById(id) : deliveryService.getById(id);
}
export function validateFile(file) {
  if (!file?.buffer?.length) throw new AppError(ERRORS.FILE_REQUIRED);
  if (file.buffer.length > MAX_FILE_SIZE) throw new AppError(ERRORS.FILE_TOO_LARGE);
  const b = file.buffer;
  const detected = b.subarray(0, 5).equals(Buffer.from('%PDF-')) ? 'application/pdf'
    : b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) ? 'image/png'
    : b.length >= 3 && b[0] === 255 && b[1] === 216 && b[2] === 255 ? 'image/jpeg' : null;
  if (!detected || detected !== file.mimetype || !FILE_TYPES[detected].includes(extname(file.originalname).toLowerCase())) {
    throw new AppError(ERRORS.INVALID_FILE_TYPE);
  }
}
export async function create(type, id, file, directory) {
  validateFile(file);
  await owner(type, id);
  const storageKey = randomUUID() + extname(file.originalname).toLowerCase();
  const path = join(directory, storageKey);
  await mkdir(directory, { recursive: true });
  await writeFile(path, file.buffer, { flag: 'wx' });
  let saved;
  try {
    saved = await documents.create({ ownerType: type, ownerId: id, storageKey,
      originalName: basename(file.originalname.replaceAll('\\', '/')).replace(/[\x00-\x1f\x7f]/g, '').slice(0, 180) || 'document',
      mimeType: file.mimetype, size: file.buffer.length });
  } catch (error) {
    try { await unlink(path); } catch { logger.error('UPLOAD_CLEANUP_FAILED', { storageKey }); }
    throw error;
  }
  logger.info('DOCUMENT_UPLOADED', { id: String(saved._id), ownerType: type, ownerId: id, size: saved.size });
  const { storageKey: hidden, ...result } = saved.toObject();
  return result;
}
export async function list(type, id, query) {
  const page = pagination(query);
  await owner(type, id);
  return documents.list(type, id, page);
}
export async function download(type, id, documentId, directory) {
  validateId(documentId);
  await owner(type, id);
  const document = await documents.find(documentId, type, id);
  if (!document) throw new AppError(ERRORS.DOCUMENT_NOT_FOUND);
  // Nunca usar un nombre o ruta recibida del cliente para acceder al disco.
  if (!/^[a-f0-9-]{36}\.(pdf|jpe?g|png)$/.test(document.storageKey)) throw new AppError(ERRORS.INTERNAL_ERROR);
  return { path: join(directory, document.storageKey), name: document.originalName };
}
