import { logger } from '../config/logger.config.js';
import { ERRORS } from '../errors/error-catalog.js';
import * as repository from '../repositories/product.repository.js';
import { PRODUCT_STATUS } from '../constants/index.js';
import { AppError } from '../errors/app-error.js';
import { pagination, requiredText, validateBody, validateId } from './validation.js';

export function list(query) {
  return repository.findAll(pagination(query));
}

export async function getById(id) {
  validateId(id);
  const product = await repository.findById(id);
  if (!product) throw new AppError(ERRORS.PRODUCT_NOT_FOUND);
  return product;
}

export async function create(body) {
  validateBody(body, ['name', 'price', 'stock']);
  const name = requiredText(body.name, 'name', 120);
  if (typeof body.price !== 'number' || !Number.isFinite(body.price) || body.price < 0) {
    throw new AppError(ERRORS.INVALID_PRICE);
  }
  if (!Number.isSafeInteger(body.stock) || body.stock < 0) {
    throw new AppError(ERRORS.INVALID_STOCK);
  }
  // Decisión de negocio: el cliente no puede imponer un estado incompatible con el stock.
  const status = body.stock > 0 ? PRODUCT_STATUS.AVAILABLE : PRODUCT_STATUS.OUT_OF_STOCK;
  const created = await repository.create({ name, price: body.price, stock: body.stock, status });
  logger.info('PRODUCT_CREATED', { id: String(created._id) });
  return created;
}
