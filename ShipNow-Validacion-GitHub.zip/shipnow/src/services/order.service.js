import * as orders from '../repositories/order.repository.js';
import * as users from '../repositories/user.repository.js';
import * as deliveries from '../repositories/delivery.repository.js';
import { ORDER_STATUS as S, DELIVERY_PRIORITY, USER_ROLES } from '../constants/index.js';
import { ERRORS } from '../errors/error-catalog.js';
import { AppError } from '../errors/app-error.js';
import { pagination, requiredText, validateBody, validateId } from './validation.js';
import { logger } from '../config/logger.config.js';

const transitions = Object.freeze({
  [S.PENDING]: [S.ASSIGNED, S.CANCELLED],
  [S.ASSIGNED]: [S.IN_TRANSIT, S.CANCELLED],
  [S.IN_TRANSIT]: [S.DELIVERED, S.CANCELLED],
  [S.DELIVERED]: [], [S.CANCELLED]: [],
});

export function validateOrderInput(body) {
  validateBody(body, ['userId', 'address', 'items', 'priority']);
  validateId(body.userId);
  const address = requiredText(body.address, 'address', 250);
  const priority = body.priority === undefined ? DELIVERY_PRIORITY.NORMAL : body.priority;
  if (!Object.values(DELIVERY_PRIORITY).includes(priority)) throw new AppError(ERRORS.INVALID_PRIORITY);
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 100) {
    throw new AppError(ERRORS.INVALID_ITEMS);
  }
  let totalCents = 0;
  const items = body.items.map(item => {
    validateBody(item, ['name', 'quantity', 'unitPrice']);
    const name = requiredText(item.name, 'name', 120);
    const { quantity, unitPrice } = item;
    if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 1000000
      || typeof unitPrice !== 'number' || !Number.isFinite(unitPrice) || unitPrice < 0
      || unitPrice > 1000000000 || Number(unitPrice.toFixed(2)) !== unitPrice) {
      throw new AppError(ERRORS.INVALID_ORDER_AMOUNT);
    }
    const subtotal = Math.round(unitPrice * 100) * quantity;
    totalCents += subtotal;
    if (!Number.isSafeInteger(totalCents) || totalCents > 100000000000000) {
      throw new AppError(ERRORS.INVALID_ORDER_AMOUNT);
    }
    return { name, quantity, unitPrice };
  });
  return { userId: body.userId, address, items, priority, status: S.PENDING, total: totalCents / 100 };
}

export function validateStatusBody(body) {
  validateBody(body, ['status']);
  if (!Object.values(S).includes(body.status)) throw new AppError(ERRORS.INVALID_STATUS);
  return body.status;
}

export function list(query) { return orders.findAll(pagination(query)); }
export async function getById(id) {
  validateId(id);
  const order = await orders.findById(id);
  if (!order) throw new AppError(ERRORS.ORDER_NOT_FOUND);
  return order;
}
export async function create(body) {
  const data = validateOrderInput(body);
  const user = await users.findById(data.userId);
  if (!user) throw new AppError(ERRORS.USER_NOT_FOUND);
  if (user.role !== USER_ROLES.USER) throw new AppError(ERRORS.INVALID_CUSTOMER);
  const created = await orders.create(data);
  logger.info('ORDER_CREATED', { id: String(created._id) });
  return created;
}
export async function changeStatus(id, body) {
  validateId(id);
  const status = validateStatusBody(body);
  const order = await getById(id);
  if (status === order.status) return order; // Repetir estado no genera otra escritura.
  if (!transitions[order.status]?.includes(status)) throw new AppError(ERRORS.INVALID_STATUS_TRANSITION);
  if (status !== S.CANCELLED) {
    const delivery = await deliveries.findByOrderId(id);
    if (!delivery?.driverId) throw new AppError(ERRORS.DELIVERY_REQUIRED);
    const driver = await users.findById(String(delivery.driverId));
    if (!driver) throw new AppError(ERRORS.DRIVER_NOT_FOUND);
    if (driver.role !== USER_ROLES.DRIVER) throw new AppError(ERRORS.INVALID_DRIVER);
  }
  const updated = await orders.changeStatus(id, order.status, status);
  if (!updated) throw new AppError(ERRORS.ORDER_CHANGED);
  logger.info('ORDER_STATUS_CHANGED', { id: String(updated._id), from: order.status, to: status });
  return updated;
}

export async function update(id, body) {
  validateId(id);
  validateBody(body, ['address', 'items', 'priority']);
  if (!Object.keys(body).length) throw new AppError(ERRORS.INVALID_BODY);
  const current = await getById(id);
  const validated = validateOrderInput({ userId: String(current.userId), address: current.address,
    items: current.items, priority: current.priority, ...body });
  const changes = Object.fromEntries(Object.keys(body).map(key => [key, validated[key]]));
  if (body.items !== undefined) changes.total = validated.total;
  const updated = await orders.updatePending(id, changes);
  if (!updated) throw new AppError(ERRORS.ORDER_NOT_EDITABLE);
  logger.info('ORDER_UPDATED', { id });
  return updated;
}
export async function remove(id) {
  await getById(id);
  const removed = await orders.remove(id);
  if (!removed) throw new AppError(ERRORS.ORDER_NOT_EDITABLE);
  logger.info('ORDER_DELETED', { id });
  return { id, deleted: true };
}
export async function tracking(id) {
  validateId(id);
  const order = await orders.tracking(id);
  if (!order) throw new AppError(ERRORS.ORDER_NOT_FOUND);
  // Los registros anteriores a esta versión carecen de historial, no se inventan transiciones.
  return { orderId: String(order._id), status: order.status, events: order.tracking ?? [] };
}
