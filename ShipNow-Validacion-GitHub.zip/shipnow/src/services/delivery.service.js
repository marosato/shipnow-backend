import * as orders from '../repositories/order.repository.js';
import * as deliveries from '../repositories/delivery.repository.js';
import * as users from '../repositories/user.repository.js';
import * as orderService from './order.service.js';
import { ORDER_STATUS, USER_ROLES } from '../constants/index.js';
import { ERRORS } from '../errors/error-catalog.js';
import { AppError } from '../errors/app-error.js';
import { pagination, validateBody, validateId } from './validation.js';
import { logger } from '../config/logger.config.js';

export function list(query) { return deliveries.findAll(pagination(query)); }
export async function getById(id) {
  validateId(id);
  const delivery = await deliveries.findById(id);
  if (!delivery) throw new AppError(ERRORS.DELIVERY_NOT_FOUND);
  return delivery;
}
export async function create(body) {
  validateBody(body, ['orderId', 'driverId']);
  validateId(body.orderId);
  validateId(body.driverId);
  const order = await orderService.getById(body.orderId);
  if ([ORDER_STATUS.DELIVERED, ORDER_STATUS.CANCELLED].includes(order.status)) {
    throw new AppError(ERRORS.DELIVERY_ORDER_CLOSED);
  }
  const driver = await users.findById(body.driverId);
  if (!driver) throw new AppError(ERRORS.DRIVER_NOT_FOUND);
  if (driver.role !== USER_ROLES.DRIVER) throw new AppError(ERRORS.INVALID_DRIVER);
  // El índice único orderId arbitra altas duplicadas, incluso concurrentes.
  const created = await deliveries.create({ orderId: order._id, driverId: driver._id, priority: order.priority });
  if (!created) throw new AppError(ERRORS.ORDER_CHANGED);
  logger.info('DELIVERY_CREATED', { id: String(created._id), orderId: String(order._id) });
  return created;
}
export async function changeStatus(id, body) {
  validateId(id);
  orderService.validateStatusBody(body);
  const delivery = await getById(id);
  const order = await orderService.changeStatus(String(delivery.orderId), body);
  // Devuelve el estado exacto de la escritura, sin una segunda lectura concurrente.
  return { ...delivery, status: order.status, updatedAt: order.updatedAt };
}

export async function update(id, body) {
  validateId(id);
  validateBody(body, ['driverId']);
  validateId(body.driverId);
  const delivery = await getById(id);
  const driver = await users.findById(body.driverId);
  if (!driver) throw new AppError(ERRORS.DRIVER_NOT_FOUND);
  if (driver.role !== USER_ROLES.DRIVER) throw new AppError(ERRORS.INVALID_DRIVER);
  const updated = await orders.updatePending(delivery.orderId, { driverId: driver._id });
  if (!updated) throw new AppError(ERRORS.ORDER_NOT_EDITABLE);
  logger.info('DELIVERY_UPDATED', { id });
  return { ...delivery, driverId: driver._id, updatedAt: updated.updatedAt };
}
export async function remove(id) {
  const delivery = await getById(id);
  await orderService.remove(String(delivery.orderId));
  return { id, deleted: true };
}
export async function tracking(id) {
  const delivery = await getById(id);
  return { deliveryId: id, ...await orderService.tracking(String(delivery.orderId)) };
}
