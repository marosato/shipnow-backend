# Código del Módulo 5 — versión 0.5.1

Estado actual de runtime, schemas y pruebas. Incluye Orders y Deliveries; base e581a5a. Las evidencias de ejecución están en VERIFICACION.md.

## package.json

```json
{
  "name": "shipnow-backend",
  "version": "0.5.1",
  "private": true,
  "type": "module",
  "description": "Backend III - M\u00f3dulos 1 a 5",
  "engines": {
    "node": ">=24 <25"
  },
  "scripts": {
    "start": "node src/server.js",
    "dev": "node --watch src/server.js",
    "test": "mocha --timeout 10000 \"tests/**/*.test.js\"",
    "test:integration": "mocha --no-parallel --require ./tests/integration.setup.js --timeout 15000 \"tests/*mongodb.js\""
  },
  "dependencies": {
    "@faker-js/faker": "10.6.0",
    "dotenv": "17.4.2",
    "express": "5.2.1",
    "mongoose": "9.10.1",
    "swagger-jsdoc": "6.3.0",
    "swagger-ui-express": "5.0.1",
    "winston": "3.19.0",
    "winston-daily-rotate-file": "5.0.0"
  },
  "devDependencies": {
    "@apidevtools/swagger-parser": "13.1.0",
    "ajv": "8.20.0",
    "ajv-formats": "3.0.1",
    "chai": "6.2.2",
    "mocha": "12.0.1",
    "supertest": "7.2.2"
  }
}
```

## src/app.js

```javascript
import ordersRouter from './routes/orders.router.js';
import deliveriesRouter from './routes/deliveries.router.js';
import { createDocsRouter } from './routes/docs.router.js';
import loggerRouter from './routes/logger.router.js';
import { requestLogger } from './middlewares/request-logger.js';
import { ERRORS } from './errors/error-catalog.js';
import express from 'express';
import usersRouter from './routes/users.router.js';
import productsRouter from './routes/products.router.js';
import mocksRouter from './routes/mocks.router.js';
import { AppError } from './errors/app-error.js';
import { errorHandler } from './middlewares/error-handler.js';

export function createApp({ mocksEnabled = false, loggerTestEnabled = false, port = 8080 } = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.use(requestLogger);
  app.use(express.json({ limit: '100kb' }));
  if (loggerTestEnabled) app.use(loggerRouter);
  // Guardar el prefijo antes de que Express lo restaure al derivar un error.
  const mount = (path, router) => app.use(path, (req, res, next) => {
    res.locals.logBase = path;
    next();
  }, router);
  mount('/api/docs', createDocsRouter({ mocksEnabled, loggerTestEnabled, port }));
  mount('/api/orders', ordersRouter);
  mount('/api/deliveries', deliveriesRouter);
  mount('/api/users', usersRouter);
  mount('/api/products', productsRouter);
  if (mocksEnabled) mount('/api/mocks', mocksRouter);
  app.use((req, res, next) => next(new AppError(ERRORS.ROUTE_NOT_FOUND)));
  app.use(errorHandler);
  return app;
}

export default createApp();
```

## src/config/db.config.js

```javascript
import { logger } from './logger.config.js';
import mongoose from 'mongoose';

export async function connectDatabase(uri) {
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000, bufferCommands: false });
    logger.info('MONGODB_CONNECTED');
  } catch (error) {
    logger.error('MONGODB_CONNECTION_FAILED');
    throw error;
  }
}

export async function disconnectDatabase() {
  const wasOpen = mongoose.connection.readyState !== 0;
  await mongoose.disconnect();
  if (wasOpen) logger.info('MONGODB_DISCONNECTED');
}
```

## src/config/env.config.js

```javascript
import dotenv from 'dotenv';

// Único módulo autorizado para leer process.env.
export function validateEnv(source) {
  for (const key of ['PORT', 'NODE_ENV', 'MONGODB_URI']) {
    if (typeof source[key] !== 'string' || !source[key].trim()) {
      throw new Error(`Configuración inválida: falta ${key}.`);
    }
  }
  const portText = source.PORT.trim();
  const port = Number(portText);
  if (!/^\d+$/.test(portText) || !Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('Configuración inválida: PORT debe ser un entero entre 1 y 65535.');
  }
  const nodeEnv = source.NODE_ENV.trim();
  if (!['development', 'test', 'production'].includes(nodeEnv)) {
    throw new Error('Configuración inválida: NODE_ENV debe ser development, test o production.');
  }
  const mongodbUri = source.MONGODB_URI.trim();
  if (!/^mongodb(?:\+srv)?:\/\/[^\s]+$/.test(mongodbUri)) {
    throw new Error('Configuración inválida: MONGODB_URI debe ser una URI MongoDB.');
  }
  const flag = source.ENABLE_MOCKS ?? 'false';
  if (!['true', 'false'].includes(flag)) {
    throw new Error('Configuración inválida: ENABLE_MOCKS debe ser true o false.');
  }
  const loggerFlag = source.ENABLE_LOGGER_TEST ?? 'false';
  if (!['true', 'false'].includes(loggerFlag)) {
    throw new Error('Configuración inválida: ENABLE_LOGGER_TEST debe ser true o false.');
  }
  return Object.freeze({ loggerTestEnabled: loggerFlag === 'true' && nodeEnv !== 'production', port, nodeEnv, mongodbUri,
    mocksEnabled: flag === 'true' && nodeEnv !== 'production' });
}

export function loadConfig() {
  dotenv.config({ quiet: true });
  return validateEnv(process.env);
}
```

## src/config/logger.config.js

```javascript
import winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import { mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

export const LOG_LEVELS = Object.freeze({ fatal: 0, error: 1, warning: 2, info: 3, http: 4, debug: 5 });
export const LOG_POLICY = Object.freeze({ maxsize: '5m', maxFiles: 5 });
export const LOG_DIRECTORY = fileURLToPath(new URL('../../logs/', import.meta.url));

function options({ nodeEnv = 'test', silent = false, files = true,
  directory = LOG_DIRECTORY, maxsize = LOG_POLICY.maxsize,
  maxFiles = LOG_POLICY.maxFiles, consoleStream } = {}) {
  const consoleLevel = nodeEnv === 'development' ? 'debug' : 'info';
  const outputs = [consoleStream
    ? new winston.transports.Stream({ stream: consoleStream, level: consoleLevel })
    : new winston.transports.Console({ level: consoleLevel })];
  if (files) {
    mkdirSync(directory, { recursive: true });
    outputs.push(new DailyRotateFile({ dirname: directory, filename: 'error-%DATE%.log',
      datePattern: 'YYYY-MM-DD', utc: true, level: 'error', maxSize: maxsize, maxFiles,
      auditFile: join(directory, 'rotation-audit.json') }));
  }
  return { levels: LOG_LEVELS, level: 'debug', silent,
    format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
    transports: outputs, exitOnError: false };
}

function handleTransportError() {
  // Último recurso centralizado: no intentar registrar un fallo del logger en sí mismo.
  process.stderr.write('LOGGER_FAILURE: no se pudo escribir un registro.\n');
}

export function createLogger(config) {
  const instance = winston.createLogger(options(config));
  instance.on('error', handleTransportError);
  return instance;
}

// Importar app/services en tests no abre archivos ni carga el entorno.
export const logger = createLogger({ silent: true, files: false });

export function configureLogger(config) {
  let configuration;
  try { configuration = options(config); }
  catch (error) {
    logger.configure(options({ nodeEnv: 'production', files: false }));
    logger.fatal('LOGGER_SETUP_FAILED');
    throw error;
  }
  for (const transport of logger.transports) transport.close?.();
  logger.configure(configuration);
  return logger;
}

export function closeLogger(instance = logger) {
  // Winston puede desasociar transports antes de emitir finish.
  // Conservarlos antes de end evita perder la referencia al archivo pendiente.
  const fileTransports = instance.transports.filter(t => t instanceof DailyRotateFile);
  return new Promise((resolve, reject) => {
    instance.once('finish', () => {
      // finish del logger/transport no garantiza que fs.WriteStream haya terminado.
      // Esperar el callback del flujo de archivo; end admite callbacks posteriores.
      const pending = fileTransports.map(transport => new Promise((done, fail) => {
        transport.logStream.end(error => error ? fail(error) : done());
      }));
      Promise.all(pending).then(() => {
        instance.close();
        resolve();
      }, reject);
    });
    instance.end();
  });
}
```

## src/constants/index.js

```javascript
export const USER_ROLES = Object.freeze({ ADMIN: 'admin', USER: 'user', DRIVER: 'driver' });
export const PRODUCT_STATUS = Object.freeze({ AVAILABLE: 'available', OUT_OF_STOCK: 'out_of_stock' });

export const ORDER_STATUS = Object.freeze({
  PENDING: 'pending', ASSIGNED: 'assigned', IN_TRANSIT: 'in_transit',
  DELIVERED: 'delivered', CANCELLED: 'cancelled',
});
export const DELIVERY_PRIORITY = Object.freeze({ LOW: 'low', NORMAL: 'normal', HIGH: 'high' });
export const MOCK_LIMITS = Object.freeze({ DEFAULT_QTY: 10, MAX_QTY: 100 });
```

## src/controllers/delivery.controller.js

```javascript
import * as service from '../services/delivery.service.js';

export async function list(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.list(req.query) }); }
  catch (error) { next(error); }
}
export async function getById(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.getById(req.params.id) }); }
  catch (error) { next(error); }
}
export async function create(req, res, next) {
  try { res.status(201).json({ status: 'success', data: await service.create(req.body) }); }
  catch (error) { next(error); }
}
export async function changeStatus(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.changeStatus(req.params.id, req.body) }); }
  catch (error) { next(error); }
}
```

## src/controllers/logger.controller.js

```javascript
import { generateTestLogs } from '../services/logger.service.js';

export function test(req, res, next) {
  try { res.status(200).json({ status: 'success', data: generateTestLogs() }); }
  catch (error) { next(error); }
}
```

## src/controllers/mock.controller.js

```javascript
import { mockService } from '../services/mock.service.js';

export async function dataset(req, res, next) {
  try { res.status(200).json({ status: 'success', data: mockService.preview(req.query) }); }
  catch (error) { next(error); }
}

export async function users(req, res, next) {
  try { res.status(200).json({ status: 'success', data: mockService.preview(req.query).users }); }
  catch (error) { next(error); }
}

export async function seed(req, res, next) {
  try { res.status(201).json({ status: 'success', data: await mockService.seed(req.body, req.query) }); }
  catch (error) { next(error); }
}
```

## src/controllers/order.controller.js

```javascript
import * as service from '../services/order.service.js';

export async function list(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.list(req.query) }); }
  catch (error) { next(error); }
}
export async function getById(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.getById(req.params.id) }); }
  catch (error) { next(error); }
}
export async function create(req, res, next) {
  try { res.status(201).json({ status: 'success', data: await service.create(req.body) }); }
  catch (error) { next(error); }
}
export async function changeStatus(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.changeStatus(req.params.id, req.body) }); }
  catch (error) { next(error); }
}
```

## src/controllers/product.controller.js

```javascript
import * as service from '../services/product.service.js';

export async function list(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.list(req.query) }); }
  catch (error) { next(error); }
}

export async function getById(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.getById(req.params.id) }); }
  catch (error) { next(error); }
}

export async function create(req, res, next) {
  try { res.status(201).json({ status: 'success', data: await service.create(req.body) }); }
  catch (error) { next(error); }
}
```

## src/controllers/user.controller.js

```javascript
import * as service from '../services/user.service.js';

export async function list(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.list(req.query) }); }
  catch (error) { next(error); }
}

export async function getById(req, res, next) {
  try { res.status(200).json({ status: 'success', data: await service.getById(req.params.id) }); }
  catch (error) { next(error); }
}

export async function create(req, res, next) {
  try { res.status(201).json({ status: 'success', data: await service.create(req.body) }); }
  catch (error) { next(error); }
}
```

## src/docs/deliveries.yaml

```yaml
paths:
  /api/deliveries:
    get:
      tags:
      - Deliveries
      operationId: listDeliveries
      summary: listDeliveries
      description: Paginación page/limit, orden _id ascendente. data es array sin
        total.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DeliveriesResponse'
        '400':
          description: 'INVALID_QUERY. INVALID_PAGINATION. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_QUERY'
                - $ref: '#/components/schemas/Error_INVALID_PAGINATION'
              examples:
                INVALID_QUERY:
                  $ref: '#/components/examples/INVALID_QUERY'
                INVALID_PAGINATION:
                  $ref: '#/components/examples/INVALID_PAGINATION'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Page'
      - $ref: '#/components/parameters/Limit'
    post:
      tags:
      - Deliveries
      operationId: createDelivery
      summary: createDelivery
      description: 'Crea una entrega por pedido y requiere usuario driver. Hereda
        prioridad; el estado se lee del pedido, sin avanzar automáticamente. No admite
        status/priority. El índice único rechaza duplicados. No hay endpoint de elevación
        de roles: para pruebas obtener driver de seed. Si el pedido se cancela concurrentemente,
        la entrega refleja cancelled.'
      responses:
        '201':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DeliveryResponse'
        '400':
          description: 'INVALID_BODY. INVALID_ID. INVALID_JSON. INVALID_DATA. INVALID_DRIVER. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_BODY'
                - $ref: '#/components/schemas/Error_INVALID_ID'
                - $ref: '#/components/schemas/Error_INVALID_JSON'
                - $ref: '#/components/schemas/Error_INVALID_DATA'
                - $ref: '#/components/schemas/Error_INVALID_DRIVER'
              examples:
                INVALID_BODY:
                  $ref: '#/components/examples/INVALID_BODY'
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
                INVALID_JSON:
                  $ref: '#/components/examples/INVALID_JSON'
                INVALID_DATA:
                  $ref: '#/components/examples/INVALID_DATA'
                INVALID_DRIVER:
                  $ref: '#/components/examples/INVALID_DRIVER'
        '413':
          description: 'PAYLOAD_TOO_LARGE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PAYLOAD_TOO_LARGE'
              examples:
                PAYLOAD_TOO_LARGE:
                  $ref: '#/components/examples/PAYLOAD_TOO_LARGE'
        '404':
          description: 'ORDER_NOT_FOUND. DRIVER_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_ORDER_NOT_FOUND'
                - $ref: '#/components/schemas/Error_DRIVER_NOT_FOUND'
              examples:
                ORDER_NOT_FOUND:
                  $ref: '#/components/examples/ORDER_NOT_FOUND'
                DRIVER_NOT_FOUND:
                  $ref: '#/components/examples/DRIVER_NOT_FOUND'
        '409':
          description: 'DELIVERY_ORDER_CLOSED. DUPLICATE_RESOURCE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_DELIVERY_ORDER_CLOSED'
                - $ref: '#/components/schemas/Error_DUPLICATE_RESOURCE'
              examples:
                DELIVERY_ORDER_CLOSED:
                  $ref: '#/components/examples/DELIVERY_ORDER_CLOSED'
                DUPLICATE_RESOURCE:
                  $ref: '#/components/examples/DUPLICATE_RESOURCE'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/DeliveryInput'
        description: JSON con campos permitidos; máximo 100 KiB.
  /api/deliveries/{id}:
    get:
      tags:
      - Deliveries
      operationId: getDelivery
      summary: getDelivery
      description: Consulta por ID.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DeliveryResponse'
        '400':
          description: 'INVALID_ID. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_ID'
              examples:
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
        '404':
          description: 'DELIVERY_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_DELIVERY_NOT_FOUND'
              examples:
                DELIVERY_NOT_FOUND:
                  $ref: '#/components/examples/DELIVERY_NOT_FOUND'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Id'
  /api/deliveries/{id}/status:
    patch:
      tags:
      - Deliveries
      operationId: changeDeliveryStatus
      summary: changeDeliveryStatus
      description: 'Estado único en Order, visible por ambos endpoints. pending →
        assigned → in_transit → delivered; cancelación desde cualquier estado no terminal.
        Repetir estado es idempotente. Avanzar requiere entrega con driver. Escritura
        compare-and-set: conflicto concurrente 409. No se permiten retrocesos ni salir
        de delivered/cancelled.'
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DeliveryResponse'
        '400':
          description: 'INVALID_BODY. INVALID_ID. INVALID_JSON. INVALID_DATA. INVALID_STATUS.
            INVALID_DRIVER. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_BODY'
                - $ref: '#/components/schemas/Error_INVALID_ID'
                - $ref: '#/components/schemas/Error_INVALID_JSON'
                - $ref: '#/components/schemas/Error_INVALID_DATA'
                - $ref: '#/components/schemas/Error_INVALID_STATUS'
                - $ref: '#/components/schemas/Error_INVALID_DRIVER'
              examples:
                INVALID_BODY:
                  $ref: '#/components/examples/INVALID_BODY'
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
                INVALID_JSON:
                  $ref: '#/components/examples/INVALID_JSON'
                INVALID_DATA:
                  $ref: '#/components/examples/INVALID_DATA'
                INVALID_STATUS:
                  $ref: '#/components/examples/INVALID_STATUS'
                INVALID_DRIVER:
                  $ref: '#/components/examples/INVALID_DRIVER'
        '413':
          description: 'PAYLOAD_TOO_LARGE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PAYLOAD_TOO_LARGE'
              examples:
                PAYLOAD_TOO_LARGE:
                  $ref: '#/components/examples/PAYLOAD_TOO_LARGE'
        '404':
          description: 'DELIVERY_NOT_FOUND. ORDER_NOT_FOUND. DRIVER_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_DELIVERY_NOT_FOUND'
                - $ref: '#/components/schemas/Error_ORDER_NOT_FOUND'
                - $ref: '#/components/schemas/Error_DRIVER_NOT_FOUND'
              examples:
                DELIVERY_NOT_FOUND:
                  $ref: '#/components/examples/DELIVERY_NOT_FOUND'
                ORDER_NOT_FOUND:
                  $ref: '#/components/examples/ORDER_NOT_FOUND'
                DRIVER_NOT_FOUND:
                  $ref: '#/components/examples/DRIVER_NOT_FOUND'
        '409':
          description: 'INVALID_STATUS_TRANSITION. DELIVERY_REQUIRED. ORDER_CHANGED. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_STATUS_TRANSITION'
                - $ref: '#/components/schemas/Error_DELIVERY_REQUIRED'
                - $ref: '#/components/schemas/Error_ORDER_CHANGED'
              examples:
                INVALID_STATUS_TRANSITION:
                  $ref: '#/components/examples/INVALID_STATUS_TRANSITION'
                DELIVERY_REQUIRED:
                  $ref: '#/components/examples/DELIVERY_REQUIRED'
                ORDER_CHANGED:
                  $ref: '#/components/examples/ORDER_CHANGED'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/StatusInput'
        description: JSON con campos permitidos; máximo 100 KiB.
      parameters:
      - $ref: '#/components/parameters/Id'
```

## src/docs/logger.yaml

```yaml
paths:
  /loggerTest:
    get:
      tags:
      - Logger
      operationId: testLogger
      summary: Emitir seis niveles de prueba
      description: 'Herramienta local de validación, no operación de negocio. ENABLE_LOGGER_TEST=true
        fuera de production. Emite eventos simulated=true; fatal no detiene el servidor. Consola development:
        seis niveles. Archivo: error/fatal; escritura asíncrona.'
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/LoggerResponse'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
```

## src/docs/mocks.yaml

```yaml
paths:
  /api/mocks/dataset:
    get:
      tags:
      - Mocks
      - Orders
      - Deliveries
      operationId: previewDataset
      summary: Generar lote sin persistir
      description: Disponible con ENABLE_MOCKS=true fuera de production. Genera qty usuarios, repartidores,
        pedidos y entregas; 4 × qty documentos. No guarda en MongoDB. IDs y relaciones coherentes dentro
        del lote.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DatasetResponse'
        '400':
          description: 'INVALID_QUERY. INVALID_MOCK_AMOUNT. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_QUERY'
                - $ref: '#/components/schemas/Error_INVALID_MOCK_AMOUNT'
              examples:
                INVALID_QUERY:
                  $ref: '#/components/examples/INVALID_QUERY'
                INVALID_MOCK_AMOUNT:
                  $ref: '#/components/examples/INVALID_MOCK_AMOUNT'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Qty'
  /api/mocks/users:
    get:
      tags:
      - Mocks
      operationId: previewUsers
      summary: Generar usuarios sin persistir
      description: Disponible con ENABLE_MOCKS=true fuera de production. Devuelve un array de qty usuarios
        con role=user, sin timestamps.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/MockUsersResponse'
        '400':
          description: 'INVALID_QUERY. INVALID_MOCK_AMOUNT. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_QUERY'
                - $ref: '#/components/schemas/Error_INVALID_MOCK_AMOUNT'
              examples:
                INVALID_QUERY:
                  $ref: '#/components/examples/INVALID_QUERY'
                INVALID_MOCK_AMOUNT:
                  $ref: '#/components/examples/INVALID_MOCK_AMOUNT'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Qty'
  /api/mocks/seed:
    post:
      tags:
      - Mocks
      - Orders
      - Deliveries
      operationId: seedDataset
      summary: Insertar un lote de prueba
      description: 'MODIFICA MongoDB: inserta qty documentos por entidad (total 4 × qty). ENABLE_MOCKS=true
        fuera de production. qty va solo en JSON; cualquier query se rechaza. Cada petición agrega un
        lote nuevo; no es idempotente. Compensación por lote, sin transacción; si falla limpieza requiere
        revisión mediante logs. Usar base de desarrollo descartable.'
      responses:
        '201':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/SeedResponse'
        '400':
          description: 'INVALID_BODY. INVALID_MOCK_AMOUNT. INVALID_MOCK_INPUT. INVALID_JSON. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_BODY'
                - $ref: '#/components/schemas/Error_INVALID_MOCK_AMOUNT'
                - $ref: '#/components/schemas/Error_INVALID_MOCK_INPUT'
                - $ref: '#/components/schemas/Error_INVALID_JSON'
              examples:
                INVALID_BODY:
                  $ref: '#/components/examples/INVALID_BODY'
                INVALID_MOCK_AMOUNT:
                  $ref: '#/components/examples/INVALID_MOCK_AMOUNT'
                INVALID_MOCK_INPUT:
                  $ref: '#/components/examples/INVALID_MOCK_INPUT'
                INVALID_JSON:
                  $ref: '#/components/examples/INVALID_JSON'
        '413':
          description: 'PAYLOAD_TOO_LARGE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PAYLOAD_TOO_LARGE'
              examples:
                PAYLOAD_TOO_LARGE:
                  $ref: '#/components/examples/PAYLOAD_TOO_LARGE'
        '500':
          description: 'MOCK_LOAD_FAILED. MOCK_CLEANUP_FAILED. INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_MOCK_LOAD_FAILED'
                - $ref: '#/components/schemas/Error_MOCK_CLEANUP_FAILED'
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                MOCK_LOAD_FAILED:
                  $ref: '#/components/examples/MOCK_LOAD_FAILED'
                MOCK_CLEANUP_FAILED:
                  $ref: '#/components/examples/MOCK_CLEANUP_FAILED'
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      requestBody:
        required: true
        description: JSON; límite de 100 KiB. No se admiten campos adicionales.
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/MockSeedInput'
```

## src/docs/orders.yaml

```yaml
paths:
  /api/orders:
    get:
      tags:
      - Orders
      operationId: listOrders
      summary: listOrders
      description: Paginación page/limit, orden _id ascendente. data es array sin
        total.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/OrdersResponse'
        '400':
          description: 'INVALID_QUERY. INVALID_PAGINATION. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_QUERY'
                - $ref: '#/components/schemas/Error_INVALID_PAGINATION'
              examples:
                INVALID_QUERY:
                  $ref: '#/components/examples/INVALID_QUERY'
                INVALID_PAGINATION:
                  $ref: '#/components/examples/INVALID_PAGINATION'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Page'
      - $ref: '#/components/parameters/Limit'
    post:
      tags:
      - Orders
      operationId: createOrder
      summary: createOrder
      description: Crea pedido pending para usuario con rol user. Calcula total en
        centavos (máximo 1 billón); no acepta total/status. Los ítems son conceptos
        del pedido, no referencias al catálogo Products.
      responses:
        '201':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/OrderResponse'
        '400':
          description: 'INVALID_BODY. INVALID_ID. INVALID_JSON. INVALID_DATA. INVALID_TEXT.
            INVALID_ITEMS. INVALID_ORDER_AMOUNT. INVALID_PRIORITY. INVALID_CUSTOMER. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_BODY'
                - $ref: '#/components/schemas/Error_INVALID_ID'
                - $ref: '#/components/schemas/Error_INVALID_JSON'
                - $ref: '#/components/schemas/Error_INVALID_DATA'
                - $ref: '#/components/schemas/Error_INVALID_TEXT'
                - $ref: '#/components/schemas/Error_INVALID_ITEMS'
                - $ref: '#/components/schemas/Error_INVALID_ORDER_AMOUNT'
                - $ref: '#/components/schemas/Error_INVALID_PRIORITY'
                - $ref: '#/components/schemas/Error_INVALID_CUSTOMER'
              examples:
                INVALID_BODY:
                  $ref: '#/components/examples/INVALID_BODY'
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
                INVALID_JSON:
                  $ref: '#/components/examples/INVALID_JSON'
                INVALID_DATA:
                  $ref: '#/components/examples/INVALID_DATA'
                INVALID_TEXT:
                  $ref: '#/components/examples/INVALID_TEXT'
                INVALID_ITEMS:
                  $ref: '#/components/examples/INVALID_ITEMS'
                INVALID_ORDER_AMOUNT:
                  $ref: '#/components/examples/INVALID_ORDER_AMOUNT'
                INVALID_PRIORITY:
                  $ref: '#/components/examples/INVALID_PRIORITY'
                INVALID_CUSTOMER:
                  $ref: '#/components/examples/INVALID_CUSTOMER'
        '413':
          description: 'PAYLOAD_TOO_LARGE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PAYLOAD_TOO_LARGE'
              examples:
                PAYLOAD_TOO_LARGE:
                  $ref: '#/components/examples/PAYLOAD_TOO_LARGE'
        '404':
          description: 'USER_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_USER_NOT_FOUND'
              examples:
                USER_NOT_FOUND:
                  $ref: '#/components/examples/USER_NOT_FOUND'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/OrderInput'
        description: JSON con campos permitidos; máximo 100 KiB.
  /api/orders/{id}:
    get:
      tags:
      - Orders
      operationId: getOrder
      summary: getOrder
      description: Consulta por ID.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/OrderResponse'
        '400':
          description: 'INVALID_ID. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_ID'
              examples:
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
        '404':
          description: 'ORDER_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_ORDER_NOT_FOUND'
              examples:
                ORDER_NOT_FOUND:
                  $ref: '#/components/examples/ORDER_NOT_FOUND'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Id'
  /api/orders/{id}/status:
    patch:
      tags:
      - Orders
      operationId: changeOrderStatus
      summary: changeOrderStatus
      description: 'Estado único en Order, visible por ambos endpoints. pending →
        assigned → in_transit → delivered; cancelación desde cualquier estado no terminal.
        Repetir estado es idempotente. Avanzar requiere entrega con driver. Escritura
        compare-and-set: conflicto concurrente 409. No se permiten retrocesos ni salir
        de delivered/cancelled.'
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/OrderResponse'
        '400':
          description: 'INVALID_BODY. INVALID_ID. INVALID_JSON. INVALID_DATA. INVALID_STATUS.
            INVALID_DRIVER. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_BODY'
                - $ref: '#/components/schemas/Error_INVALID_ID'
                - $ref: '#/components/schemas/Error_INVALID_JSON'
                - $ref: '#/components/schemas/Error_INVALID_DATA'
                - $ref: '#/components/schemas/Error_INVALID_STATUS'
                - $ref: '#/components/schemas/Error_INVALID_DRIVER'
              examples:
                INVALID_BODY:
                  $ref: '#/components/examples/INVALID_BODY'
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
                INVALID_JSON:
                  $ref: '#/components/examples/INVALID_JSON'
                INVALID_DATA:
                  $ref: '#/components/examples/INVALID_DATA'
                INVALID_STATUS:
                  $ref: '#/components/examples/INVALID_STATUS'
                INVALID_DRIVER:
                  $ref: '#/components/examples/INVALID_DRIVER'
        '413':
          description: 'PAYLOAD_TOO_LARGE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PAYLOAD_TOO_LARGE'
              examples:
                PAYLOAD_TOO_LARGE:
                  $ref: '#/components/examples/PAYLOAD_TOO_LARGE'
        '404':
          description: 'ORDER_NOT_FOUND. DRIVER_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_ORDER_NOT_FOUND'
                - $ref: '#/components/schemas/Error_DRIVER_NOT_FOUND'
              examples:
                ORDER_NOT_FOUND:
                  $ref: '#/components/examples/ORDER_NOT_FOUND'
                DRIVER_NOT_FOUND:
                  $ref: '#/components/examples/DRIVER_NOT_FOUND'
        '409':
          description: 'INVALID_STATUS_TRANSITION. DELIVERY_REQUIRED. ORDER_CHANGED. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_STATUS_TRANSITION'
                - $ref: '#/components/schemas/Error_DELIVERY_REQUIRED'
                - $ref: '#/components/schemas/Error_ORDER_CHANGED'
              examples:
                INVALID_STATUS_TRANSITION:
                  $ref: '#/components/examples/INVALID_STATUS_TRANSITION'
                DELIVERY_REQUIRED:
                  $ref: '#/components/examples/DELIVERY_REQUIRED'
                ORDER_CHANGED:
                  $ref: '#/components/examples/ORDER_CHANGED'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/StatusInput'
        description: JSON con campos permitidos; máximo 100 KiB.
      parameters:
      - $ref: '#/components/parameters/Id'
```

## src/docs/products.yaml

```yaml
paths:
  /api/products:
    get:
      tags:
      - Products
      operationId: listProducts
      summary: Listar Products
      description: Lista ordenada por _id ascendente. data es un array sin total. Solo admite page y limit.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ProductsResponse'
        '400':
          description: 'INVALID_QUERY. INVALID_PAGINATION. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_QUERY'
                - $ref: '#/components/schemas/Error_INVALID_PAGINATION'
              examples:
                INVALID_QUERY:
                  $ref: '#/components/examples/INVALID_QUERY'
                INVALID_PAGINATION:
                  $ref: '#/components/examples/INVALID_PAGINATION'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Page'
      - $ref: '#/components/parameters/Limit'
    post:
      tags:
      - Products
      operationId: createProduct
      summary: Crear Product
      description: status se deriva del stock; no admite status. price y stock deben ser números JSON.
      responses:
        '201':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ProductResponse'
        '400':
          description: 'INVALID_BODY. INVALID_TEXT. INVALID_PRICE. INVALID_STOCK. INVALID_DATA. INVALID_JSON. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_BODY'
                - $ref: '#/components/schemas/Error_INVALID_TEXT'
                - $ref: '#/components/schemas/Error_INVALID_PRICE'
                - $ref: '#/components/schemas/Error_INVALID_STOCK'
                - $ref: '#/components/schemas/Error_INVALID_DATA'
                - $ref: '#/components/schemas/Error_INVALID_JSON'
              examples:
                INVALID_BODY:
                  $ref: '#/components/examples/INVALID_BODY'
                INVALID_TEXT:
                  $ref: '#/components/examples/INVALID_TEXT'
                INVALID_PRICE:
                  $ref: '#/components/examples/INVALID_PRICE'
                INVALID_STOCK:
                  $ref: '#/components/examples/INVALID_STOCK'
                INVALID_DATA:
                  $ref: '#/components/examples/INVALID_DATA'
                INVALID_JSON:
                  $ref: '#/components/examples/INVALID_JSON'
        '413':
          description: 'PAYLOAD_TOO_LARGE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PAYLOAD_TOO_LARGE'
              examples:
                PAYLOAD_TOO_LARGE:
                  $ref: '#/components/examples/PAYLOAD_TOO_LARGE'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      requestBody:
        required: true
        description: JSON; límite de 100 KiB. No se admiten campos adicionales.
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ProductInput'
  /api/products/{id}:
    get:
      tags:
      - Products
      operationId: getProduct
      summary: Consultar Product por ID
      description: Devuelve el recurso si existe.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ProductResponse'
        '400':
          description: 'INVALID_ID. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_ID'
              examples:
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
        '404':
          description: 'PRODUCT_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PRODUCT_NOT_FOUND'
              examples:
                PRODUCT_NOT_FOUND:
                  $ref: '#/components/examples/PRODUCT_NOT_FOUND'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Id'
```

## src/docs/schemas.yaml

```yaml
components:
  schemas:
    ObjectId:
      type: string
      pattern: ^[a-fA-F0-9]{24}$
      example: 507f1f77bcf86cd799439011
    SuccessResponse:
      type: object
      required:
      - status
      - data
      properties:
        status:
          type: string
          enum:
          - success
        data: {}
    User:
      type: object
      required:
      - _id
      - name
      - email
      - role
      - createdAt
      - updatedAt
      properties:
        _id:
          $ref: '#/components/schemas/ObjectId'
        name:
          type: string
          minLength: 1
          maxLength: 120
        email:
          type: string
        role:
          type: string
          enum:
          - admin
          - user
          - driver
        createdAt:
          type: string
          format: date-time
        updatedAt:
          type: string
          format: date-time
      additionalProperties: false
    Product:
      type: object
      required:
      - _id
      - name
      - price
      - stock
      - status
      - createdAt
      - updatedAt
      properties:
        _id:
          $ref: '#/components/schemas/ObjectId'
        name:
          type: string
          minLength: 1
          maxLength: 120
        price:
          type: number
          minimum: 0
        stock:
          type: integer
          minimum: 0
          maximum: 9007199254740991
        status:
          type: string
          enum:
          - available
          - out_of_stock
        createdAt:
          type: string
          format: date-time
        updatedAt:
          type: string
          format: date-time
      additionalProperties: false
    UserInput:
      type: object
      required:
      - name
      - email
      properties:
        name:
          type: string
          description: Texto no vacío luego de trim; máximo 120 caracteres después
            de normalizar.
          example: Ana Pérez
        email:
          type: string
          description: Texto; trim, minúsculas y validación de email. Máximo 254 después
            de trim. Debe ser único.
          example: ana@example.com
      additionalProperties: false
    ProductInput:
      type: object
      required:
      - name
      - price
      - stock
      properties:
        name:
          type: string
          description: Texto no vacío; máximo 120 caracteres después de trim.
          example: Caja mediana
        price:
          type: number
          minimum: 0
          example: 1500
        stock:
          type: integer
          minimum: 0
          maximum: 9007199254740991
          example: 3
      additionalProperties: false
    MockUser:
      type: object
      required:
      - _id
      - name
      - email
      - role
      - mockBatchId
      properties:
        _id:
          $ref: '#/components/schemas/ObjectId'
        name:
          type: string
          minLength: 1
          maxLength: 120
        email:
          type: string
        role:
          type: string
          enum:
          - user
          - driver
        mockBatchId:
          type: string
          format: uuid
      additionalProperties: false
    OrderItem:
      type: object
      required:
      - name
      - quantity
      - unitPrice
      properties:
        name:
          type: string
          minLength: 1
          maxLength: 120
        quantity:
          type: integer
          minimum: 1
          maximum: 9007199254740991
          example: 2
        unitPrice:
          type: number
          minimum: 0
          example: 1500
      additionalProperties: false
    Order:
      type: object
      required:
      - _id
      - userId
      - address
      - items
      - total
      - status
      - priority
      - createdAt
      - updatedAt
      properties:
        _id:
          $ref: '#/components/schemas/ObjectId'
        userId:
          $ref: '#/components/schemas/ObjectId'
        address:
          type: string
          maxLength: 250
        items:
          type: array
          items:
            $ref: '#/components/schemas/OrderItem'
          minItems: 1
        total:
          type: number
          minimum: 0
        status:
          type: string
          enum:
          - pending
          - assigned
          - in_transit
          - delivered
          - cancelled
        priority:
          type: string
          enum:
          - low
          - normal
          - high
        createdAt:
          type: string
          format: date-time
        updatedAt:
          type: string
          format: date-time
      additionalProperties: false
    Delivery:
      type: object
      required:
      - _id
      - orderId
      - driverId
      - status
      - priority
      - createdAt
      - updatedAt
      properties:
        _id:
          $ref: '#/components/schemas/ObjectId'
        orderId:
          $ref: '#/components/schemas/ObjectId'
        driverId:
          type: string
          pattern: ^[a-fA-F0-9]{24}$
          example: 507f1f77bcf86cd799439011
          nullable: true
          description: Repartidor asignado; null solo en mocks heredados sin repartidor.
        status:
          type: string
          enum:
          - pending
          - assigned
          - in_transit
          - delivered
          - cancelled
        priority:
          type: string
          enum:
          - low
          - normal
          - high
        createdAt:
          type: string
          format: date-time
        updatedAt:
          type: string
          format: date-time
      additionalProperties: false
      description: Estado derivado del pedido. updatedAt corresponde a los datos propios
        de la entrega, no al estado del pedido.
    MockDataset:
      type: object
      required:
      - batchId
      - users
      - drivers
      - orders
      - deliveries
      properties:
        batchId:
          type: string
          format: uuid
        users:
          type: array
          items:
            $ref: '#/components/schemas/MockUser'
        drivers:
          type: array
          items:
            $ref: '#/components/schemas/MockUser'
        orders:
          type: array
          items:
            $ref: '#/components/schemas/MockOrder'
        deliveries:
          type: array
          items:
            $ref: '#/components/schemas/MockDelivery'
      additionalProperties: false
    MockSeedInput:
      type: object
      required:
      - qty
      properties:
        qty:
          type: integer
          minimum: 1
          maximum: 100
          example: 2
      additionalProperties: false
    MockSeedResult:
      type: object
      required:
      - batchId
      - inserted
      - ids
      properties:
        batchId:
          type: string
          format: uuid
        inserted:
          type: object
          required:
          - users
          - drivers
          - orders
          - deliveries
          - total
          properties:
            users:
              type: integer
              minimum: 1
              maximum: 100
            drivers:
              type: integer
              minimum: 1
              maximum: 100
            orders:
              type: integer
              minimum: 1
              maximum: 100
            deliveries:
              type: integer
              minimum: 1
              maximum: 100
            total:
              type: integer
              minimum: 1
              maximum: 400
          additionalProperties: false
        ids:
          type: object
          required:
          - users
          - drivers
          - orders
          - deliveries
          properties:
            users:
              type: array
              items:
                $ref: '#/components/schemas/ObjectId'
            drivers:
              type: array
              items:
                $ref: '#/components/schemas/ObjectId'
            orders:
              type: array
              items:
                $ref: '#/components/schemas/ObjectId'
            deliveries:
              type: array
              items:
                $ref: '#/components/schemas/ObjectId'
          additionalProperties: false
      additionalProperties: false
    LoggerResult:
      type: object
      required:
      - message
      - levels
      properties:
        message:
          type: string
          enum:
          - Logs de prueba generados.
        levels:
          type: array
          items:
            type: string
            enum:
            - fatal
            - error
            - warning
            - info
            - http
            - debug
          minItems: 6
          maxItems: 6
          uniqueItems: true
      additionalProperties: false
    UserResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            $ref: '#/components/schemas/User'
    UsersResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            type: array
            items:
              $ref: '#/components/schemas/User'
    ProductResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            $ref: '#/components/schemas/Product'
    ProductsResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            type: array
            items:
              $ref: '#/components/schemas/Product'
    DatasetResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            $ref: '#/components/schemas/MockDataset'
    MockUsersResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            type: array
            items:
              $ref: '#/components/schemas/MockUser'
    SeedResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            $ref: '#/components/schemas/MockSeedResult'
    LoggerResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            $ref: '#/components/schemas/LoggerResult'
    MockOrder:
      type: object
      required:
      - _id
      - userId
      - address
      - items
      - total
      - status
      - priority
      - mockBatchId
      properties:
        _id:
          $ref: '#/components/schemas/ObjectId'
        userId:
          $ref: '#/components/schemas/ObjectId'
        address:
          type: string
          maxLength: 250
        items:
          type: array
          items:
            $ref: '#/components/schemas/OrderItem'
          minItems: 1
        total:
          type: number
          minimum: 0
        status:
          type: string
          enum:
          - pending
          - assigned
          - in_transit
          - delivered
          - cancelled
        priority:
          type: string
          enum:
          - low
          - normal
          - high
        mockBatchId:
          type: string
          format: uuid
      additionalProperties: false
      description: Vista previa de mocks sin timestamps.
    MockDelivery:
      type: object
      required:
      - _id
      - orderId
      - driverId
      - status
      - priority
      - mockBatchId
      properties:
        _id:
          $ref: '#/components/schemas/ObjectId'
        orderId:
          $ref: '#/components/schemas/ObjectId'
        driverId:
          type: string
          pattern: ^[a-fA-F0-9]{24}$
          example: 507f1f77bcf86cd799439011
          nullable: true
          description: null para pending/cancelled; ObjectId para los demás estados.
        status:
          type: string
          enum:
          - pending
          - assigned
          - in_transit
          - delivered
          - cancelled
        priority:
          type: string
          enum:
          - low
          - normal
          - high
        mockBatchId:
          type: string
          format: uuid
      additionalProperties: false
      description: Vista previa de mocks sin timestamps.
    OrderInput:
      type: object
      additionalProperties: false
      required:
      - userId
      - address
      - items
      properties:
        userId:
          $ref: '#/components/schemas/ObjectId'
        address:
          type: string
          example: Av. Siempre Viva 742
          description: Texto no vacío, hasta 250 caracteres después de trim.
        priority:
          type: string
          enum:
          - low
          - normal
          - high
          default: normal
        items:
          type: array
          minItems: 1
          maxItems: 100
          items:
            type: object
            additionalProperties: false
            required:
            - name
            - quantity
            - unitPrice
            properties:
              name:
                type: string
                example: Caja
                description: No vacío, máximo 120 tras trim.
              quantity:
                type: integer
                minimum: 1
                maximum: 1000000
                example: 2
              unitPrice:
                type: number
                minimum: 0
                maximum: 1000000000
                multipleOf: 0.01
                example: 1500
    DeliveryInput:
      type: object
      additionalProperties: false
      required:
      - orderId
      - driverId
      properties:
        orderId:
          $ref: '#/components/schemas/ObjectId'
        driverId:
          $ref: '#/components/schemas/ObjectId'
    StatusInput:
      type: object
      additionalProperties: false
      required:
      - status
      properties:
        status:
          type: string
          enum:
          - pending
          - assigned
          - in_transit
          - delivered
          - cancelled
          example: assigned
    OrderResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            $ref: '#/components/schemas/Order'
    OrdersResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            type: array
            items:
              $ref: '#/components/schemas/Order'
    DeliveryResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            $ref: '#/components/schemas/Delivery'
    DeliveriesResponse:
      allOf:
      - $ref: '#/components/schemas/SuccessResponse'
      - type: object
        properties:
          data:
            type: array
            items:
              $ref: '#/components/schemas/Delivery'
  parameters:
    Id:
      name: id
      in: path
      required: true
      description: Identificador hexadecimal de 24 caracteres.
      schema:
        $ref: '#/components/schemas/ObjectId'
    Page:
      name: page
      in: query
      description: Entero positivo, sin ceros iniciales ni repeticiones.
      schema:
        type: integer
        minimum: 1
        maximum: 1000000
        default: 1
    Limit:
      name: limit
      in: query
      description: Entero positivo, sin ceros iniciales ni repeticiones.
      schema:
        type: integer
        minimum: 1
        maximum: 100
        default: 20
    Qty:
      name: qty
      in: query
      description: Cantidad por entidad. Sin ceros iniciales ni repeticiones; no admite
        otros parámetros.
      schema:
        type: integer
        minimum: 1
        maximum: 100
        default: 10
```

## src/docs/swagger.config.js

```javascript
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import swaggerJSDoc from 'swagger-jsdoc';
import { ERRORS } from '../errors/error-catalog.js';

const { version } = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8'));

export function createSwaggerSpec({ mocksEnabled = false, loggerTestEnabled = false, port = 8080 } = {}) {
  const files = ['schemas', 'users', 'products', 'orders', 'deliveries'];
  if (mocksEnabled) files.push('mocks');
  if (loggerTestEnabled) files.push('logger');
  // El catálogo M3 es la fuente de ejemplos, códigos y mensajes públicos.
  const schemas = {
    ErrorResponse: {
      type: 'object', required: ['status', 'error', 'message'], additionalProperties: false,
      properties: {
        status: { type: 'string', enum: ['error'] },
        error: { type: 'string', enum: Object.keys(ERRORS) },
        message: { type: 'string' },
      },
    },
  };
  const examples = {};
  for (const { code, message } of Object.values(ERRORS)) {
    schemas[`Error_${code}`] = {
      allOf: [{ $ref: '#/components/schemas/ErrorResponse' }, {
        type: 'object', properties: { error: { type: 'string', enum: [code] } },
      }],
    };
    examples[code] = { value: { status: 'error', error: code, message } };
  }
  return swaggerJSDoc({
    failOnErrors: true,
    definition: {
      openapi: '3.0.3',
      info: {
        title: 'ShipNow API', version,
        description: 'API académica de logística. Users y Products: crear, listar y consultar. '
          + 'Orders y Deliveries: creación, listados, consulta y cambio de estado compartido. '
          + 'No hay autenticación implementada: no se documentan tokens ni errores 401/403 ficticios. '
          + 'La documentación muestra solo las rutas habilitadas. Si Mocks o Logger están apagados, sus rutas devuelven 404 ROUTE_NOT_FOUND. '
          + 'En producción se deshabilitan mediante la configuración validada. '
          + 'Los POST disponibles escriben datos: probar en una base de desarrollo. '
          + 'Todo cuerpo JSON está limitado a 100 KiB; JSON malformado devuelve 400 INVALID_JSON y exceso devuelve 413 PAYLOAD_TOO_LARGE, incluso antes del router.',
      },
      servers: [
        { url: '/', description: 'Servidor actual (conserva host y puerto del navegador)' },
        { url: `http://127.0.0.1:${port}`, description: 'Servidor local' },
      ],
      tags: [
        { name: 'Users', description: 'Usuarios; altas con rol user y email único.' },
        { name: 'Products', description: 'Productos; estado derivado del stock.' },
        { name: 'Orders', description: 'Pedidos con total calculado y transiciones validadas.' },
        { name: 'Deliveries', description: 'Entregas únicas por pedido; estado derivado del pedido.' },
        { name: 'Mocks', description: mocksEnabled ? 'Herramientas locales habilitadas; seed persiste datos.' : 'Deshabilitado en esta instancia; las rutas devuelven 404 ROUTE_NOT_FOUND.' },
        { name: 'Logger', description: loggerTestEnabled ? 'Prueba local habilitada.' : 'Deshabilitado en esta instancia; /loggerTest devuelve 404 ROUTE_NOT_FOUND.' },
      ],
      components: { schemas, examples },
    },
    // Rutas absolutas, independientes del cwd y compatibles con Windows.
    apis: files.map(name => fileURLToPath(new URL(`./${name}.yaml`, import.meta.url)).replaceAll('\\', '/')),
  });
}
```

## src/docs/users.yaml

```yaml
paths:
  /api/users:
    get:
      tags:
      - Users
      operationId: listUsers
      summary: Listar Users
      description: Lista ordenada por _id ascendente. data es un array sin total. Solo admite page y limit.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/UsersResponse'
        '400':
          description: 'INVALID_QUERY. INVALID_PAGINATION. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_QUERY'
                - $ref: '#/components/schemas/Error_INVALID_PAGINATION'
              examples:
                INVALID_QUERY:
                  $ref: '#/components/examples/INVALID_QUERY'
                INVALID_PAGINATION:
                  $ref: '#/components/examples/INVALID_PAGINATION'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Page'
      - $ref: '#/components/parameters/Limit'
    post:
      tags:
      - Users
      operationId: createUser
      summary: Crear User
      description: Se asigna role=user; no admite role.
      responses:
        '201':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/UserResponse'
        '400':
          description: 'INVALID_BODY. INVALID_TEXT. INVALID_EMAIL. INVALID_DATA. INVALID_JSON. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_BODY'
                - $ref: '#/components/schemas/Error_INVALID_TEXT'
                - $ref: '#/components/schemas/Error_INVALID_EMAIL'
                - $ref: '#/components/schemas/Error_INVALID_DATA'
                - $ref: '#/components/schemas/Error_INVALID_JSON'
              examples:
                INVALID_BODY:
                  $ref: '#/components/examples/INVALID_BODY'
                INVALID_TEXT:
                  $ref: '#/components/examples/INVALID_TEXT'
                INVALID_EMAIL:
                  $ref: '#/components/examples/INVALID_EMAIL'
                INVALID_DATA:
                  $ref: '#/components/examples/INVALID_DATA'
                INVALID_JSON:
                  $ref: '#/components/examples/INVALID_JSON'
        '409':
          description: 'DUPLICATE_RESOURCE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_DUPLICATE_RESOURCE'
              examples:
                DUPLICATE_RESOURCE:
                  $ref: '#/components/examples/DUPLICATE_RESOURCE'
        '413':
          description: 'PAYLOAD_TOO_LARGE. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_PAYLOAD_TOO_LARGE'
              examples:
                PAYLOAD_TOO_LARGE:
                  $ref: '#/components/examples/PAYLOAD_TOO_LARGE'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      requestBody:
        required: true
        description: JSON; límite de 100 KiB. No se admiten campos adicionales.
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/UserInput'
  /api/users/{id}:
    get:
      tags:
      - Users
      operationId: getUser
      summary: Consultar User por ID
      description: Devuelve el recurso si existe.
      responses:
        '200':
          description: Operación exitosa.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/UserResponse'
        '400':
          description: 'INVALID_ID. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INVALID_ID'
              examples:
                INVALID_ID:
                  $ref: '#/components/examples/INVALID_ID'
        '404':
          description: 'USER_NOT_FOUND. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_USER_NOT_FOUND'
              examples:
                USER_NOT_FOUND:
                  $ref: '#/components/examples/USER_NOT_FOUND'
        '500':
          description: 'INTERNAL_ERROR. '
          content:
            application/json:
              schema:
                oneOf:
                - $ref: '#/components/schemas/Error_INTERNAL_ERROR'
              examples:
                INTERNAL_ERROR:
                  $ref: '#/components/examples/INTERNAL_ERROR'
      parameters:
      - $ref: '#/components/parameters/Id'
```

## src/errors/app-error.js

```javascript
import { ERRORS } from './error-catalog.js';

export class AppError extends Error {
  constructor(definition, { cause, context } = {}) {
    if (!Object.values(ERRORS).includes(definition)) {
      throw new TypeError('AppError requiere una definición del catálogo.');
    }
    super(definition.message, { cause });
    this.name = 'AppError';
    this.code = definition.code;
    this.statusCode = definition.statusCode;
    // Metadatos internos; nunca se serializan automáticamente en la respuesta.
    this.context = context;
  }
}
```

## src/errors/error-catalog.js

```javascript
import { MOCK_LIMITS } from '../constants/index.js';

// Única fuente de códigos, mensajes públicos y estados HTTP.
export const ERRORS = Object.freeze({
  INVALID_BODY: Object.freeze({ code: 'INVALID_BODY', statusCode: 400, message: "Se requiere un objeto JSON con campos permitidos." }),
  INVALID_TEXT: Object.freeze({ code: 'INVALID_TEXT', statusCode: 400, message: "Los campos de texto obligatorios están vacíos o superan el largo permitido." }),
  INVALID_ID: Object.freeze({ code: 'INVALID_ID', statusCode: 400, message: "El identificador debe contener 24 caracteres hexadecimales." }),
  INVALID_QUERY: Object.freeze({ code: 'INVALID_QUERY', statusCode: 400, message: "Los parámetros de consulta no están permitidos o tienen un formato inválido." }),
  INVALID_PAGINATION: Object.freeze({ code: 'INVALID_PAGINATION', statusCode: 400, message: "page y limit deben ser enteros positivos dentro de los límites permitidos." }),
  INVALID_EMAIL: Object.freeze({ code: 'INVALID_EMAIL', statusCode: 400, message: "email tiene un formato inválido." }),
  INVALID_PRICE: Object.freeze({ code: 'INVALID_PRICE', statusCode: 400, message: "price debe ser un número finito no negativo." }),
  INVALID_STOCK: Object.freeze({ code: 'INVALID_STOCK', statusCode: 400, message: "stock debe ser un entero no negativo." }),
  USER_NOT_FOUND: Object.freeze({ code: 'USER_NOT_FOUND', statusCode: 404, message: "Usuario no encontrado." }),
  PRODUCT_NOT_FOUND: Object.freeze({ code: 'PRODUCT_NOT_FOUND', statusCode: 404, message: "Producto no encontrado." }),
  ROUTE_NOT_FOUND: Object.freeze({ code: 'ROUTE_NOT_FOUND', statusCode: 404, message: "Ruta no encontrada." }),
  INVALID_MOCK_AMOUNT: Object.freeze({ code: 'INVALID_MOCK_AMOUNT', statusCode: 400, message: `qty debe ser un entero entre 1 y ${MOCK_LIMITS.MAX_QTY}.` }),
  INVALID_MOCK_INPUT: Object.freeze({ code: 'INVALID_MOCK_INPUT', statusCode: 400, message: "En seed, qty se envía únicamente en el body JSON." }),
  MOCK_LOAD_FAILED: Object.freeze({ code: 'MOCK_LOAD_FAILED', statusCode: 500, message: "Falló la carga del lote; sus registros fueron retirados." }),
  MOCK_CLEANUP_FAILED: Object.freeze({ code: 'MOCK_CLEANUP_FAILED', statusCode: 500, message: "No se completó la carga ni la limpieza del lote. Requiere revisión." }),
  DUPLICATE_RESOURCE: Object.freeze({ code: 'DUPLICATE_RESOURCE', statusCode: 409, message: "El registro ya existe." }),
  INVALID_DATA: Object.freeze({ code: 'INVALID_DATA', statusCode: 400, message: "Datos inválidos." }),
  INVALID_JSON: Object.freeze({ code: 'INVALID_JSON', statusCode: 400, message: "JSON inválido." }),
  PAYLOAD_TOO_LARGE: Object.freeze({ code: 'PAYLOAD_TOO_LARGE', statusCode: 413, message: "El cuerpo de la petición supera el límite permitido." }),
  INTERNAL_ERROR: Object.freeze({ code: 'INTERNAL_ERROR', statusCode: 500, message: "Error interno del servidor." }),
  ORDER_NOT_FOUND: Object.freeze({ code: 'ORDER_NOT_FOUND', statusCode: 404, message: "Pedido no encontrado." }),
  DELIVERY_NOT_FOUND: Object.freeze({ code: 'DELIVERY_NOT_FOUND', statusCode: 404, message: "Entrega no encontrada." }),
  DRIVER_NOT_FOUND: Object.freeze({ code: 'DRIVER_NOT_FOUND', statusCode: 404, message: "Repartidor no encontrado." }),
  INVALID_CUSTOMER: Object.freeze({ code: 'INVALID_CUSTOMER', statusCode: 400, message: "El usuario del pedido debe tener rol user." }),
  INVALID_DRIVER: Object.freeze({ code: 'INVALID_DRIVER', statusCode: 400, message: "El repartidor debe tener rol driver." }),
  INVALID_ITEMS: Object.freeze({ code: 'INVALID_ITEMS', statusCode: 400, message: "items debe contener entre 1 y 100 ítems válidos." }),
  INVALID_ORDER_AMOUNT: Object.freeze({ code: 'INVALID_ORDER_AMOUNT', statusCode: 400, message: "Importe inválido: precio con hasta dos decimales, cantidad entera y total dentro del límite." }),
  INVALID_PRIORITY: Object.freeze({ code: 'INVALID_PRIORITY', statusCode: 400, message: "priority debe ser low, normal o high." }),
  INVALID_STATUS: Object.freeze({ code: 'INVALID_STATUS', statusCode: 400, message: "Estado no reconocido." }),
  INVALID_STATUS_TRANSITION: Object.freeze({ code: 'INVALID_STATUS_TRANSITION', statusCode: 409, message: "La transición de estado no está permitida." }),
  ORDER_CHANGED: Object.freeze({ code: 'ORDER_CHANGED', statusCode: 409, message: "El pedido cambió durante la operación. Volvé a consultarlo." }),
  DELIVERY_REQUIRED: Object.freeze({ code: 'DELIVERY_REQUIRED', statusCode: 409, message: "Se requiere una entrega con repartidor para avanzar el pedido." }),
  DELIVERY_ORDER_CLOSED: Object.freeze({ code: 'DELIVERY_ORDER_CLOSED', statusCode: 409, message: "No se puede crear una entrega para un pedido finalizado." }),
});
```

## src/middlewares/error-handler.js

```javascript
import { logger } from '../config/logger.config.js';
import { AppError } from '../errors/app-error.js';
import { ERRORS } from '../errors/error-catalog.js';

export function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);
  let definition = ERRORS.INTERNAL_ERROR;
  if (error instanceof AppError) {
    definition = ERRORS[error.code] ?? ERRORS.INTERNAL_ERROR;
  } else if (error?.code === 11000) {
    definition = ERRORS.DUPLICATE_RESOURCE;
  } else if (error?.name === 'ValidationError' || error?.name === 'CastError') {
    definition = ERRORS.INVALID_DATA;
  } else if (error?.type === 'entity.parse.failed') {
    definition = ERRORS.INVALID_JSON;
  } else if (error?.type === 'entity.too.large') {
    definition = ERRORS.PAYLOAD_TOO_LARGE;
  }
  const metadata = { code: definition.code, statusCode: definition.statusCode };
  if (error instanceof AppError && /^[0-9a-f-]{36}$/.test(error.context?.batchId ?? '')) {
    metadata.batchId = error.context.batchId;
  }
  // Nunca serializar el error, sus causas, req.body, headers o URI de conexión.
  const level = definition.statusCode >= 500 ? 'error' : 'warning';
  logger.log(level, 'API_ERROR', metadata);
  res.status(definition.statusCode).json({
    status: 'error', error: definition.code, message: definition.message,
  });
}
```

## src/middlewares/request-logger.js

```javascript
import { performance } from 'node:perf_hooks';
import { logger } from '../config/logger.config.js';

export function requestLogger(req, res, next) {
  const start = performance.now();
  res.once('finish', () => {
    // Usar patrón de ruta, no URL original: evita query strings e IDs del cliente.
    const route = typeof req.route?.path === 'string'
      ? `${res.locals.logBase ?? ''}${req.route.path}`.replace(/\/$/, '') || '/' : 'UNMATCHED';
    logger.http('HTTP_REQUEST', { method: req.method, route,
      statusCode: res.statusCode, durationMs: Math.round((performance.now() - start) * 100) / 100 });
  });
  next();
}
```

## src/models/delivery.model.js

```javascript
import { Schema, model } from 'mongoose';
import { DELIVERY_PRIORITY } from '../constants/index.js';

const deliverySchema = new Schema({
  orderId: { type: Schema.Types.ObjectId, ref: 'Order', required: true, unique: true },
  driverId: { type: Schema.Types.ObjectId, ref: 'User', default: null },
  priority: { type: String, required: true, enum: Object.values(DELIVERY_PRIORITY) },
  mockBatchId: { type: String, index: true },
}, { timestamps: true, versionKey: false });

export default model('Delivery', deliverySchema);
```

## src/models/order.model.js

```javascript
import { Schema, model } from 'mongoose';
import { ORDER_STATUS, DELIVERY_PRIORITY } from '../constants/index.js';

const itemSchema = new Schema({
  name: { type: String, required: true, maxlength: 120 },
  quantity: { type: Number, required: true, min: 1, validate: Number.isSafeInteger },
  unitPrice: { type: Number, required: true, min: 0 },
}, { _id: false });

const orderSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  address: { type: String, required: true, maxlength: 250 },
  items: { type: [itemSchema], required: true, validate: value => value.length > 0 },
  total: { type: Number, required: true, min: 0 },
  status: { type: String, required: true, enum: Object.values(ORDER_STATUS) },
  priority: { type: String, required: true, enum: Object.values(DELIVERY_PRIORITY) },
  mockBatchId: { type: String, index: true },
}, { timestamps: true, versionKey: false });

export default model('Order', orderSchema);
```

## src/models/product.model.js

```javascript
import { Schema, model } from 'mongoose';
import { PRODUCT_STATUS } from '../constants/index.js';

const productSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  price: { type: Number, required: true, min: 0 },
  stock: { type: Number, required: true, min: 0, validate: Number.isSafeInteger },
  status: { type: String, required: true, enum: Object.values(PRODUCT_STATUS) },
}, { timestamps: true, versionKey: false });

export default model('Product', productSchema);
```

## src/models/user.model.js

```javascript
import { Schema, model } from 'mongoose';
import { USER_ROLES } from '../constants/index.js';

const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 254, unique: true },
  mockBatchId: { type: String, index: true },
  role: { type: String, required: true, enum: Object.values(USER_ROLES) },
}, { timestamps: true, versionKey: false });

export default model('User', userSchema);
```

## src/repositories/delivery.repository.js

```javascript
import { Types } from 'mongoose';
import Order from '../models/order.model.js';
import Delivery from '../models/delivery.model.js';

export async function initialize() { await Delivery.init(); }

export function insertMany(documents) {
  return Delivery.insertMany(documents.map(({ status, ...document }) => document), { ordered: true });
}

export function deleteMockBatch(batchId) {
  // Solo datos identificados con el UUID de este lote; nunca borra una colección.
  return Delivery.deleteMany({ mockBatchId: batchId }).exec();
}

// El estado se lee del pedido; los antiguos campos delivery.status se ignoran.
// No se requieren migraciones ni dos escrituras para cambiar un estado.
const publicStages = [
  { $lookup: { from: Order.collection.name, localField: 'orderId', foreignField: '_id', as: 'order' } },
  { $unwind: '$order' },
  { $project: { _id: 1, orderId: 1, driverId: 1, priority: 1,
    status: '$order.status', createdAt: 1, updatedAt: 1 } },
];
export function findAll({ limit, skip }) {
  return Delivery.aggregate([{ $sort: { _id: 1 } }, ...publicStages, { $skip: skip }, { $limit: limit }]).exec();
}
export async function findById(id) {
  const results = await Delivery.aggregate([{ $match: { _id: new Types.ObjectId(id) } }, ...publicStages]).exec();
  return results[0] ?? null;
}
export function findByOrderId(orderId) {
  return Delivery.findOne({ orderId }).select('_id orderId driverId').lean().exec();
}
export async function create(data) {
  const document = await Delivery.create(data);
  return findById(document._id);
}
```

## src/repositories/order.repository.js

```javascript
import Order from '../models/order.model.js';

export async function initialize() { await Order.init(); }

export function insertMany(documents) {
  return Order.insertMany(documents, { ordered: true });
}

export function deleteMockBatch(batchId) {
  // Solo datos identificados con el UUID de este lote; nunca borra una colección.
  return Order.deleteMany({ mockBatchId: batchId }).exec();
}

const fields = '_id userId address items total status priority createdAt updatedAt';
export function findAll({ limit, skip }) {
  return Order.find({}).select(fields).sort({ _id: 1 }).skip(skip).limit(limit).lean().exec();
}
export function findById(id) { return Order.findById(id).select(fields).lean().exec(); }
export async function create(data) {
  const document = await Order.create(data);
  return findById(document._id);
}
export function changeStatus(id, expectedStatus, status) {
  // Compare-and-set: un cambio concurrente nunca se sobreescribe a ciegas.
  return Order.findOneAndUpdate({ _id: id, status: expectedStatus }, { $set: { status } },
    { new: true, runValidators: true }).select(fields).lean().exec();
}
```

## src/repositories/product.repository.js

```javascript
import Product from '../models/product.model.js';

const fields = '_id name price stock status createdAt updatedAt';

export function findAll({ limit, skip }) {
  return Product.find({}).select(fields).sort({ _id: 1 }).skip(skip).limit(limit).lean().exec();
}

export function findById(id) {
  return Product.findById(id).select(fields).lean().exec();
}

export async function create(data) {
  const document = await Product.create(data);
  return findById(document._id);
}

// Asegura que los índices declarados estén listos antes de aceptar peticiones.
export async function initialize() {
  await Product.init();
}
```

## src/repositories/user.repository.js

```javascript
import User from '../models/user.model.js';

const fields = '_id name email role createdAt updatedAt';

export function findAll({ limit, skip }) {
  return User.find({}).select(fields).sort({ _id: 1 }).skip(skip).limit(limit).lean().exec();
}

export function findById(id) {
  return User.findById(id).select(fields).lean().exec();
}

export async function create(data) {
  const document = await User.create(data);
  return findById(document._id);
}

// Asegura que los índices declarados estén listos antes de aceptar peticiones.
export async function initialize() {
  await User.init();
}

export function insertMany(documents) {
  return User.insertMany(documents, { ordered: true });
}

export function deleteMockBatch(batchId) {
  // Solo datos identificados con el UUID de este lote; nunca borra una colección.
  return User.deleteMany({ mockBatchId: batchId }).exec();
}
```

## src/routes/deliveries.router.js

```javascript
import { Router } from 'express';
import * as controller from '../controllers/delivery.controller.js';
const router = Router();
router.get('/', controller.list);
router.post('/', controller.create);
router.get('/:id', controller.getById);
router.patch('/:id/status', controller.changeStatus);
export default router;
```

## src/routes/docs.router.js

```javascript
import { Router } from 'express';
import swaggerUi from 'swagger-ui-express';
import { createSwaggerSpec } from '../docs/swagger.config.js';

export function createDocsRouter(options) {
  const router = Router();
  const spec = createSwaggerSpec(options);
  router.get('/openapi.json', (req, res) => res.json(spec));
  // serveFiles mantiene la especificación aislada por instancia de Express.
  router.use('/', swaggerUi.serveFiles(spec), swaggerUi.setup(spec, {
    customSiteTitle: 'ShipNow · API Docs',
    swaggerOptions: { validatorUrl: null, persistAuthorization: false },
  }));
  return router;
}
```

## src/routes/logger.router.js

```javascript
import { Router } from 'express';
import { test } from '../controllers/logger.controller.js';
const router = Router();
router.get('/loggerTest', test);
export default router;
```

## src/routes/mocks.router.js

```javascript
import { Router } from 'express';
import * as controller from '../controllers/mock.controller.js';

const router = Router();
router.get('/users', controller.users);
router.get('/dataset', controller.dataset);
router.post('/seed', controller.seed);
export default router;
```

## src/routes/orders.router.js

```javascript
import { Router } from 'express';
import * as controller from '../controllers/order.controller.js';
const router = Router();
router.get('/', controller.list);
router.post('/', controller.create);
router.get('/:id', controller.getById);
router.patch('/:id/status', controller.changeStatus);
export default router;
```

## src/routes/products.router.js

```javascript
import { Router } from 'express';
import * as controller from '../controllers/product.controller.js';

const router = Router();
router.get('/', controller.list);
router.get('/:id', controller.getById);
router.post('/', controller.create);
export default router;
```

## src/routes/users.router.js

```javascript
import { Router } from 'express';
import * as controller from '../controllers/user.controller.js';

const router = Router();
router.get('/', controller.list);
router.get('/:id', controller.getById);
router.post('/', controller.create);
export default router;
```

## src/server.js

```javascript
import { logger, configureLogger, closeLogger } from './config/logger.config.js';
import { createApp } from './app.js';
import { initialize as initializeOrders } from './repositories/order.repository.js';
import { initialize as initializeDeliveries } from './repositories/delivery.repository.js';
import { loadConfig } from './config/env.config.js';
import { connectDatabase, disconnectDatabase } from './config/db.config.js';
import { initialize as initializeUsers } from './repositories/user.repository.js';
import { initialize as initializeProducts } from './repositories/product.repository.js';

let startupStage = 'logger';

async function start() {
  // Permite registrar incluso fallos de validación, sin imprimir valores del entorno.
  configureLogger({ nodeEnv: 'production' });
  startupStage = 'configuration';
  const config = loadConfig();
  configureLogger(config);
  startupStage = 'database';
  try {
    await connectDatabase(config.mongodbUri);
    const results = await Promise.allSettled([initializeUsers(), initializeProducts(), initializeOrders(), initializeDeliveries()]);
    const failure = results.find(result => result.status === 'rejected');
    if (failure) throw failure.reason;
  } catch {
    throw new Error('No se pudo preparar MongoDB. Verifique conexión, permisos e índices.');
  }
  const app = createApp(config);
  const server = app.listen(config.port, '127.0.0.1', () => {
    logger.info('SERVER_STARTED', { port: config.port, address: `ShipNow M5 disponible en http://127.0.0.1:${config.port}` });
  });
  server.on('error', async () => {
    logger.fatal('HTTP_LISTEN_FAILED', { port: config.port });
    await disconnectDatabase();
    await closeLogger();
    process.exitCode = 1;
  });
  let closing = false;
  const shutdown = () => {
    if (closing) return;
    closing = true;
    const timeout = setTimeout(() => process.exit(1), 10000).unref();
    server.close(async () => {
      try { await disconnectDatabase(); }
      finally { logger.info('SERVER_STOPPED'); await closeLogger(); clearTimeout(timeout); }
    });
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
}

start().catch(async (error) => {
  logger.fatal('STARTUP_FAILED', { stage: startupStage,
    ...(startupStage === 'configuration' && error.message.startsWith('Configuración inválida:')
      ? { reason: error.message } : {}) });
  await disconnectDatabase();
  await closeLogger();
  process.exitCode = 1;
});
```

## src/services/delivery.service.js

```javascript
import * as deliveries from '../repositories/delivery.repository.js';
import * as users from '../repositories/user.repository.js';
import * as orderService from './order.service.js';
import { ORDER_STATUS, USER_ROLES } from '../constants/index.js';
import { ERRORS } from '../errors/error-catalog.js';
import { AppError } from '../errors/app-error.js';
import { pagination, validateBody, validateId } from './validation.js';
import { logger } from '../config/logger.config.js';

export function list(query) { return deliveries.findAll(pagination(query)); }
export async function getById(id) {
  validateId(id);
  const delivery = await deliveries.findById(id);
  if (!delivery) throw new AppError(ERRORS.DELIVERY_NOT_FOUND);
  return delivery;
}
export async function create(body) {
  validateBody(body, ['orderId', 'driverId']);
  validateId(body.orderId);
  validateId(body.driverId);
  const order = await orderService.getById(body.orderId);
  if ([ORDER_STATUS.DELIVERED, ORDER_STATUS.CANCELLED].includes(order.status)) {
    throw new AppError(ERRORS.DELIVERY_ORDER_CLOSED);
  }
  const driver = await users.findById(body.driverId);
  if (!driver) throw new AppError(ERRORS.DRIVER_NOT_FOUND);
  if (driver.role !== USER_ROLES.DRIVER) throw new AppError(ERRORS.INVALID_DRIVER);
  // El índice único orderId arbitra altas duplicadas, incluso concurrentes.
  const created = await deliveries.create({ orderId: order._id, driverId: driver._id, priority: order.priority });
  logger.info('DELIVERY_CREATED', { id: String(created._id), orderId: String(order._id) });
  return created;
}
export async function changeStatus(id, body) {
  validateId(id);
  orderService.validateStatusBody(body);
  const delivery = await getById(id);
  const order = await orderService.changeStatus(String(delivery.orderId), body);
  // Devuelve el estado exacto de la escritura, sin una segunda lectura concurrente.
  return { ...delivery, status: order.status };
}
```

## src/services/logger.service.js

```javascript
import { logger, LOG_LEVELS } from '../config/logger.config.js';

export function generateTestLogs() {
  for (const level of Object.keys(LOG_LEVELS)) {
    logger.log(level, 'LOGGER_TEST', { simulated: true });
  }
  return { message: 'Logs de prueba generados.', levels: Object.keys(LOG_LEVELS) };
}
```

## src/services/mock.generator.js

```javascript
import { randomBytes, randomUUID } from 'node:crypto';
import { Faker, es, en } from '@faker-js/faker';
import { USER_ROLES, ORDER_STATUS, DELIVERY_PRIORITY } from '../constants/index.js';

// Datos compatibles con MongoDB sin importar Mongoose ni escribir en persistencia.
const newId = () => randomBytes(12).toString('hex');

export function generateDataset(qty) {
  const faker = new Faker({ locale: [es, en] });
  const batchId = randomUUID();
  const person = (role, index) => ({
    _id: newId(), name: faker.person.fullName().slice(0, 120),
    email: `${role}.${index}.${batchId}@example.com`, role, mockBatchId: batchId,
  });
  const users = Array.from({ length: qty }, (_, i) => person(USER_ROLES.USER, i));
  const drivers = Array.from({ length: qty }, (_, i) => person(USER_ROLES.DRIVER, i));
  const orders = users.map(user => {
    const items = [{ name: faker.commerce.productName().slice(0, 120),
      quantity: faker.number.int({ min: 1, max: 5 }),
      unitPrice: faker.number.int({ min: 100, max: 10000 }) }];
    return {
      _id: newId(), userId: user._id, address: faker.location.streetAddress().slice(0, 250),
      items, total: items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0),
      status: faker.helpers.arrayElement(Object.values(ORDER_STATUS)),
      priority: faker.helpers.arrayElement(Object.values(DELIVERY_PRIORITY)),
      mockBatchId: batchId,
    };
  });
  const deliveries = orders.map((order, index) => ({
    _id: newId(), orderId: order._id,
    driverId: [ORDER_STATUS.PENDING, ORDER_STATUS.CANCELLED].includes(order.status)
      ? null : drivers[index]._id,
    status: order.status, priority: order.priority, mockBatchId: batchId,
  }));
  return { batchId, users, drivers, orders, deliveries };
}
```

## src/services/mock.service.js

```javascript
import { logger } from '../config/logger.config.js';
import { ERRORS } from '../errors/error-catalog.js';
import * as userRepository from '../repositories/user.repository.js';
import * as orderRepository from '../repositories/order.repository.js';
import * as deliveryRepository from '../repositories/delivery.repository.js';
import { generateDataset } from './mock.generator.js';
import { MOCK_LIMITS } from '../constants/index.js';
import { AppError } from '../errors/app-error.js';
import { validateBody } from './validation.js';

export function parseQueryQty(query = {}) {
  if (Object.keys(query).some(key => key !== 'qty')) {
    throw new AppError(ERRORS.INVALID_QUERY);
  }
  if (query.qty === undefined) return MOCK_LIMITS.DEFAULT_QTY;
  if (typeof query.qty !== 'string' || !/^[1-9]\d*$/.test(query.qty)) {
    throw new AppError(ERRORS.INVALID_MOCK_AMOUNT);
  }
  return validateQty(Number(query.qty));
}

function validateQty(qty) {
  if (!Number.isSafeInteger(qty) || qty < 1 || qty > MOCK_LIMITS.MAX_QTY) {
    throw new AppError(ERRORS.INVALID_MOCK_AMOUNT);
  }
  return qty;
}

// Inyección simple para probar fallas de escritura sin una infraestructura adicional.
export function createMockService(repositories = {
  users: userRepository, orders: orderRepository, deliveries: deliveryRepository,
}) {
  return {
    preview(query) {
      const qty = parseQueryQty(query);
      const dataset = generateDataset(qty);
      logger.debug('MOCK_PREVIEW_CREATED', { qty, batchId: dataset.batchId });
      return dataset;
    },
    async seed(body, query = {}) {
      if (Object.keys(query).length) throw new AppError(ERRORS.INVALID_MOCK_INPUT);
      validateBody(body, ['qty']);
      const dataset = generateDataset(validateQty(body.qty));
      const { batchId, users, drivers, orders, deliveries } = dataset;
      try {
        await repositories.users.insertMany([...users, ...drivers]);
        await repositories.orders.insertMany(orders);
        await repositories.deliveries.insertMany(deliveries);
      } catch (loadError) {
        // Compensación en orden inverso. Si falla, no eliminamos sus padres.
        // No es una transacción: una caída de proceso requiere revisión del lote.
        try {
          await repositories.deliveries.deleteMockBatch(batchId);
          await repositories.orders.deleteMockBatch(batchId);
          await repositories.users.deleteMockBatch(batchId);
        } catch (cleanupError) {
          throw new AppError(ERRORS.MOCK_CLEANUP_FAILED, { cause: new AggregateError([loadError, cleanupError]), context: { batchId } });
        }
        throw new AppError(ERRORS.MOCK_LOAD_FAILED, { cause: loadError, context: { batchId } });
      }
      logger.info('MOCK_BATCH_INSERTED', { batchId, qty: users.length, total: users.length * 4 });
      return { batchId, inserted: { users: users.length, drivers: drivers.length,
        orders: orders.length, deliveries: deliveries.length, total: users.length + drivers.length + orders.length + deliveries.length },
        ids: { users: users.map(x => x._id), drivers: drivers.map(x => x._id),
          orders: orders.map(x => x._id), deliveries: deliveries.map(x => x._id) } };
    },
  };
}

export const mockService = createMockService();
```

## src/services/order.service.js

```javascript
import * as orders from '../repositories/order.repository.js';
import * as users from '../repositories/user.repository.js';
import * as deliveries from '../repositories/delivery.repository.js';
import { ORDER_STATUS as S, DELIVERY_PRIORITY, USER_ROLES } from '../constants/index.js';
import { ERRORS } from '../errors/error-catalog.js';
import { AppError } from '../errors/app-error.js';
import { pagination, requiredText, validateBody, validateId } from './validation.js';
import { logger } from '../config/logger.config.js';

const transitions = Object.freeze({
  [S.PENDING]: [S.ASSIGNED, S.CANCELLED],
  [S.ASSIGNED]: [S.IN_TRANSIT, S.CANCELLED],
  [S.IN_TRANSIT]: [S.DELIVERED, S.CANCELLED],
  [S.DELIVERED]: [], [S.CANCELLED]: [],
});

export function validateOrderInput(body) {
  validateBody(body, ['userId', 'address', 'items', 'priority']);
  validateId(body.userId);
  const address = requiredText(body.address, 'address', 250);
  const priority = body.priority === undefined ? DELIVERY_PRIORITY.NORMAL : body.priority;
  if (!Object.values(DELIVERY_PRIORITY).includes(priority)) throw new AppError(ERRORS.INVALID_PRIORITY);
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 100) {
    throw new AppError(ERRORS.INVALID_ITEMS);
  }
  let totalCents = 0;
  const items = body.items.map(item => {
    validateBody(item, ['name', 'quantity', 'unitPrice']);
    const name = requiredText(item.name, 'name', 120);
    const { quantity, unitPrice } = item;
    if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 1000000
      || typeof unitPrice !== 'number' || !Number.isFinite(unitPrice) || unitPrice < 0
      || unitPrice > 1000000000 || Number(unitPrice.toFixed(2)) !== unitPrice) {
      throw new AppError(ERRORS.INVALID_ORDER_AMOUNT);
    }
    const subtotal = Math.round(unitPrice * 100) * quantity;
    totalCents += subtotal;
    if (!Number.isSafeInteger(totalCents) || totalCents > 100000000000000) {
      throw new AppError(ERRORS.INVALID_ORDER_AMOUNT);
    }
    return { name, quantity, unitPrice };
  });
  return { userId: body.userId, address, items, priority, status: S.PENDING, total: totalCents / 100 };
}

export function validateStatusBody(body) {
  validateBody(body, ['status']);
  if (!Object.values(S).includes(body.status)) throw new AppError(ERRORS.INVALID_STATUS);
  return body.status;
}

export function list(query) { return orders.findAll(pagination(query)); }
export async function getById(id) {
  validateId(id);
  const order = await orders.findById(id);
  if (!order) throw new AppError(ERRORS.ORDER_NOT_FOUND);
  return order;
}
export async function create(body) {
  const data = validateOrderInput(body);
  const user = await users.findById(data.userId);
  if (!user) throw new AppError(ERRORS.USER_NOT_FOUND);
  if (user.role !== USER_ROLES.USER) throw new AppError(ERRORS.INVALID_CUSTOMER);
  const created = await orders.create(data);
  logger.info('ORDER_CREATED', { id: String(created._id) });
  return created;
}
export async function changeStatus(id, body) {
  validateId(id);
  const status = validateStatusBody(body);
  const order = await getById(id);
  if (status === order.status) return order; // Repetir estado no genera otra escritura.
  if (!transitions[order.status]?.includes(status)) throw new AppError(ERRORS.INVALID_STATUS_TRANSITION);
  if (status !== S.CANCELLED) {
    const delivery = await deliveries.findByOrderId(id);
    if (!delivery?.driverId) throw new AppError(ERRORS.DELIVERY_REQUIRED);
    const driver = await users.findById(String(delivery.driverId));
    if (!driver) throw new AppError(ERRORS.DRIVER_NOT_FOUND);
    if (driver.role !== USER_ROLES.DRIVER) throw new AppError(ERRORS.INVALID_DRIVER);
  }
  const updated = await orders.changeStatus(id, order.status, status);
  if (!updated) throw new AppError(ERRORS.ORDER_CHANGED);
  logger.info('ORDER_STATUS_CHANGED', { id: String(updated._id), from: order.status, to: status });
  return updated;
}
```

## src/services/product.service.js

```javascript
import { logger } from '../config/logger.config.js';
import { ERRORS } from '../errors/error-catalog.js';
import * as repository from '../repositories/product.repository.js';
import { PRODUCT_STATUS } from '../constants/index.js';
import { AppError } from '../errors/app-error.js';
import { pagination, requiredText, validateBody, validateId } from './validation.js';

export function list(query) {
  return repository.findAll(pagination(query));
}

export async function getById(id) {
  validateId(id);
  const product = await repository.findById(id);
  if (!product) throw new AppError(ERRORS.PRODUCT_NOT_FOUND);
  return product;
}

export async function create(body) {
  validateBody(body, ['name', 'price', 'stock']);
  const name = requiredText(body.name, 'name', 120);
  if (typeof body.price !== 'number' || !Number.isFinite(body.price) || body.price < 0) {
    throw new AppError(ERRORS.INVALID_PRICE);
  }
  if (!Number.isSafeInteger(body.stock) || body.stock < 0) {
    throw new AppError(ERRORS.INVALID_STOCK);
  }
  // Decisión de negocio: el cliente no puede imponer un estado incompatible con el stock.
  const status = body.stock > 0 ? PRODUCT_STATUS.AVAILABLE : PRODUCT_STATUS.OUT_OF_STOCK;
  const created = await repository.create({ name, price: body.price, stock: body.stock, status });
  logger.info('PRODUCT_CREATED', { id: String(created._id) });
  return created;
}
```

## src/services/user.service.js

```javascript
import { logger } from '../config/logger.config.js';
import { ERRORS } from '../errors/error-catalog.js';
import * as repository from '../repositories/user.repository.js';
import { USER_ROLES } from '../constants/index.js';
import { AppError } from '../errors/app-error.js';
import { pagination, requiredText, validateBody, validateId } from './validation.js';

export function list(query) {
  return repository.findAll(pagination(query));
}

export async function getById(id) {
  validateId(id);
  const user = await repository.findById(id);
  if (!user) throw new AppError(ERRORS.USER_NOT_FOUND);
  return user;
}

export async function create(body) {
  validateBody(body, ['name', 'email']);
  const name = requiredText(body.name, 'name', 120);
  const email = requiredText(body.email, 'email', 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new AppError(ERRORS.INVALID_EMAIL);
  }
  // No se acepta un rol elevado desde el body de una ruta sin autenticación.
  const created = await repository.create({ name, email, role: USER_ROLES.USER });
  logger.info('USER_CREATED', { id: String(created._id) });
  return created;
}
```

## src/services/validation.js

```javascript
import { ERRORS } from '../errors/error-catalog.js';
import { AppError } from '../errors/app-error.js';

export function validateBody(body, allowedFields) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new AppError(ERRORS.INVALID_BODY);
  }
  if (Object.keys(body).some((key) => !allowedFields.includes(key))) {
    throw new AppError(ERRORS.INVALID_BODY);
  }
}

export function requiredText(value, label, maxLength) {
  if (typeof value !== 'string' || !value.trim() || value.trim().length > maxLength) {
    throw new AppError(ERRORS.INVALID_TEXT);
  }
  return value.trim();
}

export function validateId(id) {
  if (typeof id !== 'string' || !/^[a-fA-F0-9]{24}$/.test(id)) {
    throw new AppError(ERRORS.INVALID_ID);
  }
}

export function pagination(query = {}) {
  if (Object.keys(query).some((key) => !['limit', 'page'].includes(key))) {
    throw new AppError(ERRORS.INVALID_QUERY);
  }
  const parse = (value, fallback, max) => {
    if (value === undefined) return fallback;
    if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) {
      throw new AppError(ERRORS.INVALID_PAGINATION);
    }
    const number = Number(value);
    if (!Number.isSafeInteger(number) || number > max) {
      throw new AppError(ERRORS.INVALID_PAGINATION);
    }
    return number;
  };
  const limit = parse(query.limit, 20, 100);
  const page = parse(query.page, 1, 1000000);
  return { limit, skip: (page - 1) * limit };
}
```

## tests/base.test.js

```javascript
import { expect } from 'chai';
import request from 'supertest';
import app from '../src/app.js';
import { validateEnv } from '../src/config/env.config.js';
import { USER_ROLES, PRODUCT_STATUS } from '../src/constants/index.js';

const valid = { PORT: '8080', NODE_ENV: 'test', MONGODB_URI: 'mongodb://127.0.0.1:27017/shipnow_test' };
describe('Configuración y frontera HTTP sin base de datos', () => {
  it('valida y congela la configuración', () => {
    const config = validateEnv(valid);
    expect(config.port).to.equal(8080);
    expect(Object.isFrozen(config)).to.equal(true);
  });
  for (const key of Object.keys(valid)) {
    it(`rechaza ausencia de ${key}`, () => {
      expect(() => validateEnv({ ...valid, [key]: '' })).to.throw(key);
    });
  }
  for (const port of ['0', '65536', '12.5', '1e3']) {
    it(`rechaza puerto ${port}`, () => expect(() => validateEnv({ ...valid, PORT: port })).to.throw('PORT'));
  }
  it('rechaza entorno y URI inválidos', () => {
    expect(() => validateEnv({ ...valid, NODE_ENV: 'invalid' })).to.throw('NODE_ENV');
    expect(() => validateEnv({ ...valid, MONGODB_URI: 'http://localhost' })).to.throw('MONGODB_URI');
  });
  it('congela constantes del dominio', () => {
    expect(Object.isFrozen(USER_ROLES)).to.equal(true);
    expect(Object.isFrozen(PRODUCT_STATUS)).to.equal(true);
  });
  const cases = [
    ['get', '/missing', undefined, 404],
    ['get', '/api/products/not-an-id', undefined, 400],
    ['get', '/api/users/not-an-id', undefined, 400],
    ['get', '/api/products?limit=101', undefined, 400],
    ['get', '/api/users?page=-1', undefined, 400],
    ['get', '/api/users?limit=1&limit=2', undefined, 400],
    ['post', '/api/products', { name: 'Caja', price: 5, stock: -1 }, 400],
    ['post', '/api/products', { name: 'Caja', price: '5', stock: 1 }, 400],
    ['post', '/api/products', { name: 'Caja', price: 5, stock: 0, status: PRODUCT_STATUS.AVAILABLE }, 400],
    ['post', '/api/users', { name: 'Ana', email: 'invalid' }, 400],
    ['post', '/api/users', { name: 'Ana', email: 'ana@example.com', role: USER_ROLES.ADMIN }, 400],
    ['post', '/api/users', [], 400],
  ];
  for (const [method, url, body, status] of cases) {
    it(`${method.toUpperCase()} ${url} rechaza ${JSON.stringify(body)}`, async () => {
      const response = await request(app)[method](url).send(body);
      expect(response.status).to.equal(status);
      expect(response.body.status).to.equal('error');
      expect(response.body.message).to.be.a('string').and.not.empty;
      expect(response.body).not.to.have.property('stack');
    });
  }
  it('controla JSON mal formado', async () => {
    const response = await request(app).post('/api/users').set('Content-Type', 'application/json').send('{');
    expect(response.status).to.equal(400);
    expect(response.body.message).to.equal('JSON inválido.');
  });
});
```

## tests/docs.test.js

```javascript
import { expect } from 'chai';
import request from 'supertest';
import SwaggerParser from '@apidevtools/swagger-parser';
import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { createApp } from '../src/app.js';
import { createSwaggerSpec } from '../src/docs/swagger.config.js';
import { validateEnv } from '../src/config/env.config.js';
import { ERRORS } from '../src/errors/error-catalog.js';

const options = { mocksEnabled: true, loggerTestEnabled: true };
const ajv = new Ajv({ strict: false, allErrors: true });
addFormats(ajv);
let spec;

function matchesResponse(path, method, response) {
  const schema = spec.paths[path][method].responses[response.status].content['application/json'].schema;
  const validate = ajv.compile(schema);
  expect(validate(response.body), JSON.stringify(validate.errors)).to.equal(true);
}

describe('M5: OpenAPI y documentación HTTP', () => {
  before(async () => { spec = await SwaggerParser.validate(createSwaggerSpec(options)); });

  it('valida referencias, operaciones únicas y cobertura de las dieciocho operaciones existentes', () => {
    const operations = Object.values(spec.paths).flatMap(path => Object.values(path));
    expect(operations).to.have.length(18);
    expect(new Set(operations.map(x => x.operationId)).size).to.equal(18);
    expect(spec.info.version).to.equal('0.5.1');
    expect(spec.paths).to.have.property('/api/orders');
    expect(spec.paths).to.have.property('/api/deliveries');
    for (const operation of operations) {
      expect(operation.tags).not.to.be.empty;
      expect(operation.description).not.to.be.empty;
      expect(operation.responses).to.have.property('500');
    }
  });

  it('sirve Swagger UI, sus assets y el JSON sin MongoDB', async () => {
    const app = createApp(options);
    await request(app).get('/api/docs').expect(301);
    const html = await request(app).get('/api/docs/').expect(200);
    expect(html.text).to.include('swagger-ui');
    for (const asset of ['swagger-ui.css', 'swagger-ui-bundle.js', 'swagger-ui-init.js']) {
      const response = await request(app).get(`/api/docs/${asset}`).expect(200);
      expect(response.text.length).to.be.greaterThan(100);
    }
    const json = await request(app).get('/api/docs/openapi.json').expect(200);
    expect(json.body.openapi).to.equal('3.0.3');
    await SwaggerParser.validate(json.body);
  });

  it('omite rutas apagadas y documenta solo las habilitadas en producción', async () => {
    const config = validateEnv({ PORT: '9090', NODE_ENV: 'production',
      MONGODB_URI: 'mongodb://localhost/demo', ENABLE_MOCKS: 'true', ENABLE_LOGGER_TEST: 'true' });
    const app = createApp(config);
    const { body } = await request(app).get('/api/docs/openapi.json').expect(200);
    expect(Object.keys(body.paths)).to.deep.equal(['/api/users', '/api/users/{id}', '/api/products', '/api/products/{id}', '/api/orders', '/api/orders/{id}', '/api/orders/{id}/status', '/api/deliveries', '/api/deliveries/{id}', '/api/deliveries/{id}/status']);
    expect(body.servers[1].url).to.equal('http://127.0.0.1:9090');
    for (const path of ['/loggerTest', '/api/mocks/dataset']) {
      const response = await request(app).get(path).expect(404);
      expect(response.body.error).to.equal('ROUTE_NOT_FOUND');
    }
  });

  it('aísla documentos de dos apps con flags distintos', async () => {
    const enabled = createApp(options);
    const disabled = createApp();
    const first = await request(enabled).get('/api/docs/swagger-ui-init.js');
    await request(disabled).get('/api/docs/swagger-ui-init.js');
    const again = await request(enabled).get('/api/docs/swagger-ui-init.js');
    expect(first.text).to.equal(again.text);
    const { body } = await request(disabled).get('/api/docs/openapi.json');
    expect(body.paths).not.to.have.property('/loggerTest');
  });

  it('carga YAML desde otro directorio de trabajo', () => {
    const moduleUrl = new URL('../src/docs/swagger.config.js', import.meta.url).href;
    const code = `import { createSwaggerSpec } from ${JSON.stringify(moduleUrl)}; console.log(Object.keys(createSwaggerSpec().paths).length);`;
    expect(execFileSync(process.execPath, ['--input-type=module', '-e', code], { cwd: tmpdir(), encoding: 'utf8' }).trim()).to.equal('10');
  });

  it('mantiene todos los ejemplos de errores sincronizados con M3', () => {
    for (const error of Object.values(ERRORS)) {
      expect(spec.components.examples[error.code].value).to.deep.equal({
        status: 'error', error: error.code, message: error.message,
      });
    }
  });

  it('valida respuestas reales de dataset, users mock y logger contra sus schemas', async () => {
    const app = createApp(options);
    for (const path of ['/api/mocks/dataset', '/api/mocks/users', '/loggerTest']) {
      const response = await request(app).get(path + (path.startsWith('/api/mocks') ? '?qty=2' : '')).expect(200);
      matchesResponse(path, 'get', response);
    }
  });

  it('valida errores reales de ID, paginación, body, JSON y cantidades contra lo documentado', async () => {
    const app = createApp(options);
    const cases = [
      ['get', '/api/users/not-an-id', '/api/users/{id}'],
      ['get', '/api/products?limit=101', '/api/products'],
      ['get', '/api/mocks/dataset?qty=-1', '/api/mocks/dataset'],
      ['post', '/api/users', '/api/users', { name: 'Ana', email: 'invalid' }],
      ['post', '/api/products', '/api/products', { name: 'Caja', price: 1, stock: -1 }],
      ['post', '/api/mocks/seed?qty=1', '/api/mocks/seed', { qty: 1 }],
    ];
    for (const [method, url, path, body] of cases) {
      let req = request(app)[method](url);
      if (body) req = req.send(body);
      const response = await req.expect(400);
      matchesResponse(path, method, response);
    }
    const invalid = await request(app).post('/api/users').set('Content-Type', 'application/json').send('{').expect(400);
    matchesResponse('/api/users', 'post', invalid);
    const large = await request(app).post('/api/users').send({ name: 'x'.repeat(110000) }).expect(413);
    matchesResponse('/api/users', 'post', large);
  });
});
```

## tests/errors.test.js

```javascript
import { expect } from 'chai';
import express from 'express';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { ERRORS } from '../src/errors/error-catalog.js';
import { AppError } from '../src/errors/app-error.js';
import { errorHandler } from '../src/middlewares/error-handler.js';
import { createMockService, mockService } from '../src/services/mock.service.js';

const app = createApp({ mocksEnabled: true });
function expectError(response, definition) {
  expect(response.status).to.equal(definition.statusCode);
  expect(response.body).to.deep.equal({ status: 'error', error: definition.code, message: definition.message });
}
describe('M3: contrato uniforme de errores', () => {
  it('congela el catálogo y exige definiciones registradas', () => {
    expect(Object.isFrozen(ERRORS)).to.equal(true);
    for (const [key, value] of Object.entries(ERRORS)) {
      expect(value.code).to.equal(key);
      expect(Object.isFrozen(value)).to.equal(true);
    }
    expect(() => new AppError({ code: 'inventado' })).to.throw(TypeError);
  });
  const cases = [
    ['get', '/missing', undefined, ERRORS.ROUTE_NOT_FOUND],
    ['get', '/api/users/not-an-id', undefined, ERRORS.INVALID_ID],
    ['get', '/api/products?page=-1', undefined, ERRORS.INVALID_PAGINATION],
    ['post', '/api/users', [], ERRORS.INVALID_BODY],
    ['post', '/api/users', { name: '', email: 'a@example.com' }, ERRORS.INVALID_TEXT],
    ['post', '/api/users', { name: 'Ana', email: 'invalid' }, ERRORS.INVALID_EMAIL],
    ['post', '/api/products', { name: 'Caja', price: -1, stock: 1 }, ERRORS.INVALID_PRICE],
    ['post', '/api/products', { name: 'Caja', price: 1, stock: -1 }, ERRORS.INVALID_STOCK],
    ['get', '/api/mocks/dataset?qty=-1', undefined, ERRORS.INVALID_MOCK_AMOUNT],
    ['get', '/api/mocks/users?qty=text', undefined, ERRORS.INVALID_MOCK_AMOUNT],
    ['post', '/api/mocks/seed', { qty: 101 }, ERRORS.INVALID_MOCK_AMOUNT],
    ['post', '/api/mocks/seed?qty=1', { qty: 1 }, ERRORS.INVALID_MOCK_INPUT],
  ];
  for (const [method, path, body, definition] of cases) {
    it(`${method.toUpperCase()} ${path}: ${definition.code}`, async () => {
      expectError(await request(app)[method](path).send(body), definition);
    });
  }
  it('JSON malformado y cuerpo excesivo tienen el mismo contrato', async () => {
    expectError(await request(app).post('/api/users').set('Content-Type', 'application/json').send('{'), ERRORS.INVALID_JSON);
    expectError(await request(app).post('/api/users').send({ name: 'x'.repeat(110000) }), ERRORS.PAYLOAD_TOO_LARGE);
  });
  for (const [error, definition] of [
    [Object.assign(new Error('mongodb://secret'), { code: 11000 }), ERRORS.DUPLICATE_RESOURCE],
    [Object.assign(new Error('private data'), { name: 'ValidationError' }), ERRORS.INVALID_DATA],
    [Object.assign(new Error('private data'), { name: 'CastError' }), ERRORS.INVALID_DATA],
    [Object.assign(new Error('password=secret'), { statusCode: 400 }), ERRORS.INTERNAL_ERROR],
    [null, ERRORS.INTERNAL_ERROR],
  ]) {
    it(`normaliza ${error?.name ?? 'null'} como ${definition.code} sin filtrar detalles`, async () => {
      const fixture = express();
      fixture.get('/failure', async (req, res, next) => {
        if (error === null) return errorHandler(null, req, res, next);
        throw error;
      });
      fixture.use(errorHandler);
      expectError(await request(fixture).get('/failure'), definition);
    });
  }
  it('delega si la respuesta ya comenzó', () => {
    const error = new Error('test');
    let forwarded;
    errorHandler(error, {}, { headersSent: true }, caught => { forwarded = caught; });
    expect(forwarded).to.equal(error);
  });
  for (const cleanupFails of [false, true]) {
    it(`la falla de seed llega por Controller al middleware (limpieza falla=${cleanupFails})`, async () => {
      const failure = new Error('mongodb://private:secret@host');
      const repository = {
        async insertMany() { throw failure; },
        async deleteMockBatch() { if (cleanupFails) throw new Error('private cleanup'); },
      };
      const failing = createMockService({ users: repository, orders: repository, deliveries: repository });
      const original = mockService.seed;
      mockService.seed = failing.seed;
      try {
        expectError(await request(app).post('/api/mocks/seed').send({ qty: 1 }),
          cleanupFails ? ERRORS.MOCK_CLEANUP_FAILED : ERRORS.MOCK_LOAD_FAILED);
      } finally { mockService.seed = original; }
    });
  }
});
```

## tests/helpers/openapi.js

```javascript
import { expect } from 'chai';
import SwaggerParser from '@apidevtools/swagger-parser';
import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import { createSwaggerSpec } from '../../src/docs/swagger.config.js';

const ajv = new Ajv({ strict: false, allErrors: true });
addFormats(ajv);
let specification;

// Comparar respuestas de MongoDB con el contrato público, sin cambiar el servidor.
export async function expectDocumentedResponse(path, method, response) {
  specification ??= SwaggerParser.validate(createSwaggerSpec({ mocksEnabled: true, loggerTestEnabled: true }));
  const spec = await specification;
  const schema = spec.paths[path][method].responses[response.status].content['application/json'].schema;
  const validate = ajv.compile(schema);
  expect(validate(response.body), JSON.stringify(validate.errors)).to.equal(true);
}
```

## tests/integration.mongodb.js

```javascript
import { expectDocumentedResponse } from './helpers/openapi.js';
import { expect } from 'chai';
import request from 'supertest';
import { randomUUID } from 'node:crypto';
import app from '../src/app.js';
import User from '../src/models/user.model.js';
import Product from '../src/models/product.model.js';
import { USER_ROLES, PRODUCT_STATUS } from '../src/constants/index.js';

// Tests de integración: se permite inspeccionar directamente la persistencia.
const users = [];
const products = [];
describe('Flujos HTTP con MongoDB real y descartable', () => {
  after(async () => {
    if (users.length) await User.deleteMany({ _id: { $in: users } });
    if (products.length) await Product.deleteMany({ _id: { $in: products } });
  });
  it('crea usuario, normaliza email, consulta y rechaza duplicado', async () => {
    const email = `${randomUUID()}@EXAMPLE.COM`;
    const created = await request(app).post('/api/users').send({ name: ' Ana ', email });
    if (created.body.data?._id) users.push(created.body.data._id);
    expect(created.status).to.equal(201);
    await expectDocumentedResponse('/api/users', 'post', created);
    expect(created.body.data).to.include({ name: 'Ana', email: email.toLowerCase(), role: USER_ROLES.USER });
    const found = await request(app).get(`/api/users/${created.body.data._id}`);
    expect(found.status).to.equal(200);
    await expectDocumentedResponse('/api/users/{id}', 'get', found);
    expect(found.body.data.email).to.equal(email.toLowerCase());
    const duplicate = await request(app).post('/api/users').send({ name: 'Ana', email });
    expect(duplicate.status).to.equal(409);
    await expectDocumentedResponse('/api/users', 'post', duplicate);
    expect(duplicate.body.status).to.equal('error');
    expect(duplicate.body.error).to.equal('DUPLICATE_RESOURCE');
  });
  for (const [stock, status] of [[3, PRODUCT_STATUS.AVAILABLE], [0, PRODUCT_STATUS.OUT_OF_STOCK]]) {
    it(`persiste producto con stock ${stock} y estado derivado`, async () => {
      const created = await request(app).post('/api/products').send({ name: 'Caja', price: 12.5, stock });
      if (created.body.data?._id) products.push(created.body.data._id);
      expect(created.status).to.equal(201);
      await expectDocumentedResponse('/api/products', 'post', created);
      expect(created.body.data).to.include({ name: 'Caja', price: 12.5, stock, status });
      const found = await request(app).get(`/api/products/${created.body.data._id}`);
      expect(found.status).to.equal(200);
      await expectDocumentedResponse('/api/products/{id}', 'get', found);
      expect(found.body.data.status).to.equal(status);
      expect(await Product.exists({ _id: created.body.data._id })).not.to.equal(null);
    });
  }
  for (const resource of ['users', 'products']) {
    it(`limita listado de ${resource}`, async () => {
      const response = await request(app).get(`/api/${resource}?limit=1`);
      expect(response.status).to.equal(200);
      await expectDocumentedResponse(`/api/${resource}`, 'get', response);
      expect(response.body.data).to.be.an('array');
      expect(response.body.data.length).to.be.at.most(1);
    });
    it(`devuelve 404 para ${resource} inexistente`, async () => {
      const response = await request(app).get(`/api/${resource}/000000000000000000000000`);
      expect(response.status).to.equal(404);
      await expectDocumentedResponse(`/api/${resource}/{id}`, 'get', response);
      expect(response.body.status).to.equal('error');
      expect(response.body.error).to.equal(resource === 'users' ? 'USER_NOT_FOUND' : 'PRODUCT_NOT_FOUND');
    });
  }
});
```

## tests/integration.setup.js

```javascript
import { loadConfig } from '../src/config/env.config.js';
import { connectDatabase, disconnectDatabase } from '../src/config/db.config.js';
import User from '../src/models/user.model.js';
import Product from '../src/models/product.model.js';
import Order from '../src/models/order.model.js';
import Delivery from '../src/models/delivery.model.js';

// Una conexión para toda la ejecución serial de integración.
// Esperar todos los modelos evita cerrar con inicializaciones pendientes.
export const mochaHooks = {
  async beforeAll() {
    const config = loadConfig();
    const database = new URL(config.mongodbUri).pathname.slice(1);
    if (config.nodeEnv !== 'test' || !database.endsWith('_test')) {
      throw new Error('Se requiere NODE_ENV=test y una base terminada en _test.');
    }
    await connectDatabase(config.mongodbUri);
    const results = await Promise.allSettled([
      User.init(), Product.init(), Order.init(), Delivery.init(),
    ]);
    const failure = results.find(result => result.status === 'rejected');
    if (failure) throw failure.reason;
  },
  async afterAll() {
    await disconnectDatabase();
  },
};
```

## tests/logger.test.js

```javascript
import { expect } from 'chai';
import request from 'supertest';
import express from 'express';
import { Writable } from 'node:stream';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createLogger, configureLogger, closeLogger, LOG_LEVELS } from '../src/config/logger.config.js';
import { createApp } from '../src/app.js';
import { validateEnv } from '../src/config/env.config.js';
import { errorHandler } from '../src/middlewares/error-handler.js';

function capture() {
  const lines = [];
  const stream = new Writable({ write(chunk, encoding, done) {
    lines.push(...chunk.toString().trim().split('\n').filter(Boolean).map(line => JSON.parse(line)));
    done();
  } });
  return { stream, lines };
}

describe('M4: Winston y persistencia real en archivos temporales', () => {
  let directory;
  beforeEach(async () => { directory = await mkdtemp(join(tmpdir(), 'shipnow-logs-')); });
  afterEach(async () => { await rm(directory, { recursive: true, force: true }); });
  for (const nodeEnv of ['development', 'production']) {
    it(`${nodeEnv}: consola filtra niveles y archivo solo persiste error/fatal`, async () => {
      const { stream, lines } = capture();
      const log = createLogger({ nodeEnv, directory, consoleStream: stream });
      for (const level of Object.keys(LOG_LEVELS)) log.log(level, `TEST_${level}`);
      await closeLogger(log);
      expect(lines.map(x => x.level)).to.deep.equal(nodeEnv === 'development'
        ? ['fatal', 'error', 'warning', 'info', 'http', 'debug'] : ['fatal', 'error', 'warning', 'info']);
      const filenames = (await readdir(directory)).filter(name => /^error-.*\.log$/.test(name));
      // Al resolverse closeLogger el archivo ya debe existir y estar completo.
      expect(filenames, 'closeLogger debe esperar la escritura del archivo').to.have.length(1);
      const records = (await readFile(join(directory, filenames[0]), 'utf8'))
        .trim().split('\n').map(JSON.parse);
      expect(records.map(x => x.level)).to.deep.equal(['fatal', 'error']);
      for (const record of records) {
        expect(Number.isNaN(Date.parse(record.timestamp))).to.equal(false);
        expect(record.message).to.match(/^TEST_/);
      }
    });
  }
  it('rota por tamaño y limita la cantidad de archivos', async () => {
    const { stream } = capture();
    const log = createLogger({ nodeEnv: 'production', directory, consoleStream: stream, maxsize: '1k', maxFiles: 3 });
    // Esperar escritura de cada registro para probar rotación, no carreras del productor.
    for (let i = 0; i < 16; i++) {
      log.error('ROTATION_TEST', { sequence: i, padding: 'x'.repeat(180) });
      // logged significa encolado. Esperar evidencia en disco, con límite de tiempo.
      let persisted = false;
      for (let attempt = 0; attempt < 100 && !persisted; attempt++) {
        const names = (await readdir(directory)).filter(name => /^error-.*\.log(?:\.\d+)?$/.test(name));
        const text = (await Promise.all(names.map(name => readFile(join(directory, name), 'utf8')))).join('');
        persisted = text.includes(`"sequence":${i},`) || text.includes(`"sequence":${i}}`);
        if (!persisted) await new Promise(resolve => setTimeout(resolve, 5));
      }
      expect(persisted, `registro ${i} escrito`).to.equal(true);
    }
    await closeLogger(log);
    const files = (await readdir(directory)).filter(name => /^error-.*\.log(?:\.\d+)?$/.test(name));
    expect(files.length).to.be.within(2, 3);
    const contents = (await Promise.all(files.map(name => readFile(join(directory, name), 'utf8')))).join('\n');
    const records = contents.split('\n').filter(Boolean).map(JSON.parse);
    expect(records.some(x => x.sequence === 15)).to.equal(true);
    expect(records.some(x => x.sequence === 0)).to.equal(false);
    expect(records.every(x => x.level === 'error')).to.equal(true);
  });
});

describe('M4: integración del logger con HTTP', () => {
  let lines;
  beforeEach(() => {
    const captureStream = capture();
    lines = captureStream.lines;
    configureLogger({ nodeEnv: 'development', files: false, consoleStream: captureStream.stream });
  });
  afterEach(() => { configureLogger({ silent: true, files: false }); });
  it('/loggerTest emite los seis niveles y responde sin simular un fallo HTTP', async () => {
    const response = await request(createApp({ loggerTestEnabled: true })).get('/loggerTest');
    expect(response.status).to.equal(200);
    const records = lines.filter(x => x.message === 'LOGGER_TEST');
    expect(records.map(x => x.level)).to.deep.equal(Object.keys(LOG_LEVELS));
    expect(records.every(x => x.simulated === true)).to.equal(true);
  });
  it('deshabilita el endpoint por defecto y en producción', async () => {
    const env = { PORT: '8080', NODE_ENV: 'production', MONGODB_URI: 'mongodb://localhost/demo', ENABLE_LOGGER_TEST: 'true' };
    expect(validateEnv(env).loggerTestEnabled).to.equal(false);
    expect((await request(createApp(validateEnv(env))).get('/loggerTest')).status).to.equal(404);
    expect((await request(createApp()).get('/loggerTest')).status).to.equal(404);
    expect(() => validateEnv({ ...env, ENABLE_LOGGER_TEST: 'yes' })).to.throw('ENABLE_LOGGER_TEST');
  });
  it('registra 4xx como warning y HTTP sin query, headers ni datos del body', async () => {
    await request(createApp()).post('/api/users?token=secret-query')
      .set('Authorization', 'Bearer secret-header').send({ name: 'secret-body', email: 'invalid' });
    const error = lines.find(x => x.message === 'API_ERROR');
    expect(error.level).to.equal('warning');
    expect(error.code).to.equal('INVALID_EMAIL');
    const http = lines.find(x => x.message === 'HTTP_REQUEST');
    expect(http.statusCode).to.equal(400);
    expect(http.route).to.equal('/api/users');
    expect(http.durationMs).to.be.at.least(0);
    expect(JSON.stringify(lines)).not.to.include('secret');
  });
  it('error inesperado: nivel error, respuesta M3 intacta y causa privada omitida', async () => {
    const app = express();
    app.get('/failure', async () => { throw new Error('mongodb://secret:password@host'); });
    app.use(errorHandler);
    const response = await request(app).get('/failure');
    expect(response.status).to.equal(500);
    expect(response.body.error).to.equal('INTERNAL_ERROR');
    expect(lines.find(x => x.message === 'API_ERROR').level).to.equal('error');
    expect(JSON.stringify(lines)).not.to.include('password');
  });
  it('registra generación de mocks con cantidad y lote, sin personas', async () => {
    const response = await request(createApp({ mocksEnabled: true })).get('/api/mocks/dataset?qty=2');
    const record = lines.find(x => x.message === 'MOCK_PREVIEW_CREATED');
    expect(record).to.include({ level: 'debug', qty: 2, batchId: response.body.data.batchId });
    expect(JSON.stringify(lines)).not.to.include(response.body.data.users[0].email);
  });
});
```

## tests/mocks.integration.mongodb.js

```javascript
import { expectDocumentedResponse } from './helpers/openapi.js';
import { expect } from 'chai';
import request from 'supertest';
import { createApp } from '../src/app.js';
import User from '../src/models/user.model.js';
import Order from '../src/models/order.model.js';
import Delivery from '../src/models/delivery.model.js';
import { USER_ROLES } from '../src/constants/index.js';
const app = createApp({ mocksEnabled: true });
const batches = [];
describe('M2: mocks con MongoDB real', () => {
  after(async () => {
    if (batches.length) {
      const filter = { mockBatchId: { $in: batches } };
      await Delivery.deleteMany(filter);
      await Order.deleteMany(filter);
      await User.deleteMany(filter);
    }
  });
  it('la vista previa no persiste sus documentos', async () => {
    const response = await request(app).get('/api/mocks/dataset?qty=2');
    expect(response.status).to.equal(200);
    await expectDocumentedResponse('/api/mocks/dataset', 'get', response);
    const filter = { mockBatchId: response.body.data.batchId };
    expect(await User.countDocuments(filter)).to.equal(0);
    expect(await Order.countDocuments(filter)).to.equal(0);
    expect(await Delivery.countDocuments(filter)).to.equal(0);
  });
  it('dos cargas conservan el lote anterior y persisten referencias válidas', async () => {
    for (let run = 0; run < 2; run++) {
      const response = await request(app).post('/api/mocks/seed').send({ qty: 2 });
      if (response.body.data?.batchId) batches.push(response.body.data.batchId);
      expect(response.status).to.equal(201);
      await expectDocumentedResponse('/api/mocks/seed', 'post', response);
      expect(response.body.data.inserted.total).to.equal(8);
      const filter = { mockBatchId: response.body.data.batchId };
      expect(await User.countDocuments(filter)).to.equal(4);
      expect(await Order.countDocuments(filter)).to.equal(2);
      const deliveries = await Delivery.find(filter).populate('orderId').populate('driverId').lean();
      expect(deliveries).to.have.length(2);
      for (const delivery of deliveries) {
        const publicDelivery = await request(app).get(`/api/deliveries/${delivery._id}`);
        expect(publicDelivery.status).to.equal(200);
        expect(publicDelivery.body.data.status).to.equal(delivery.orderId.status);
        expect(delivery.orderId.priority).to.equal(delivery.priority);
        const user = await User.findById(delivery.orderId.userId).lean();
        expect(user.role).to.equal(USER_ROLES.USER);
        if (delivery.driverId) expect(delivery.driverId.role).to.equal(USER_ROLES.DRIVER);
      }
    }
    expect(batches[0]).not.to.equal(batches[1]);
    expect(await User.countDocuments({ mockBatchId: batches[0] })).to.equal(4);
  });
});
```

## tests/mocks.test.js

```javascript
import { expect } from 'chai';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { validateEnv } from '../src/config/env.config.js';
import { generateDataset } from '../src/services/mock.generator.js';
import { createMockService } from '../src/services/mock.service.js';
import User from '../src/models/user.model.js';
import Order from '../src/models/order.model.js';
import Delivery from '../src/models/delivery.model.js';
import { USER_ROLES, ORDER_STATUS, DELIVERY_PRIORITY } from '../src/constants/index.js';

const app = createApp({ mocksEnabled: true });
describe('M2: generación y contrato HTTP sin MongoDB', () => {
  it('genera documentos válidos y relaciones coherentes para el máximo permitido', async () => {
    const data = generateDataset(100);
    const all = [...data.users, ...data.drivers, ...data.orders, ...data.deliveries];
    expect(new Set(all.map(x => x._id)).size).to.equal(400);
    for (const user of data.users) expect(user.role).to.equal(USER_ROLES.USER);
    for (const driver of data.drivers) expect(driver.role).to.equal(USER_ROLES.DRIVER);
    for (let i = 0; i < 100; i++) {
      const order = data.orders[i], delivery = data.deliveries[i];
      expect(order.userId).to.equal(data.users[i]._id);
      expect(order.total).to.equal(order.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0));
      expect(Object.values(ORDER_STATUS)).to.include(order.status);
      expect(Object.values(DELIVERY_PRIORITY)).to.include(order.priority);
      expect(delivery.orderId).to.equal(order._id);
      expect(delivery.status).to.equal(order.status);
      expect(delivery.priority).to.equal(order.priority);
      expect(delivery.driverId).to.equal([ORDER_STATUS.PENDING, ORDER_STATUS.CANCELLED].includes(order.status) ? null : data.drivers[i]._id);
    }
    await Promise.all([...data.users, ...data.drivers].map(x => new User(x).validate()));
    await Promise.all(data.orders.map(x => new Order(x).validate()));
    await Promise.all(data.deliveries.map(x => new Delivery(x).validate()));
  });
  it('GET dataset y users funcionan sin conexión a MongoDB', async () => {
    const response = await request(app).get('/api/mocks/dataset?qty=2');
    expect(response.status).to.equal(200);
    expect(response.body.data.orders).to.have.length(2);
    const users = await request(app).get('/api/mocks/users');
    expect(users.status).to.equal(200);
    expect(users.body.data).to.have.length(10);
  });
  for (const query of ['qty=0', 'qty=101', 'qty=-1', 'qty=1.5', 'qty=abc', 'qty=1&qty=2', 'qty[$gt]=1', 'unknown=1']) {
    it(`rechaza consulta ${query}`, async () => {
      expect((await request(app).get(`/api/mocks/dataset?${query}`)).status).to.equal(400);
    });
  }
  for (const body of [{}, { qty: '2' }, { qty: 0 }, { qty: 101 }, { qty: 1.5 }, { qty: 2, role: 'admin' }, []]) {
    it(`rechaza seed inválido ${JSON.stringify(body)}`, async () => {
      expect((await request(app).post('/api/mocks/seed').send(body)).status).to.equal(400);
    });
  }
  it('seed exige qty en JSON, no en query', async () => {
    expect((await request(app).post('/api/mocks/seed?qty=2').send({ qty: 2 })).status).to.equal(400);
  });
  it('oculta las rutas por defecto y en producción aunque se solicite habilitarlas', async () => {
    const env = { PORT: '8080', NODE_ENV: 'production', MONGODB_URI: 'mongodb://localhost/test', ENABLE_MOCKS: 'true' };
    expect(validateEnv(env).mocksEnabled).to.equal(false);
    expect((await request(createApp(validateEnv(env))).get('/api/mocks/users')).status).to.equal(404);
    expect((await request(createApp()).post('/api/mocks/seed').send({ qty: 1 })).status).to.equal(404);
    expect(() => validateEnv({ ...env, ENABLE_MOCKS: 'yes' })).to.throw('ENABLE_MOCKS');
  });
});

describe('M2: orquestación y compensación de fallos', () => {
  function setup(failAt, failCleanup = false) {
    const calls = [], batches = [];
    const repositories = Object.fromEntries(['users', 'orders', 'deliveries'].map(name => [name, {
      async insertMany(docs) { calls.push(`insert:${name}`); batches.push(...docs.map(x => x.mockBatchId)); if (name === failAt) throw new Error('simulado'); },
      async deleteMockBatch(id) { calls.push(`delete:${name}`); batches.push(id); if (failCleanup) throw new Error('limpieza'); },
    }]));
    return { service: createMockService(repositories), calls, batches };
  }
  it('inserta padres antes que referencias y cuenta documentos', async () => {
    const { service, calls } = setup();
    const result = await service.seed({ qty: 2 });
    expect(result.inserted).to.deep.equal({ users: 2, drivers: 2, orders: 2, deliveries: 2, total: 8 });
    expect(calls).to.deep.equal(['insert:users', 'insert:orders', 'insert:deliveries']);
  });
  for (const failAt of ['users', 'orders', 'deliveries']) {
    it(`compensa un fallo en ${failAt} únicamente por su lote`, async () => {
      const { service, calls, batches } = setup(failAt);
      let error;
      try { await service.seed({ qty: 1 }); } catch (caught) { error = caught; }
      expect(error?.statusCode).to.equal(500);
      expect(error.message).to.include('retirados');
      expect(calls.slice(-3)).to.deep.equal(['delete:deliveries', 'delete:orders', 'delete:users']);
      expect(new Set(batches).size).to.equal(1);
    });
  }
  it('si falla la compensación informa lote y no elimina sus padres', async () => {
    const { service, calls, batches } = setup('orders', true);
    let error;
    try { await service.seed({ qty: 1 }); } catch (caught) { error = caught; }
    expect(error?.message).to.include('Requiere revisión');
    expect(error.context.batchId).to.equal(batches[0]);
    expect(error.code).to.equal('MOCK_CLEANUP_FAILED');
    expect(error.cause.errors).to.have.length(2);
    expect(calls).to.deep.equal(['insert:users', 'insert:orders', 'delete:deliveries']);
  });
});
```

## tests/orders-deliveries.mongodb.js

```javascript
import { expect } from 'chai';
import request from 'supertest';
import { randomUUID } from 'node:crypto';
import app from '../src/app.js';
import User from '../src/models/user.model.js';
import Order from '../src/models/order.model.js';
import Delivery from '../src/models/delivery.model.js';
import * as orderRepository from '../src/repositories/order.repository.js';
import { expectDocumentedResponse } from './helpers/openapi.js';

const absent = '000000000000000000000000';
let user, driver, orders;
const input = () => ({ userId: String(user._id), address: 'Calle de prueba 123',
  items: [{ name: 'Caja', quantity: 3, unitPrice: 0.1 }] });
async function createOrder() {
  const response = await request(app).post('/api/orders').send(input()).expect(201);
  orders.push(response.body.data._id);
  await expectDocumentedResponse('/api/orders', 'post', response);
  return response.body.data;
}
async function createDelivery(order) {
  const response = await request(app).post('/api/deliveries').send({ orderId: order._id, driverId: String(driver._id) }).expect(201);
  await expectDocumentedResponse('/api/deliveries', 'post', response);
  return response.body.data;
}

describe('M5.1: ciclo real de pedidos y entregas', () => {
  beforeEach(async () => {
    orders = [];
    // Fixtures internas: no se crea una ruta pública para elevar roles.
    user = await User.create({ name: 'Cliente test', email: `${randomUUID()}@example.com`, role: 'user' });
    driver = await User.create({ name: 'Driver test', email: `${randomUUID()}@example.com`, role: 'driver' });
  });
  afterEach(async () => {
    if (orders.length) {
      await Delivery.deleteMany({ orderId: { $in: orders } });
      await Order.deleteMany({ _id: { $in: orders } });
    }
    await User.deleteMany({ _id: { $in: [user?._id, driver?._id].filter(Boolean) } });
  });
  it('crea, lista, consulta y avanza por ambos endpoints sin divergir estados', async () => {
    const order = await createOrder();
    expect(order).to.include({ total: 0.3, status: 'pending', priority: 'normal' });
    const delivery = await createDelivery(order);
    expect(delivery.status).to.equal('pending');
    for (const [resource, item] of [['orders', order], ['deliveries', delivery]]) {
      const found = await request(app).get(`/api/${resource}/${item._id}`).expect(200);
      await expectDocumentedResponse(`/api/${resource}/{id}`, 'get', found);
      const list = await request(app).get(`/api/${resource}?limit=1`).expect(200);
      expect(list.body.data.length).to.be.at.most(1);
      await expectDocumentedResponse(`/api/${resource}`, 'get', list);
    }
    for (const [resource, id, status] of [['orders', order._id, 'assigned'], ['deliveries', delivery._id, 'in_transit'], ['deliveries', delivery._id, 'delivered']]) {
      const changed = await request(app).patch(`/api/${resource}/${id}/status`).send({ status }).expect(200);
      await expectDocumentedResponse(`/api/${resource}/{id}/status`, 'patch', changed);
      for (const [name, item] of [['orders', order], ['deliveries', delivery]]) {
        expect((await request(app).get(`/api/${name}/${item._id}`)).body.data.status).to.equal(status);
      }
    }
    const repeated = await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'delivered' }).expect(200);
    expect(repeated.body.data.status).to.equal('delivered');
    const invalid = await request(app).patch(`/api/deliveries/${delivery._id}/status`).send({ status: 'pending' }).expect(409);
    await expectDocumentedResponse('/api/deliveries/{id}/status', 'patch', invalid);
  });
  it('rechaza usuarios, repartidores y recursos inexistentes o con roles incorrectos', async () => {
    const missingUser = await request(app).post('/api/orders').send({ ...input(), userId: absent }).expect(404);
    await expectDocumentedResponse('/api/orders', 'post', missingUser);
    expect((await request(app).post('/api/orders').send({ ...input(), userId: String(driver._id) }).expect(400)).body.error).to.equal('INVALID_CUSTOMER');
    const order = await createOrder();
    for (const [driverId, status, code] of [[absent, 404, 'DRIVER_NOT_FOUND'], [String(user._id), 400, 'INVALID_DRIVER']]) {
      const response = await request(app).post('/api/deliveries').send({ orderId: order._id, driverId }).expect(status);
      expect(response.body.error).to.equal(code);
      await expectDocumentedResponse('/api/deliveries', 'post', response);
    }
    for (const resource of ['orders', 'deliveries']) {
      const response = await request(app).get(`/api/${resource}/${absent}`).expect(404);
      await expectDocumentedResponse(`/api/${resource}/{id}`, 'get', response);
    }
    await request(app).post('/api/deliveries').send({ orderId: absent, driverId: String(driver._id) }).expect(404);
  });
  it('exige entrega para avanzar y permite cancelar sin entrega', async () => {
    const order = await createOrder();
    expect((await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'assigned' }).expect(409)).body.error).to.equal('DELIVERY_REQUIRED');
    await request(app).patch(`/api/orders/${order._id}/status`).send({ status: 'cancelled' }).expect(200);
    const closed = await request(app).post('/api/deliveries').send({ orderId: order._id, driverId: String(driver._id) }).expect(409);
    expect(closed.body.error).to.equal('DELIVERY_ORDER_CLOSED');
    await expectDocumentedResponse('/api/deliveries', 'post', closed);
  });
  it('el índice único resuelve dos altas concurrentes de entrega', async () => {
    const order = await createOrder();
    const responses = await Promise.all([1, 2].map(() => request(app).post('/api/deliveries').send({ orderId: order._id, driverId: String(driver._id) })));
    expect(responses.map(r => r.status).sort()).to.deep.equal([201, 409]);
    for (const response of responses) await expectDocumentedResponse('/api/deliveries', 'post', response);
    expect(await Delivery.countDocuments({ orderId: order._id })).to.equal(1);
  });
  it('compare-and-set impide sobrescribir un estado modificado concurrentemente', async () => {
    const order = await createOrder();
    await createDelivery(order);
    const results = await Promise.all([
      orderRepository.changeStatus(order._id, 'pending', 'assigned'),
      orderRepository.changeStatus(order._id, 'pending', 'cancelled'),
    ]);
    expect(results.filter(Boolean)).to.have.length(1);
  });
  it('ignora estados antiguos en Delivery y no almacena una segunda copia nueva', async () => {
    const order = await createOrder(); const delivery = await createDelivery(order);
    const stored = await Delivery.collection.findOne({ orderId: new Order({ _id: order._id })._id });
    expect(stored).not.to.have.property('status');
    await Delivery.collection.updateOne({ _id: stored._id }, { $set: { status: 'delivered' } });
    expect((await request(app).get(`/api/deliveries/${delivery._id}`)).body.data.status).to.equal('pending');
  });
  it('rechaza saltos de estado sin cambiar la persistencia', async () => {
    const order = await createOrder(); const delivery = await createDelivery(order);
    const response = await request(app).patch(`/api/deliveries/${delivery._id}/status`).send({ status: 'delivered' }).expect(409);
    expect(response.body.error).to.equal('INVALID_STATUS_TRANSITION');
    expect((await Order.findById(order._id)).status).to.equal('pending');
  });
});
```

## tests/orders-deliveries.test.js

```javascript
import { expect } from 'chai';
import request from 'supertest';
import app from '../src/app.js';
import { validateOrderInput } from '../src/services/order.service.js';
const id = '507f1f77bcf86cd799439011';
const valid = { userId: id, address: ' Calle 1 ', items: [{ name: ' Caja ', quantity: 3, unitPrice: 0.1 }] };

describe('M5.1: validación de pedidos y entregas sin MongoDB', () => {
  it('calcula centavos, normaliza texto y establece valores del servidor', () => {
    const order = validateOrderInput(valid);
    expect(order).to.include({ total: 0.3, status: 'pending', priority: 'normal', address: 'Calle 1' });
    expect(order.items[0].name).to.equal('Caja');
  });
  const cases = [
    ['post', '/api/orders', { ...valid, items: [] }, 'INVALID_ITEMS'],
    ['post', '/api/orders', { ...valid, items: Array(101).fill(valid.items[0]) }, 'INVALID_ITEMS'],
    ['post', '/api/orders', { ...valid, items: [{ name: 'Caja', quantity: 1, unitPrice: 0.001 }] }, 'INVALID_ORDER_AMOUNT'],
    ['post', '/api/orders', { ...valid, items: [{ name: 'Caja', quantity: 1.5, unitPrice: 1 }] }, 'INVALID_ORDER_AMOUNT'],
    ['post', '/api/orders', { ...valid, items: [{ name: 'Caja', quantity: 1000000, unitPrice: 1000000000 }] }, 'INVALID_ORDER_AMOUNT'],
    ['post', '/api/orders', { ...valid, total: 0 }, 'INVALID_BODY'],
    ['post', '/api/orders', { ...valid, priority: 'urgent' }, 'INVALID_PRIORITY'],
    ['post', '/api/orders', { ...valid, userId: 'bad' }, 'INVALID_ID'],
    ['post', '/api/deliveries', { orderId: id, driverId: 'bad' }, 'INVALID_ID'],
    ['post', '/api/deliveries', { orderId: id, driverId: id, status: 'delivered' }, 'INVALID_BODY'],
    ['patch', `/api/orders/${id}/status`, { status: 'unknown' }, 'INVALID_STATUS'],
    ['patch', `/api/deliveries/${id}/status`, { status: 'unknown' }, 'INVALID_STATUS'],
    ['get', '/api/orders?limit=101', undefined, 'INVALID_PAGINATION'],
    ['get', '/api/deliveries?extra=1', undefined, 'INVALID_QUERY'],
  ];
  for (const [method, path, body, code] of cases) {
    it(`${method.toUpperCase()} ${path}: ${code}`, async () => {
      let call = request(app)[method](path);
      if (body) call = call.send(body);
      const response = await call.expect(400);
      expect(response.body.error).to.equal(code);
    });
  }
});
```
