# Ejecutar con servidor activo en development y ENABLE_MOCKS=true.
# Solo sobre una base local descartable: crea datos y los conserva como evidencia.
& {
    $ErrorActionPreference = 'Stop'
    $baseUrl = 'http://127.0.0.1:8080'

    $seed = Invoke-RestMethod -Method Post -Uri "$baseUrl/api/mocks/seed" `
        -ContentType 'application/json' -Body '{"qty":1}'
    $userId = $seed.data.ids.users[0]
    $driverId = $seed.data.ids.drivers[0]

    $body = @{
        userId = $userId
        address = 'Calle de prueba 123'
        priority = 'normal'
        items = @(@{ name = 'Caja'; quantity = 3; unitPrice = 0.10 })
    } | ConvertTo-Json -Depth 5
    $order = Invoke-RestMethod -Method Post -Uri "$baseUrl/api/orders" `
        -ContentType 'application/json' -Body $body
    $orderId = $order.data._id
    if ($order.data.total -ne 0.30 -or $order.data.status -ne 'pending') {
        throw 'El total o estado inicial no coincide.'
    }

    $body = @{ orderId = $orderId; driverId = $driverId } | ConvertTo-Json
    $delivery = Invoke-RestMethod -Method Post -Uri "$baseUrl/api/deliveries" `
        -ContentType 'application/json' -Body $body
    $deliveryId = $delivery.data._id

    foreach ($state in @('assigned', 'in_transit', 'delivered')) {
        $resource = if ($state -eq 'assigned') { "orders/$orderId" } else { "deliveries/$deliveryId" }
        $body = @{ status = $state } | ConvertTo-Json
        $null = Invoke-RestMethod -Method Patch -Uri "$baseUrl/api/$resource/status" `
            -ContentType 'application/json' -Body $body
        $currentOrder = Invoke-RestMethod "$baseUrl/api/orders/$orderId"
        $currentDelivery = Invoke-RestMethod "$baseUrl/api/deliveries/$deliveryId"
        if ($currentOrder.data.status -ne $state -or $currentDelivery.data.status -ne $state) {
            throw "Estados incoherentes: $state"
        }
        Write-Host "OK: pedido y entrega = $state"
    }

    $rejected = $false
    try {
        $null = Invoke-RestMethod -Method Patch -Uri "$baseUrl/api/deliveries/$deliveryId/status" `
            -ContentType 'application/json' -Body '{"status":"pending"}' -ErrorAction Stop
    }
    catch {
        if ($null -eq $_.Exception.Response) { throw }
        $code = [int]$_.Exception.Response.StatusCode
        $errorBody = $_.ErrorDetails.Message | ConvertFrom-Json
        if ($code -ne 409 -or $errorBody.error -ne 'INVALID_STATUS_TRANSITION') { throw }
        $rejected = $true
        Write-Host "OK: HTTP $code INVALID_STATUS_TRANSITION"
    }
    if (-not $rejected) { throw 'Se permitió un retroceso de estado inválido.' }
    [pscustomobject]@{ Resultado = 'OK'; Pedido = $orderId; Entrega = $deliveryId; Lote = $seed.data.batchId }
}
