# Archivo histórico

Estos documentos corresponden a los módulos 1 a 5 y conservan sus instrucciones y resultados originales. No representan la configuración, rutas ni cantidad de tests de la versión final. Para trabajar con la versión actual usar README.md y las guías situadas directamente en src/docs/.
