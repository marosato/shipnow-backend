# Verificación de la versión 1.0.0

## Evidencia obtenida durante esta corrección

- `npm run test:unit`: **114 passing**. Incluye las pruebas anteriores y validaciones de formato/tamaño de archivos, multipart, aislamiento de la URI de tests, health sin conexión y rutas nuevas.
- Swagger: OpenAPI válido, 31 operaciones habilitando mocks/logger, IDs de operación únicos y referencias resueltas. Las nuevas respuestas de integración se comparan con sus schemas al ejecutar MongoDB.
- Validación posterior en Windows, informada por la autora: `npm test` completó **114 pruebas unitarias y 26 de integración con MongoDB**.
- `npm audit`: 0 vulnerabilidades después de actualizar la dependencia transitiva serialize-javascript.
- Sintaxis: 66 archivos JavaScript revisados; Compose parseado como YAML (no sustituye la ejecución de Docker).
- Docker: **no ejecutado**; Docker Engine/CLI no está disponible aquí. El archivo Compose y Dockerfile están incluidos, pero requieren prueba real de construcción y arranque.
- GitHub Actions: workflow preparado; consultar el resultado real del commit en Actions. Véase `VALIDACION-GITHUB.md`.

## Validación local requerida

Con MongoDB iniciado y desde la raíz del proyecto:

```powershell
npm ci
npm test
if ($LASTEXITCODE -ne 0) { throw 'La suite no pasó; conservar la salida para corregirla.' }
```

Se esperan 114 pruebas sin MongoDB y 26 con MongoDB. La suite usa `shipnow_test`, crea fixtures propios y elimina solo esos registros. No depende de seeds previos ni de la API corriendo.

## Validación de Docker requerida

Con Docker Desktop iniciado y el servidor local detenido:

```powershell
docker compose config --quiet
if ($LASTEXITCODE -ne 0) { throw 'Compose inválido.' }
docker compose --profile test run --build --rm tests
if ($LASTEXITCODE -ne 0) { throw 'Fallaron los tests en Docker.' }
docker compose up --build -d --wait
if ($LASTEXITCODE -ne 0) { throw 'La API o MongoDB no están saludables.' }
Invoke-RestMethod 'http://127.0.0.1:8080/api/health' | ConvertTo-Json -Depth 5
Start-Process 'http://127.0.0.1:8080/api/docs/'
```

Confirmar API y MongoDB saludables en `docker compose ps`. En producción `/loggerTest` y `/api/mocks/dataset` deben responder 404. Realizar el recorrido del documento `ENTREGA-FINAL.md`, subir un comprobante y comprobar que persiste después de `docker compose restart api`.

Si falla un comando, detener la secuencia y revisar su salida. No ejecutar cambios de base ni borrar volúmenes como solución automática.

## Antes del commit

```powershell
git status --short
git diff --stat
```

Verificar que no se incluyan `.env`, uploads, logs, node_modules ni credenciales. Si el proyecto se actualizó copiando el ZIP, mover fuera del repo la vieja carpeta `docs/` de la raíz; su contenido histórico ya está en `src/docs/historial/`. Revisar que se registren los archivos nuevos y la reubicación de documentación.
