# Corrección de la entrega final

## Respuesta a la devolución

| Observación | Cambio implementado | Verificación |
| --- | --- | --- |
| Orders/Deliveries tenían modelos y mocks sin endpoints | Routers, controllers, services y repositories para ambos recursos; CRUD y reglas de estado. | `orders-deliveries.*` y `final-flow.mongodb.js`. |
| Faltaba CRUD/tracking del envío | PATCH de datos, baja lógica y consultas de tracking; historial persistido y estado único en Order. | Ciclo completo y bajas por ambas rutas en `final-flow.mongodb.js`. |
| Faltaba Multer | Documentos de usuario y comprobantes de entrega; PDF/JPEG/PNG, 5 MiB, firma/MIME/extensión, metadatos y descarga. | `final.test.js` y `final-flow.mongodb.js`. |
| Faltaba Docker | Dockerfile multi-stage, usuario no-root, dockerignore, Compose con API/Mongo y healthcheck. | Construcción y ejecución pendientes en un equipo con Docker. |
| `npm test` no cubría el ciclo completo | Ejecuta pruebas sin MongoDB y funcionales con MongoDB real. Base exclusiva y limpieza de fixtures. | 114 pruebas sin MongoDB aprobadas; 26 de integración pendientes de ejecución. |
| `docs` debe estar dentro de `src` | Swagger y guías vigentes en `src/docs`; apuntes anteriores en `src/docs/historial`. | No existe carpeta `docs` en la raíz de este paquete. |

También se agregó healthcheck con ping a MongoDB, un comando administrativo para crear repartidores, separación de logs de actividad/errores y pruebas de archivos inválidos y de compensación cuando falla MongoDB.

## Decisiones de dominio

- Order representa el pedido del cliente; Delivery representa su entrega, con un índice único por pedido.
- El estado, la prioridad y el historial pertenecen a Order. Delivery los consulta, evitando dos estados que puedan divergir. La reasignación de repartidor se conserva en Order como valor vigente, con compatibilidad para entregas anteriores.
- `PATCH /orders/:id` admite dirección, ítems y prioridad mientras está pendiente. Recalcula el total si cambian los ítems.
- `PATCH /deliveries/:id` admite un repartidor existente con rol `driver`, mientras el pedido esté pendiente.
- `DELETE` en cualquiera de los dos recursos realiza la baja lógica del envío completo. No elimina documentos físicos; quedan conservados para auditoría. Solo se permite antes de asignar o tras cancelar.
- `PATCH .../status` valida transiciones. El compare-and-set evita sobrescribir un estado concurrente. La escritura añade el evento al historial de forma atómica.
- El tracking devuelve ID, estado y eventos con fecha UTC. Los registros de versiones anteriores no tienen eventos históricos reconstruidos: su lista puede estar vacía.
- Los ítems del pedido son conceptos con nombre, cantidad y precio. No descuentan stock del catálogo Products.

## Recorrido para demostrar el flujo

1. Crear un usuario con `POST /api/users`.
2. Crear un repartidor con `npm run driver:create -- "Nombre" "email@example.com"` (o seed de mocks en desarrollo).
3. Crear un pedido con ese usuario:

```json
{
  "userId": "REEMPLAZAR_POR_ID_DEL_USUARIO",
  "address": "Calle de prueba 123",
  "priority": "normal",
  "items": [{ "name": "Caja", "quantity": 2, "unitPrice": 12.5 }]
}
```

4. Editar la dirección con `PATCH /api/orders/:id` y `{ "address": "Calle corregida 456" }`.
5. Crear la entrega con `POST /api/deliveries` y `{ "orderId": "ID_PEDIDO", "driverId": "ID_REPARTIDOR" }`.
6. Enviar sucesivamente a `PATCH /api/deliveries/:id/status`: `{ "status": "assigned" }`, `{ "status": "in_transit" }` y `{ "status": "delivered" }`.
7. Consultar `GET /api/deliveries/:id/tracking`: debe mostrar los cuatro estados, incluyendo pending.
8. Subir un PDF/imagen desde Swagger, en `POST /api/deliveries/:id/documents`, campo `document`. Consultar sus metadatos y descargarlo usando el ID devuelto.
9. Intentar volver a pending: debe responder 409 `INVALID_STATUS_TRANSITION`.
10. Para demostrar DELETE, crear otro pedido pendiente y darlo de baja. Consultarlo después debe devolver 404. No borrar el envío entregado del paso anterior.

La suite funcional automatiza este recorrido, además de probar errores, duplicados y concurrencia.

## Archivos

- Un adjunto por petición; se rechazan campos extras, multipart malformado, formatos incompatibles y archivos mayores a 5 MiB.
- Dueño validado antes de recibir el archivo y antes de persistirlo.
- Nombre de disco aleatorio; nunca se usa el nombre enviado para construir una ruta.
- El almacenamiento en memoria durante la recepción está limitado por archivo a 5 MiB. Un despliegue público requeriría además cuotas, limitación de solicitudes y controles de acceso.
- Si la escritura en MongoDB falla, se intenta retirar el archivo; una falla de compensación se registra para revisión. Disco y MongoDB no comparten una transacción.
- Los documentos de recursos dados de baja se conservan, pero dejan de estar disponibles por las rutas públicas del recurso.

## Preparación de la segunda entrega

Seguir `VERIFICACION-FINAL.md`, ejecutar todos los pasos y guardar sus salidas. No sustituir evidencia de ejecución por la presencia de Dockerfile o tests. El README contiene instalación, entorno, endpoints, Docker y alcance.
