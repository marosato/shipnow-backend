import multer from 'multer';
import { extname } from 'node:path';
import { MAX_FILE_SIZE, FILE_TYPES } from '../config/upload.config.js';
import { AppError } from '../errors/app-error.js';
import { ERRORS } from '../errors/error-catalog.js';
const receive = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE, files: 1, fields: 0, parts: 1, fieldNameSize: 50 },
  fileFilter(req, file, callback) {
    const valid = FILE_TYPES[file.mimetype]?.includes(extname(file.originalname).toLowerCase());
    callback(valid ? null : new AppError(ERRORS.INVALID_FILE_TYPE), Boolean(valid));
  },
}).single('document');
export function upload(req, res, next) {
  receive(req, res, error => {
    if (!error) return next();
    if (error instanceof AppError) return next(error);
    next(new AppError(error.code === 'LIMIT_FILE_SIZE' ? ERRORS.FILE_TOO_LARGE : ERRORS.INVALID_UPLOAD));
  });
}
