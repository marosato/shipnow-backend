import { Schema, model } from 'mongoose';
const schema = new Schema({
  ownerType: { type: String, enum: ['user', 'delivery'], required: true },
  ownerId: { type: Schema.Types.ObjectId, required: true },
  originalName: { type: String, required: true, maxlength: 180 },
  storageKey: { type: String, required: true, unique: true },
  mimeType: { type: String, required: true },
  size: { type: Number, required: true, min: 1 },
}, { timestamps: true, versionKey: false });
schema.index({ ownerType: 1, ownerId: 1, _id: 1 });
export default model('Document', schema);
