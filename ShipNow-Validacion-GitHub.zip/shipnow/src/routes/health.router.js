import { Router } from 'express';
import { get } from '../controllers/health.controller.js';
const router = Router();
router.get('/', get);
export default router;
