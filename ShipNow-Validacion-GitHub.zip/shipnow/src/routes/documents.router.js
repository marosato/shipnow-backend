import { Router } from 'express';
import { documentController } from '../controllers/document.controller.js';
import { upload } from '../middlewares/upload.js';
export function documentsRouter(type, directory) {
  const router = Router({ mergeParams: true });
  const controller = documentController(type, directory);
  router.get('/', controller.list);
  router.post('/', controller.checkOwner, upload, controller.create);
  router.get('/:documentId', controller.download);
  return router;
}
